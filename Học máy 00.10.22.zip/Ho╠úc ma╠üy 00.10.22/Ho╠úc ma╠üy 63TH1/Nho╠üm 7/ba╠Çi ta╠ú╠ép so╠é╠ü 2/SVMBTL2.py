import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split 
from sklearn.datasets import load_iris
from sklearn.model_selection import cross_val_score
from sklearn.tree import DecisionTreeClassifier
from sklearn import svm
from sklearn.metrics import precision_score, recall_score, f1_score,accuracy_score

#Đọc dữ liệu và chuẩn bị tập huấn luyện
df = pd.read_csv('D:/code hoc may/Breast_cancer_data.csv') #đọc tập csv và lưu trữ dạng dataframe
#chọn các cột cụ thể và chuyển đổi thành mảng ngắn gọn
X_data = np.array(df[['mean_radius','mean_texture','mean_perimeter','mean_area','mean_smoothness','diagnosis']].values) # lấy giá trị của các cột được chọn từ df và chuyển đổi thành mảng numpy
data=X_data  #gán cho data
#phân chia thành tập huấn luyện 70% và tập kiểm trá 30% và xáo trộn khi tách
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True)
np.set_printoptions(suppress=True)
print(dt_Train)
X_train = dt_Train[:, :5] #tính năng của tập HL
y_train = dt_Train[:, 5] #nhãn của tập HL
X_test = dt_Test[:, :5] #tính năng của tập KT
y_test = dt_Test[:, 5] #nhãn của tập KT

#loại kernel là tuyến tính,Dung sai cho tiêu chí dừng= 0.01,tham số quy hóa =1000,sử dụng pp rút gọn thu hẹp tăng tốc quá trình tối ưu hóa,Chỉ định kích thước của bộ đệm kernel =200,nó sẽ in thông báo tiến trình,Tham số này đặt số lần lặp tối đa
clf = svm.SVC(kernel='linear', tol=0.01, C=1000.0, shrinking=True, cache_size=200, verbose=False, max_iter=-1)
clf.fit(X_train, y_train)

# Dự đoán kết quả trên tập kiểm tra
y_pred = clf.predict(X_test)

# Đánh giá độ chính xác
accuracy = accuracy_score(y_pred, y_test)
# Tính Precision
precision = precision_score(y_test, y_pred)

# Tính Recall
recall = recall_score(y_test, y_pred)

# Tính F1-score
f1 = f1_score(y_test, y_pred)
print('precision:',precision)
print('recall:',recall)
print('f1_score:',f1)
print('Độ chính xác của SVM:', accuracy)
print('Độ sai lệch của SVM:',1-accuracy)
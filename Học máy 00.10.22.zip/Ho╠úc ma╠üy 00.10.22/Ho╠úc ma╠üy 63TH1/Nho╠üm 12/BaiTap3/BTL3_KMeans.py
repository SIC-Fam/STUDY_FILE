from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score,davies_bouldin_score

data = pd.read_csv('Customers.csv')
le = preprocessing.LabelEncoder()         #khoi tao ra vi du
data = data.apply(le.fit_transform)       #ma hoa

dt_Train, dt_Test = train_test_split(data, test_size=0.1, shuffle=True)
X_train = dt_Train.drop(['CustomerID'], axis=1)
X_test = dt_Test.drop(['CustomerID'], axis=1)
X_train = np.array(X_train)

#init:  init bằng ‘random’ để model thực hiện lựa chọn tâm cụm khởi đầu một cách hoàn toàn ngẫu nhiên
#tham số n_init cho biết model thực hiện auto lần train với bộ tâm cụm khởi đầu khác nhau để lựa chọn model cho hiệu quả phân loại tốt nhất
#n_clusters là phân cụm
kmeans = KMeans(n_clusters=2, random_state=0, n_init="auto").fit(X_train)
labels = kmeans.labels_
centers = kmeans.cluster_centers_

print('Cụm :', labels)
print('Silhouette Score:', silhouette_score(X_train, labels))
print('Davies Bouldin:', davies_bouldin_score(X_train, labels))
# print('center: ',centers)

#Thuật toán tìm k
# distortions =[]
# K = range(1,10)
# for k in K:
#     kmeanModel = KMeans(n_clusters=k)
#     kmeanModel.fit(X_train)
#     distortions.append(kmeanModel.inertia_)
# plt.figure(figsize=(9, 6))
# plt.plot(K, distortions, 'bx-')
# plt.xlabel('k')
# plt.ylabel('Distortion')
# plt.title('The Elbow Method showing the optimal k')
# plt.show()


#form
window = Tk()
window.title('BTL3_KMeans')
window.geometry('800x500')
window.configure(background= 'cyan')
lable_GioiTinh = Label(window, text="Giới tính:", bg="cyan")
lable_GioiTinh.grid(row=1, column=1, padx=40, pady=10)
lable_Tuoi = Label(window, text="Tuổi:", bg="cyan")
lable_Tuoi.grid(row=2, column=1, pady=10)
lable_ThuNhapHangNam = Label(window, text="Thu nhập hàng năm:", bg="cyan")
lable_ThuNhapHangNam.grid(row=3, column=1, pady=10)
lable_DiemChiTieu = Label(window, text="Điểm chi tiêu:", bg="cyan")
lable_DiemChiTieu.grid(row=4, column=1, pady=10)
lable_NgheNghiep = Label(window, text="Nghề nghiệp:", bg="cyan")
lable_NgheNghiep.grid(row=5, column=1, pady=10)
lable_KinhNghiem = Label(window, text="Kinh nghiệm làm viêc(số năm):", bg="cyan")
lable_KinhNghiem.grid(row=6, column=1, pady=10)
lable_GiaDinh = Label(window, text="Quy mô gia đình:", bg="cyan")
lable_GiaDinh.grid(row=7, column=1, pady=10)

# textbox_IDKhachHang = Entry(window)
# textbox_IDKhachHang.grid(row=1, column=2)
textbox_GioiTinh = Entry(window)
textbox_GioiTinh.grid(row=1, column=2)
textbox_Tuoi = Entry(window)
textbox_Tuoi.grid(row=2, column=2)
textbox_ThuNhapHangNam = Entry(window)
textbox_ThuNhapHangNam.grid(row=3, column=2)
textbox_DiemChiTieu = Entry(window)
textbox_DiemChiTieu.grid(row=4, column=2)
textbox_NgheNghiep = Entry(window)
textbox_NgheNghiep.grid(row=5, column=2)
textbox_KinhNghiem = Entry(window)
textbox_KinhNghiem.grid(row=6, column=2)
textbox_GiaDinh = Entry(window)
textbox_GiaDinh.grid(row=7, column=2)

def get_GioiTinh(GioiTinh):
    if(GioiTinh == 'male'):
        return 1
    else:
        return 0
def dudoankmean():
    GioiTinh = textbox_GioiTinh.get()
    Tuoi = textbox_Tuoi.get()
    ThuNhap = textbox_ThuNhapHangNam.get()
    ChiTieu = textbox_DiemChiTieu.get()
    NgheNghiep = textbox_NgheNghiep.get()
    KinhNghiem = textbox_KinhNghiem.get()
    GiaDinh = textbox_GiaDinh.get()
    if ((GioiTinh == '') or (Tuoi == '') or (ThuNhap == '') or (ChiTieu == '') or (NgheNghiep == '') or (KinhNghiem == '') or (GiaDinh == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        nhan = kmeans.predict([[get_GioiTinh(GioiTinh), int(Tuoi), int(ThuNhap), int(ChiTieu), int(NgheNghiep), int(KinhNghiem), int(GiaDinh)]])
        Nhan.configure(text="Cụm: " + str(nhan[0]), bg="cyan")
style = ttk.Style()
style.configure('Cyan.TButton', background='cyan')
XacNhan = ttk.Button(window, text="Xác nhận",command=dudoankmean, style='Cyan.TButton')
XacNhan.grid(row=8, column=2, padx=40, pady=10)
Silhouette = Label(window)
Silhouette.grid(row=9, column=1)
Silhouette.configure(text="Độ đo đánh giá chất lượng mô hình Silhouette là:"+str(silhouette_score(X_train, labels)), bg="cyan")
DaviesBouldin = Label(window)
DaviesBouldin.grid(row=10, column=1)
DaviesBouldin.configure(text="Độ đo đánh giá chất lượng mô hình DaviesBouldin là:"+str(davies_bouldin_score(X_train, labels)), bg="cyan")
Nhan = Label(window)
Nhan.grid(row=11, column=1)
window.mainloop()
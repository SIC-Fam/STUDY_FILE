import pandas as pd
import numpy as np
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Lasso

data = pd.read_csv('ParisHousing.csv')
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle=False)

X_Train = dt_Train.iloc[:, :15]
Y_Train = dt_Train.iloc[:, -1]
X_Test = dt_Test.iloc[:, :15]
Y_Test = dt_Test.iloc[:, -1]

y = np.array(Y_Test)

model = Lasso().fit(X_Train, Y_Train)
y_pred= model.predict(X_Test)
print("Thuc te        Du doan      Chenh lech")
for i in range(0,10):
    print("%.2f" % y[i],"   ",  "%.2f" % y_pred[i], "   ", abs(y[i]-y_pred[i]))

def tinh_nse(y_test, y_pred):
    sse = np.sum((y_test - y_pred) ** 2)
    sst = np.sum((y_test - np.mean(y_test)) ** 2)
    nse = 1 - (sse / sst)
    return nse

print("Đánh giá mô hình Lasso bằng độ đo R2 %.12f" %r2_score(Y_Test, y_pred))
print("Đánh giá mô hình Lasso bằng độ đo NSE: %.12f" % tinh_nse(Y_Test, y_pred))
print("Đánh giá mô hình Lasso bằng độ đo MAE: %.12f" % mean_absolute_error(Y_Test, y_pred))
print("Đánh giá mô hình Lasso bằng độ đo RMSE: %.12f" % np.sqrt(mean_squared_error(Y_Test, y_pred)))
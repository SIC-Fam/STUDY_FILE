import pandas as pd
import numpy as np
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge

data = pd.read_csv('ParisHousing.csv')
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle=False)

X_train = dt_Train.iloc[:, :15]
y_train = dt_Train.iloc[:, -1]
X_test = dt_Test.iloc[:, :15]
y_test = dt_Test.iloc[:, -1]
y = np.array(y_test)

model2 = Ridge().fit(X_train, y_train)
y_pred= model2.predict(X_test)

print("Thuc te        Du doan      Chenh lech")
for i in range(0,10):
    print("%.2f" % y[i],"   ",  "%.2f" % y_pred[i], "   ", abs(y[i]-y_pred[i]))

def tinh_nse(y_test,y_pred):
    sse = np.sum((y_test - y_pred) ** 2)
    sst = np.sum((y_test - np.mean(y_test)) ** 2)
    nse = 1 - (sse / sst)
    return nse

print("Đánh giá mô hình Ridge bằng độ đo R2: %.12f" % r2_score(y_test, y_pred))
print("Đánh giá mô hình Ridge bằng độ đo NSE: %.12f" % tinh_nse(y_test, y_pred))
print("Đánh giá mô hình Ridge bằng độ đo MAE: %.12f" % mean_absolute_error(y_test, y_pred))
print("Đánh giá mô hình Ridge bằng độ đo RMSE: %.12f" % np.sqrt(mean_squared_error(y_test, y_pred)))
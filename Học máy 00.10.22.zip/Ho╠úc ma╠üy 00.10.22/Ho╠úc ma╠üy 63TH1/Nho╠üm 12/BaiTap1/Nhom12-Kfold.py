from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split

# Load du lieu
data = pd.read_csv('ParisHousing.csv')
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle=False)

# tinh error, y thuc te, y_pred: dl du doan
def error(y, y_pred):
    sum = 0
    for i in range(0, len(y)):
        sum = sum + abs(y[i] - y_pred[i])
    return sum / len(y)  # tra ve trung binh

min = 999999
k = 3
kf = KFold(n_splits=k, random_state=None)
# fold_index = 1
for train_index, validation_index in kf.split(dt_Train):
    X_train, X_validation = dt_Train.iloc[train_index, :15], dt_Train.iloc[validation_index, :15]
    y_train, y_validation = dt_Train.iloc[train_index, -1], dt_Train.iloc[validation_index, -1]

    lr = LinearRegression()
    lr.fit(X_train, y_train)
    y_train_pred = lr.predict(X_train)
    y_validation_pred = lr.predict(X_validation)
    y_train = np.array(y_train)
    y_validation = np.array(y_validation)
    y = np.array(y_train)

    sum_error = error(y_train, y_train_pred) + error(y_validation, y_validation_pred)

# Lay ra tap index cua tung fold
    # print("Fold ",fold_index)
    # print(train_index)
    # print(validation_index)

#So sanh sum_error voi min de lua chon mo hinh fold tot nhat
    if (sum_error < min):
        min = sum_error
        regr = lr
        # min_index = fold_index
#     fold_index += 1
# print(min_index)

y_test_pred = regr.predict(dt_Test.iloc[:, :15])
y_test = np.array(dt_Test.iloc[:, -1])
print("Thuc te        Du doan              Chenh lech")
for i in range(0, 10):
    print(y_test[i], "  ", y_test_pred[i], "  ", abs(y_test[i] - y_test_pred[i]))

def tinh_nse(y_test,y_test_pred):
    sse = np.sum((y_test - y_test_pred) ** 2)
    sst = np.sum((y_test - np.mean(y_test)) ** 2)
    nse = 1 - (sse / sst)
    return nse

print("Đánh giá mô hình K-Fold bằng độ đo R2: %.12f" % r2_score(y_test, y_test_pred))
print("Đánh giá mô hình K-Fold bằng độ đo NSE: %.12f" % tinh_nse(y_test, y_test_pred))
print("Đánh giá mô hình K-Fold bằng độ đo MAE: %.12f" % mean_absolute_error(y_test, y_test_pred))
print("Đánh giá mô hình K-Fold bằng độ đo RMSE: %.12f" % np.sqrt(mean_squared_error(y_test, y_test_pred)))
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn import preprocessing
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

df = pd.read_csv('riceClassification.csv')
X_data = np.array(df[['id', 'Area', 'MajorAxisLength', 'MinorAxisLength', 'Eccentricity', 'ConvexArea',
                      'EquivDiameter', 'Extent', 'Perimeter', 'Roundness', 'AspectRation', 'Class']].values)
data = pd.read_csv('riceClassification.csv')
le = preprocessing.LabelEncoder()
data = data.apply(le.fit_transform)

dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True)
X_train = dt_Train.drop(['id', 'Class'], axis=1)
y_train = dt_Train['Class']
X_test = dt_Test.drop(['id', 'Class'], axis=1)
y_test = dt_Test['Class']
y_test = np.array(y_test)

pla = DecisionTreeClassifier()
pla.fit(X_train, y_train)
y_predict = pla.predict(X_test)
#print(accuracy_score(y_test, y_predict))

count = 0
for i in range(0, len(y_predict)):
    if(y_test[i] == y_predict[i]):
        count = count + 1

print('Tỷ lệ dự đoán đúng của mô hình CART với độ đo accuracy_score:', count/len(y_predict))
print('Tỷ lệ dự đoán đúng của mô hình CART với độ đo precision_score:', precision_score(y_test, y_predict))
print('Tỷ lệ dự đoán đúng của mô hình CART với độ đo recall_score:', recall_score(y_test, y_predict))
print('Tỷ lệ dự đoán đúng của mô hình CART với độ đo f1_score:', f1_score(y_test, y_predict))

print('Tỷ lệ dự đoán sai của mô hình CART:', 1 - count/len(y_predict))


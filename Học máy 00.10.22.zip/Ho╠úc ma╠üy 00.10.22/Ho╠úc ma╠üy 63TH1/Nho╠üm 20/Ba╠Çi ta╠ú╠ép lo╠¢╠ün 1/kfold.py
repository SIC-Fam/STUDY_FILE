import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder

data = pd.read_csv('Gas.csv', encoding='latin1')
#chia dữ liệu 70% để train 30% để test, có xáo trộn dữ liệu
dt_Train,dt_Test = train_test_split(data, test_size=0.3, shuffle=False)
label_encoder = LabelEncoder()

# Kết hợp tập huấn luyện và tập kiểm tra để đảm bảo tất cả các giá trị trong 'Country' đã được mã hóa
all_countries = pd.concat([dt_Train['Country'], dt_Test['Country']], axis=0)

# Mã hóa tất cả các giá trị trong 'Country'
all_countries_encoded = label_encoder.fit_transform(all_countries)


# Cập nhật cột 'Country' trong tập huấn luyện và tập kiểm tra
dt_Train['Country'] = all_countries_encoded[:len(dt_Train)]
dt_Test['Country'] = all_countries_encoded[len(dt_Train):]
k=5
kf=KFold(n_splits=k,random_state=None) #chia tập dữ liệu thành 5 phần
#hàm tính lỗi
def error(y_test,y_pred):
   l=[]
   for i in range(0,len(y_test)):
      l.append(np.abs(np.array(y_test[i:i+1])-np.array(y_pred[i:i+1])))
   return np.mean(l)#trả về giá trị trênh lệch
def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))
def MAE(y_test, y_pred):
    return mean_absolute_error(y_test, y_pred)

def RMSE(y_test, y_pred):
    return mean_squared_error(y_test, y_pred, squared=False)

min=999
for Trainning_Set,Validation_Set in kf.split(dt_Train): #chọn ngẫu nhiên 4 phần là data train và 1 phần làm validation
   #cắt dữ liệu vào các biến tương ứng (X chứa các thuộc tính | Y chứa nhãn)
   X_Train=dt_Train.iloc[Trainning_Set,:5]
   X_Validation=dt_Train.iloc[Validation_Set,:5]
   Y_Train=dt_Train.iloc[Trainning_Set,5]
   Y_Validation=dt_Train.iloc[Validation_Set,5]
#Khai báo mô hình hồi quy tuyến tính và tính toán bộ trọng số W của hàm tuyến tính
   LinReg=LinearRegression().fit(X_Train,Y_Train)

   Y_Train_pred=LinReg.predict(X_Train)#dự đoán nhãn của bộ dữ liệu trainning
   Y_Validation_pred=LinReg.predict(X_Validation)#dự đoán nhãn của bộ dữ liệu validation
   Y_Train=np.array(Y_Train)
   Y_Validation=np.array(Y_Validation)
   #tính tổng trung bình lỗi trên mô hình đã chọn
   sum_er=error(Y_Train,Y_Train_pred)+error(Y_Validation,Y_Validation_pred) # tính tổng của train error và validation error
   if (sum_er<min):
      min=sum_er
      lr=LinReg # trả về mô hình có lỗi nhỏ nhất

#bắt đầu dự đoán dựa trên mô hình tốt nhất
X_Test=dt_Test.iloc[:,:5]
Y_Test=dt_Test.iloc[:,5]
Y_Test_pred=lr.predict(X_Test)
Y_Test=np.array(Y_Test)

for i in range(0,len(Y_Test)):
    print("Thực tế:",Y_Test[i],"--","Dự đoán:",Y_Test_pred[i], "--","Chênh lệch:", abs(Y_Test[i]-Y_Test_pred[i]))
print ('R2 :' ,r2_score(Y_Test,Y_Test_pred)) 
print("NSE: ", NSE(Y_Test,Y_Test_pred))
print('MAE:', MAE(Y_Test,Y_Test_pred))
print('RMSE:', RMSE(Y_Test,Y_Test_pred))

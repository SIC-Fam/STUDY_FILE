import pandas as pd
from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
import numpy as np
from sklearn.preprocessing import LabelEncoder

# Đọc dữ liệu từ tệp gas.csv
data = pd.read_csv('Gas.csv', encoding='latin1')

# Chia dữ liệu thành tập huấn luyện và tập kiểm tra
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle=False)

def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))

def MAE(y_test, y_pred):
    return mean_absolute_error(y_test, y_pred)

def RMSE(y_test, y_pred):
    return mean_squared_error(y_test, y_pred, squared=False)

label_encoder = LabelEncoder()
all_countries = pd.concat([dt_Train['Country'], dt_Test['Country']], axis=0)
all_countries_encoded = label_encoder.fit_transform(all_countries)
dt_Train['Country'] = all_countries_encoded[:len(dt_Train)]
dt_Test['Country'] = all_countries_encoded[len(dt_Train):]

X_Train = dt_Train.iloc[:, :6]  
Y_Train = dt_Train.iloc[:, 6]  
X_Test = dt_Test.iloc[:, :6]   
Y_Test = dt_Test.iloc[:, 6] 

reg = LinearRegression().fit(X_Train, Y_Train)
y_pred = reg.predict(X_Test)
y = np.array(Y_Test)
print("NSE: ", NSE(Y_Test, y_pred))
print('R2: %.5f' % r2_score(Y_Test, y_pred))
print('MAE:', MAE(Y_Test, y_pred))
print('RMSE:', RMSE(Y_Test, y_pred))

print(data.iloc[:, :6])

# # In ra giá trị thực tế và dự đoán
# print("Thuc te   Du doan")
# for i in range(len(y)):
#     print("%.5f" % y[i], "   ", y_pred[i])
# print(data.iloc[:,6])

# print(X_Train)
# print(X_Test)
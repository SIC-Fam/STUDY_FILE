import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from sklearn.cluster import KMeans
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import silhouette_score, davies_bouldin_score
from sklearn.model_selection import train_test_split


df = pd.read_csv('driver-data.csv')
X = np.array(df[['id','mean_dist_day','mean_over_speed_perc']].values)    
X_train, X_test= train_test_split(X,test_size=0.1 , shuffle = False)
n_clusters = 5

# Mô hình KMeans
kmeans = KMeans(n_clusters=n_clusters)
kmeans.fit(X_train)


#form
form = tk.Tk()
form.title("Phâm cụm tài xế:")
form.geometry("500x500")



lable_ten = tk.Label(form, text = "Nhập thông tin:", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)

lable_tv = tk.Label(form, text = " ID:")
lable_tv.grid(row = 2, column = 1, padx = 40, pady = 10)
textbox_tv = tk.Entry(form)
textbox_tv.grid(row = 2, column = 2)

lable_radio = tk.Label(form, text = "mean_dist_day:")
lable_radio.grid(row = 3, column = 1, pady = 10)
textbox_radio = tk.Entry(form)
textbox_radio.grid(row = 3, column = 2)

lable_newspaper = tk.Label(form, text = "mean_over_speed_perc:")
lable_newspaper.grid(row = 4, column = 1,pady = 10)
textbox_newspaper = tk.Entry(form)
textbox_newspaper.grid(row = 4, column = 2)



pred = kmeans.predict(X_test)
# Tính toán độ đo Silhouette và Davies-Bouldin
silhouette = silhouette_score(X_train, kmeans.labels_)
davies_bouldin = davies_bouldin_score(X_train, kmeans.labels_)


lbl1 = tk.Label(form)
lbl1.grid(column=2, row=8)
lbl1.configure(text="Tỉ lệ dự đoán đúng của K-Mean: "+'\n'
                           +"silhouette: "+str(silhouette)+'\n'
                           +"davies_bouldin: "+str(davies_bouldin)+'\n')

def dudoan():
    tv = textbox_tv.get()
    radio = textbox_radio.get()
    newspaper = textbox_newspaper.get()
    if((tv == '') or (radio == '') or (newspaper == '')):
        messagebox.showinfo("Thông báo", "Hãy nhập đủ dữ liệu!")
    else:
        X_dudoan = np.array([tv,radio,newspaper]).reshape(1, -1)
        label = kmeans.predict(X_dudoan)
        lbl.configure(text= f'Nhãn: {label}')
button_cart = tk.Button(form, text = 'Nhãn mới', command = dudoan)
button_cart.grid(row = 9, column = 2, pady = 20)
lbl = tk.Label(form, text="...")
lbl.grid(column=2, row=10)

form.mainloop()

import numpy as np
import pandas as pd
from sklearn.calibration import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
df = pd.read_csv('./Housing.csv')
X_data = np.array(df[['price', 'area', 'bedrooms', 'bathrooms', 'stories', 'parking']].values)

def data_encoder(X):
    for i, j in enumerate(X):
        for k in range(0, 6):
            if (j[k] == "unfurnished"):
                j[k] = 0
            elif (j[k] == "furnished"):
                j[k] = 1
            elif (j[k] == "semi-furnished"):
                j[k] = 2
            elif (j[k] == "low"):
                j[k] = 3
            elif (j[k] == "2"):
                j[k] = 4
            elif (j[k] == "3"):
                j[k] =5
            elif (j[k] == "4"):
                j[k] = 6
            elif (j[k] == "5more"):
                j[k] =7
            elif (j[k] == "more"):
                j[k] = 8
            elif (j[k] =="small"):
                j[k] =9
            elif (j[k] == "big"):
                j[k] = 10
    return X
data=data_encoder(X_data) #dung ham date_encoder de chuan hoa' du lieu va luu vao bien data
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True)
#print(dt_Train)
X_train = dt_Train[:, :5]
y_train = dt_Train[:, 5]
X_test = dt_Test[:, :5]
y_test = dt_Test[:, 5]

pla = Perceptron().fit(X_train, y_train)
y_predict = pla.predict(X_test) 
Count = 0
for i in range(0,len(y_predict)):
    if(y_test[i] == y_predict[i]):
        Count = Count +1
print('Ty le du doan dung:', Count/len(y_predict))
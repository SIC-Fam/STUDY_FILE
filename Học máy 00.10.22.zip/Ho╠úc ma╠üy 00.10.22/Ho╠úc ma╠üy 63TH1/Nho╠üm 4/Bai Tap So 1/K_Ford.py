import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error,r2_score
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import numpy as np

# Loading the dataset
data = pd.read_csv('cancer patient data sets.csv')
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle=False)

# Calculate NSE, MAE, and RMSE
def calculate_metrics(y_true, y_pred):
    nse = 1 - (np.sum((y_true - y_pred) ** 2) / np.sum((y_true - np.mean(y_true)) ** 2))
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    return nse, mae, rmse

min_error = float('inf')
k = 3
kf = KFold(n_splits=k, random_state=None)

for train_index, validation_index in kf.split(dt_Train):
    X_train, X_validation = dt_Train.iloc[train_index, :23], dt_Train.iloc[validation_index, :23]
    y_train, y_validation = dt_Train.iloc[train_index, 23], dt_Train.iloc[validation_index, 23]

    lr = LinearRegression()
    lr.fit(X_train, y_train)
    y_train_pred = lr.predict(X_train)
    y_validation_pred = lr.predict(X_validation)
    
    nse_train, mae_train, rmse_train = calculate_metrics(np.array(y_train), y_train_pred)
    nse_validation, mae_validation, rmse_validation = calculate_metrics(np.array(y_validation), y_validation_pred)
    
    sum_error = mae_train + mae_validation
    
    if sum_error < min_error:
        min_error = sum_error
        best_regr = lr

y_test_pred = best_regr.predict(dt_Test.iloc[:, :23])
y_test = np.array(dt_Test.iloc[:, 23])

nse_test, mae_test, rmse_test = calculate_metrics(y_test, y_test_pred)
print("Measure for K_Fold:")
print("Coefficient of Determination (R-squared): ", r2_score(y_test, y_test_pred))
print("Normalized Squared Error (NSE) on Test Set:", nse_test)
print("Mean Absolute Error (MAE) on Test Set:", mae_test)
print("Root Mean Squared Error (RMSE) on Test Set:", rmse_test)

print("Actual vs. Predicted vs. Absolute Error of K_Ford")
for i in range(0, len(y_test)):
    print(y_test[i], "  ", y_test_pred[i], "  ", abs(y_test[i] - y_test_pred[i]))

print("Actual vs. Predicted vs. Absolute Error of Ridge")
for i in range(0, len(y_Test)):
    print("%.2f" % y[i], " ", y_pred2[i], " ", abs(y[i] - y_pred2[i]))
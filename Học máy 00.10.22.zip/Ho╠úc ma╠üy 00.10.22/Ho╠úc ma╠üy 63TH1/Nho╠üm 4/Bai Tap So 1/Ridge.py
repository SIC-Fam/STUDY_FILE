import pandas as pd
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.linear_model import Ridge
from sklearn.model_selection import train_test_split
import numpy as np

data = pd.read_csv('cancer patient data sets.csv')

dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle=True)

X_Train = dt_Train.iloc[:, :23]  # Select columns 0-22
y_Train = dt_Train.iloc[:, -1]  # Select the last column
X_Test = dt_Test.iloc[:, :23]  # Select columns 0-22
y_Test = dt_Test.iloc[:, -1]  # Select the last column

# Ridge regression
clf = Ridge(alpha=1, max_iter=1000, tol=0.00001).fit(X_Train, y_Train)   # Train the Ridge model
y_pred2 = clf.predict(X_Test)  

y = np.array(y_Test)
print("Measure for Ridge:")
print("Coefficient of Determination (R-squared): ", r2_score(y_Test, y_pred2))

# Calculate NSE
sse = np.sum((y_Test - y_pred2) ** 2)
sst = np.sum((y_Test - np.mean(y_Test)) ** 2)
nse = 1 - (sse / sst)
print("Normalized Squared Error (NSE): ", nse)

# Calculate MAE
mae = mean_absolute_error(y_Test, y_pred2)
print("Mean Absolute Error (MAE): ", mae)

# Calculate RMSE
rmse = np.sqrt(mean_squared_error(y_Test, y_pred2))
print("Root Mean Squared Error (RMSE): ", rmse)

print("Actual vs. Predicted vs. Absolute Error of Ridge")
for i in range(0, len(y_Test)):
    print("%.2f" % y[i], " ", y_pred2[i], " ", abs(y[i] - y_pred2[i]))

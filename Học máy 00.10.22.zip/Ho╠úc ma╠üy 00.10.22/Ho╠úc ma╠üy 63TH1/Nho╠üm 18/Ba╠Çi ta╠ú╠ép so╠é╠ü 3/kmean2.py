from sklearn.model_selection import train_test_split
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score
import pandas as pd
import numpy as np
from sklearn import preprocessing 

df = pd.read_csv("C:\\Users\\ASUS\\Downloads\\employee2.csv")

le = preprocessing.LabelEncoder()
data = df.apply(le.fit_transform)

dt_Train, dt_Test = train_test_split(data, test_size=0.1, shuffle=True)

kmeans = KMeans(n_clusters=2, init="random", n_init=9, max_iter=350, random_state=40).fit(dt_Train)
y_pred = kmeans.predict(dt_Test)
labels = kmeans.labels_
centers = kmeans.cluster_centers_

print('Chia nhóm:', labels)
print('Tâm:', centers)


#form
form = Tk()
form.title("Dự đoán phân nhóm nhân viên:")
form.geometry("1200x600")

EducationOptions =['Bachelors', 'Masters','PHD']
JoningyearOptions = ['2012','2013','2014','2015','2016','2017','2018']
CityOptions = ['Bangalore','Pune','New Delhi']
PaymentTierOptions=['1','2','3']
#age
GenderOptions =['Male', 'Female']
EverBenchedOptions = ['No', 'Yes']
ExperienceOptions = ['0','1','2','3','4','5']
LeaveOrNotOptions = ['0','1']



lable_ten = Label(form, text = "Nhập thông tin nhan vien", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)

lable_age = Label(form, text = "Tuổi:")
lable_age.grid(row = 2, column = 1, padx = 40, pady = 10)
textbox_age = Entry(form)
textbox_age.grid(row = 2, column = 2)


lable_education = Label(form, text = "Hoc van")
lable_education.grid(row = 2, column = 3, pady = 10, padx = 40)
comboBox_education = ttk.Combobox(form, values=EducationOptions)
comboBox_education.grid(row=2, column=4)

lable_jyear = Label(form, text = "Nam vao lam")
lable_jyear.grid(row = 3, column = 1,pady = 10, padx = 40)
comboBox_jyear = ttk.Combobox(form, values=JoningyearOptions)
comboBox_jyear.grid(row=3, column=2)


lable_city = Label(form, text = "thanh pho")
lable_city.grid(row = 3, column = 3, pady = 10, padx = 40)
comboBox_city = ttk.Combobox(form, values=CityOptions)
comboBox_city.grid(row=3, column=4)


lable_pment = Label(form, text = "He so luong")
lable_pment.grid(row = 4, column = 1, pady = 10, padx = 40)
comboBox_pment = ttk.Combobox(form, values=PaymentTierOptions)
comboBox_pment.grid(row=4, column=2)

lable_bench = Label(form, text = "Da thuc tap chua")
lable_bench.grid(row = 4, column = 3, pady = 10, padx = 40 )
comboBox_bench = ttk.Combobox(form, values=EverBenchedOptions)
comboBox_bench.grid(row=4, column=4)

lable_year = Label(form, text = "Nam kinh nghiem")
lable_year.grid(row = 5, column = 1, pady = 10, padx = 40 )
comboBox_year = ttk.Combobox(form, values=ExperienceOptions)
comboBox_year.grid(row=5, column=2)

lable_status = Label(form, text = "Tinh trang lam viec")
lable_status.grid(row = 5, column = 3, pady = 10, padx = 40 )
comboBox_status = ttk.Combobox(form, values=LeaveOrNotOptions)
comboBox_status.grid(row=5, column=4)

lable_gender = Label(form, text = "Gioi tinh")
lable_gender.grid(row = 6, column = 1, pady = 10, padx = 40)
comboBox_gender = ttk.Combobox(form, values=GenderOptions)
comboBox_gender.grid(row=6, column=2)

def dudoan():
    if (textbox_age.get() == '' or comboBox_gender.get() =='' or comboBox_jyear.get() =='' or comboBox_pment.get() =='' or comboBox_bench.get() == '' or comboBox_year.get() =='' or comboBox_status.get() ==''or comboBox_city.get() ==''):
        messagebox.showerror("Lỗi", "Bạn cần nhập đầy đủ thông tin")
    else:
        age = float(textbox_age.get())
        education = le.fit_transform([comboBox_jyear.get() ])[0]
        jyear = le.fit_transform([comboBox_jyear.get() ])[0]
        city = le.fit_transform([comboBox_city.get()])[0]
        pment = le.fit_transform([comboBox_pment.get()])[0]
        bench = le.fit_transform([comboBox_bench.get()  ])[0]
        year = le.fit_transform([comboBox_year.get()  ])[0]
        status = le.fit_transform([comboBox_status.get()  ])[0]
        gender = le.fit_transform(['M' if comboBox_gender.get() == 'Male' else 'F'])[0]
        predict =np.array([age, education, jyear, city,year, pment, bench, year, status, gender]).reshape(1,-1)
        y_kqua = kmeans.predict(predict)
        lbl.configure(text=y_kqua[0])

acc = Label(form, text="Độ đo đánh giá chất lượng mô hình", font=("Arial Bold", 10), fg="red", pady=20)
acc.grid(column=1, row=9)
silhouette = Label(form, text="Silhouette Score:",anchor='w')
silhouette.grid(column=2, row=9)
Label(form, text=silhouette_score(dt_Test, y_pred),anchor='e').grid(column=3, row=9)

davies = Label(form, text=f"Chỉ số Davies Bouldin:", anchor='w')
davies.grid(column=2, row=10)
Label(form, text=davies_bouldin_score(dt_Test, y_pred), anchor='e').grid(column=3, row=10)
    

button_cart = Button(form, text = 'Kết quả dự đoán theo KMeans', command = dudoan)
button_cart.grid(row = 11, column = 1, pady = 20)
lbl = Label(form, text="...", pady=10)
lbl.grid(column=2, row=11)

form.mainloop()
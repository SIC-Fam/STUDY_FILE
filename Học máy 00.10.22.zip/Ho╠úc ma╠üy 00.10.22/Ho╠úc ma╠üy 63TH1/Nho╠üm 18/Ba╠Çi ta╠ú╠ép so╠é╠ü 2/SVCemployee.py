import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import Perceptron 
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import precision_score,mean_absolute_error, recall_score, f1_score
df = pd.read_csv('C:\\Users\\ASUS\\Downloads\\employee2.csv') 
X_data = np.array(df[['Education', 'JoiningYear', 'City', 'PaymentTier', 'Age', 'Gender','EverBenched', 'ExperienceInCurrentDomain','LeaveOrNot']].values)

from sklearn import preprocessing 
data = pd.read_csv('C:\\Users\\ASUS\\Downloads\\employee2.csv') 
le=preprocessing.LabelEncoder() 
data=data.apply(le.fit_transform) 
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True) 
X_train = dt_Train.drop(['Stt','LeaveOrNot'], axis = 1) 
y_train = dt_Train['LeaveOrNot'] 
X_test= dt_Test.drop(['Stt','LeaveOrNot'], axis = 1)
y_test= dt_Test['LeaveOrNot']
y_test = np.array(y_test)
print(X_train)
print(y_train)
print(X_test)


clf = make_pipeline(StandardScaler(),SVC(gamma='auto',cache_size=500))  
clf.fit(X_train, y_train) 
y_predict = clf.predict(X_test) 
count = 0 
for i in range(0,len(y_predict)) : 
    if(y_test[i] == y_predict[i]) : 
        count = count +1 
print('Ty le du doan dung : ', count/len(y_predict))
print("Độ đo Precision:",precision_score(y_test, y_predict, average ='macro')) # Precision (độ chuẩn xác) tỉ lệ số điểm Positive (dự đoán đúng) / tổng số điểm mô hình dự đoán là Positive
#càng cao càng tốt tức là tất cả số điểm đều đúng 
print("Độ đo Recall:",recall_score(y_test, y_predict, average ='micro')) #Recall tỉ lệ số điểm Positive mô hình dự đoán đúng trên tổng số điểm được gán nhãn là Positive ban đầu
#Recall càng cao, tức là số điểm là positive bị bỏ sót càng ít
#micro tbc của precision và recall theo các lớp.
print("Độ đo F1:", f1_score(y_test, y_predict, average='macro'))
mae = mean_absolute_error(y_test, y_predict)
print('Tỉ lệ dự đoán sai: %f' % mae)



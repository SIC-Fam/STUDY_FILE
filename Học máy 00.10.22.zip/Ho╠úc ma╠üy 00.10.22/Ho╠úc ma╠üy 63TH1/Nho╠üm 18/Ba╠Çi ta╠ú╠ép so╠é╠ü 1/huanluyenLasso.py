import pandas as pd
from sklearn.metrics import r2_score #đánh giá chất lượng của mô hình hồi quy
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split #
from sklearn import linear_model
import numpy as np
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error


data=pd.read_csv("D:\\bmi.csv")

dt_Train,dt_Test = train_test_split(data,test_size=0.3,shuffle=True) #tách dữ liệu thành 2 tập train và test, test_size 30% 70% là train data
#shuffle=True thì là lấy ngẫu nhiên các dòng trong dữ liệu (chuẩn hơn với tất cả các quận)

X_Train=dt_Train.iloc[:,:3] #lấy từ cột 0 đến cột 2 làm dữ liệu cho tập huấn luyện
# print(X_Train.to_string())
y_Train=dt_Train.iloc[:,3] # Chọn cột thứ 3 làm biến mục tiêu cho tập huấn luyện 
# print(y_Train.to_string())
X_Test=dt_Test.iloc[:,:3] #lấy từ cột 0 đến cột 2 làm dữ liệu cho tập kiểm tra
y_Test=dt_Test.iloc[:,3] #Chọn cột thứ 3 làm biến mục tiêu cho tập kiểm tra 

lasso = linear_model.Lasso(alpha=0.05).fit(X_Train, y_Train)   #Huan luyen lasso
y_pred=lasso.predict(X_Test)  
y=np.array(y_Test)

# In giá trị thực, giá trị dự đoán và hiệu giữa chúng
print("So sánh giá trị thực và dự đoán:")
for i in range(0, len(y)):
    diff = abs(y[i] - y_pred[i])
    print("%.2f, %.2f, %.2f" % (y[i], y_pred[i], diff))

def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))
def MAE(y_test, y_pred):
    return mean_absolute_error(y_test, y_pred)
def RMSE(y_test, y_pred):
    return mean_squared_error(y_test, y_pred, squared=False)


print("NSE: ", NSE(y_Test,y_pred))
print ('Hệ số xác định R2: %.2f' %  r2_score(y_Test,y_pred)) 
print('MAE:', MAE(y_Test,y_pred))
print('RMSE:', RMSE(y_Test,y_pred))  
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
from sklearn.metrics import accuracy_score, precision_score, f1_score, recall_score
import numpy as np

# đọc file 
data = pd.read_csv('gender_classification_v7.csv')

# Preprocessing
data["gender"].replace({"Male": 0, "Female":1}, inplace=True)

# print(data)
X = data.iloc[:, :-1]
Y = data.iloc[:, -1]

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.3, shuffle=False)


pla = Perceptron(max_iter=500)
pla.fit(X_train, y_train)

y_pred = pla.predict(X_test)

test_score_accuracy = accuracy_score(y_test, y_pred)
test_score_precision = precision_score(y_test, y_pred)
test_score_recall = recall_score(y_test, y_pred)
test_score_f1 = f1_score(y_test, y_pred)

print("Ti le doan dung accuracy_score: ", test_score_accuracy)
print("Ti le doan dung precision_score: ", test_score_precision)
print("Ti le doan dung recall_score: ", test_score_recall)
print("Ti le doan dung f1_score: ", test_score_f1)

print("Ti le doan sai accuracy_score: ", 1 - test_score_accuracy)
print("Ti le doan sai precision_score: ", 1 - test_score_precision)
print("Ti le doan sai recall_score: ", 1 - test_score_recall)
print("Ti le doan sai f1_score: ", 1 - test_score_f1)
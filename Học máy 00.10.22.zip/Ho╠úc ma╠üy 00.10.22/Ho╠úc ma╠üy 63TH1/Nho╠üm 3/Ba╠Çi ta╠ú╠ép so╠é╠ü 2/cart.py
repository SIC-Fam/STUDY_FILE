import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score,f1_score,precision_score,recall_score

# đọc file 
data = pd.read_csv('gender_classification_v7.csv')

# Preprocessing
data["gender"].replace({"Male": 0, "Female":1}, inplace=True)

# print(data)
X = data.iloc[:, :-1]
Y = data.iloc[:, -1]

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.3, shuffle=True)

gini = DecisionTreeClassifier(criterion="gini",max_depth=8, ccp_alpha=0.001)
# 
gini.fit(X_train, y_train)

y_pred_gini = gini.predict(X_test)

test_score_accuracy = accuracy_score(y_test, y_pred_gini)
test_score_precision = precision_score(y_test, y_pred_gini)
test_score_recall = recall_score(y_test, y_pred_gini)
test_score_f1 = f1_score(y_test, y_pred_gini)

print("Tỉ lệ đoán đúng accuracy : ", test_score_accuracy)
print("Tỉ lệ đoán sai accuracy : ", 1-test_score_accuracy)
print("Tỉ lệ đoán đúng precision : ", test_score_precision)
print("Tỉ lệ đoán sai precision : ", 1-test_score_precision)
print("Tỉ lệ đoán đúng recall : ", test_score_recall)
print("Tỉ lệ đoán sai recall : ", 1-test_score_recall)
print("Tỉ lệ đoán đúng f1 : ", test_score_f1)
print("Tỉ lệ đoán sai f1 : ", 1-test_score_f1)

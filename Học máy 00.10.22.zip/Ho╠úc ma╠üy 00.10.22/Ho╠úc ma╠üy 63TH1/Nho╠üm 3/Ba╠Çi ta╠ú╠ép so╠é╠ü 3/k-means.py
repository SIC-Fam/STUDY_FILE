from tkinter import*
from tkinter import messagebox
from sklearn.cluster import KMeans
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import silhouette_score,davies_bouldin_score

# đọc file 
data = pd.read_csv('seeds.csv')
X = data.iloc[:, :-1].values
Y = data.iloc[:, -1]
X_train, X_test, y_train, y_test = train_test_split(X,Y, test_size=0.1, shuffle=True)

#Tạo một cửa sổ mới
window=Tk()  
#Thêm tiêu đề cho cửa sổ
window.title('Dự đoán loại hạt lúa mì')
#Đặt kích thước của cửa sổ
window.geometry("400x500")

label_top = Label(window, text = "Nhập thông tin cho hạt lúa mì:", font=("Arial Bold", 10), fg="red")
label_top.grid(row = 1, column = 1, padx = 20, pady = 5)

# diện tích
lable_area = Label(window, text = "Diện tích: ")
lable_area.grid(row = 2, column = 1, padx = 40, pady = 10)
textbox_area = Entry(window)
textbox_area.grid(row = 2, column = 2)
# chu vi
lable_perimeter = Label(window, text = "Chu vi: ")
lable_perimeter.grid(row = 3, column = 1, padx = 40, pady = 10)
textbox_perimeter = Entry(window)
textbox_perimeter.grid(row = 3, column = 2)
# dộ nhồi
lable_compactness = Label(window, text = "Độ nhồi: ")
lable_compactness.grid(row = 4, column = 1, padx = 40, pady = 10)
textbox_compactness = Entry(window)
textbox_compactness.grid(row = 4, column = 2)
# chiều dài
lable_length = Label(window, text = "Chiều dài: ")
lable_length.grid(row = 5, column = 1, padx = 40, pady = 10)
textbox_length = Entry(window)
textbox_length.grid(row = 5, column = 2)
# chiều rộng
lable_width = Label(window, text = "Chiều rộng: ")
lable_width.grid(row = 6, column = 1, padx = 40, pady = 10)
textbox_width = Entry(window)
textbox_width.grid(row = 6, column = 2)
# Hệ số không đối xứng
lable_asymmetry = Label(window, text = "Hệ số không đối xứng: ")
lable_asymmetry.grid(row = 7, column = 1, padx = 40, pady = 10)
textbox_asymmetry = Entry(window)
textbox_asymmetry.grid(row = 7, column = 2)
# Chiều dài của rãnh hạt lúa mì
lable_groove = Label(window, text = "Chiều dài của rãnh hạt lúa: ")
lable_groove.grid(row = 8, column = 1, padx = 40, pady = 10)
textbox_groove = Entry(window)
textbox_groove.grid(row = 8, column = 2)

kmeans = KMeans(n_clusters=3,init="k-means++", n_init=100, max_iter=1000).fit(X_train)

labels = kmeans.labels_
y_pred = kmeans.predict(X_test)
# print(X_test,y_pred, labels)

# Đánh giá mô hình phân cụm bằng Silhouette score và Davies-Bouldin score
silhouette = silhouette_score(X_test, y_pred)
davies_bouldin = davies_bouldin_score(X_test, y_pred)

def predict():
    area = textbox_area.get() 
    perimeter = textbox_compactness.get()
    compactness = textbox_compactness.get()
    length = textbox_length.get()
    width = textbox_width.get()
    asymmetry = textbox_asymmetry.get()
    groove = textbox_groove.get()

    if((area == '') or (perimeter == '') or (compactness == '') or (length == '') or (width == '')or (asymmetry == '') or (groove == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        input = np.array([area,perimeter,compactness,length,width,asymmetry,groove]).reshape(1,-1)
        # print(input.reshape(1,-1))
        output = kmeans.predict(input)
        # print("Kết quả: ",output)
        label_result = Label(window)
        label_result.grid(column=1, row =10)
        label_result.configure(text = "Output: "+str(output[0]))

#Thêm một nút nhấn Click Me
btn = Button(window, text="Xem kết quả", bg="blue", fg="white", command=predict)
btn.grid(row = 9, column = 1, padx = 30)

label_silhouette = Label(window, text="silhouette")
label_silhouette.grid(row = 11, column=1)
# label_davies_bouldin = Label(window, text="davies_bouldin")
# label_silhouette.grid(row = 11, column=2)
label_silhouette.configure(text="Độ đo: "+'\n'
                           +"Silhouette: "+str(silhouette)+'\n'
                           +"Davies_Bouldin: "+str(davies_bouldin)+'\n')

#Lặp vô tận để hiển thị cửa sổ
window.mainloop()
import pandas as pd
from sklearn.preprocessing import LabelEncoder, RobustScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.linear_model import Ridge
import numpy as np

data = pd.read_csv('laptop_price.csv', encoding="latin-1")
# Remove laptop_ID field and Product field
data.drop(columns=['laptop_ID', 'Product'], inplace=True)

# Preprocessing
feature_cat = ['Company', 'TypeName', 'ScreenResolution', 'Cpu', 'Ram', 'Memory', 'Gpu', 'OpSys', 'Weight']
le = LabelEncoder()
data[feature_cat] = data[feature_cat].apply(le.fit_transform)

X = data.iloc[:, :-1]
Y = data.iloc[:,  -1]
scaler = RobustScaler()
X = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.3, shuffle=False)

reg = Ridge(alpha=0.1)
reg.fit(X_train, y_train)

y_pred = reg.predict(X_test)
print("Coefficient of determintion Ridge: ",r2_score(y_test,y_pred))

y=np.array(y_test)
print("Thuc te          Du doan         Chenh lech")
for i in range(0,len(y)):
    print("%.2f" % y[i], "   ", y_pred[i], "   ", abs(y[i]-y_pred[i]))
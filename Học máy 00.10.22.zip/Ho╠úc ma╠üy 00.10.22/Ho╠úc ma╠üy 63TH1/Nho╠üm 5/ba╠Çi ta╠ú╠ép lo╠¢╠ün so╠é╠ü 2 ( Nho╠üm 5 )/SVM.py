import pandas as pd
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler

data = pd.read_csv('./DataSet/Credit-Score-Classification-Dataset.csv') 

X_data = np.array(data[['Age','Gender', 'Income', 'Education', 'Marital Status','Number of Children','Home Ownership']].values)
y_data = np.array(data['Credit Score'].values)

def data_encoder(X) : 
    for i, j in enumerate(X) : 
        for k in range(0, 7) : 
            if j[k]== "Male":
                j[k]=0 
            elif j[k]=="Female":
                j[k]=1
            elif j[k]=="Bachelor's Degree":
                j[k]=2
            elif j[k]=="Master's Degree":
                j[k]=3
            elif j[k]=="Doctorate":
                j[k]=4
            elif j[k]=="High School Diploma":
                j[k]=5
            elif j[k]=="Associate's Degree":
                j[k]=6
            elif j[k]=="Married":
                j[k]=7
            elif j[k]=="Single":
                j[k]=8
            elif j[k]=="Owned":
                j[k]=9
            elif j[k]=="Rented":
                j[k]=10
    return X

X_data = data_encoder(X_data)

# Chia dữ liệu thành tập huấn luyện và tập kiểm tra, với tỷ lệ 70% cho tập huấn luyện và 30% cho tập kiểm tra. Dữ liệu không được xáo trộn trước khi chia.
X_train, X_test, y_train, y_test = train_test_split(X_data, y_data, test_size=0.3, shuffle=True)

# Xây dựng mô hình SVM
clf = make_pipeline(StandardScaler(), SVC(C=4.5))
# Huấn luyện mô hình SVM trên tập huấn luyện.
clf.fit(X_train, y_train)

# Dự đoán nhãn cho tập kiểm tra.
y_pred =clf.predict(X_test)

# Tính độ chính xác của mô hình.
accuracy = accuracy_score(y_test, y_pred)
print("Ty le du doan dung :", accuracy)
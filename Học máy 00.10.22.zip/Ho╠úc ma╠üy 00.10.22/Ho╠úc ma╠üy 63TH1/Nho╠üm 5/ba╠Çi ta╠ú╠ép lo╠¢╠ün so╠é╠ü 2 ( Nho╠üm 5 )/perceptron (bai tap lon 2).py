import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import Perceptron 
df = pd.read_csv('./DataSet/Credit-Score-Classification-Dataset.csv') 
X_data = np.array(df[[  'Age','Gender', 'Income', 'Education', 'Marital Status','Number of Children','Home Ownership','Credit Score']].values)

def data_encoder(X) : 
    for i, j in enumerate(X) : 
        for k in range(0, 7) : 
            if j[k]== "Male":
                j[k]=0
            elif j[k]=="Female":
                j[k]=1
            elif j[k]=="Bachelor's Degree":
                j[k]=2
            elif j[k]=="Master's Degree":
                j[k]=3
            elif j[k]=="Doctorate":
                j[k]=4
            elif j[k]=="High School Diploma":
                j[k]=5
            elif j[k]=="Associate's Degree":
                j[k]=6
            elif j[k]=="Married":
                j[k]=7
            elif j[k]=="Single":
                j[k]=8
            elif j[k]=="Owned":
                j[k]=9
            elif j[k]=="Rented":
                j[k]=10
        return X
data=data_encoder(X_data)    

from sklearn import preprocessing 
data = pd.read_csv('./DataSet/Credit-Score-Classification-Dataset.csv') 
le=preprocessing.LabelEncoder() 
data=data.apply(le.fit_transform) 
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True) 
X_train = dt_Train.drop(['Age','Credit Score'], axis = 1) 
y_train = dt_Train['Credit Score'] 
X_test= dt_Test.drop(['Age','Credit Score'], axis = 1)
y_test= dt_Test['Credit Score']
y_test = np.array(y_test)
print(X_train)
print(y_train)
print(X_test)


# dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True) 
# print(dt_Train) 
# X_train = dt_Train[:, :6] 
# y_train = dt_Train[:,6] 
# X_test= dt_Test[:,:6] 
# y_test= dt_Test[:,6] 
pla = Perceptron() 
pla.fit(X_train, y_train) 
y_predict = pla.predict(X_test) 
count = 0 
for i in range(0,len(y_predict)) : 
    if(y_test[i] == y_predict[i]) : 
        count = count +1 
print('Ty le du doan dung : ', count/len(y_predict))



# from sklearn import preprocessing 
# data = pd.read_csv('weather.csv') 
# le=preprocessing.LabelEncoder() 
# data-data.apply(le.fit_transform) 
# dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True) 
# X_train = dt_Train.drop(['play'], axis = 1) 
# y_train = dt_Train['play'] 
# X_test= dt_Test.drop(['play'], axis = 1)
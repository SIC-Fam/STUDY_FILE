import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split 
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn import preprocessing

data = pd.read_csv('anemia.csv') 
le = preprocessing.LabelEncoder()   #mã hóa các ký tự chữ thành số
data = data.apply(le.fit_transform) #apply các ký tự đã mã hóa vào tập dữ liệu
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True) #chia tập dữ liệu thành 2 phần
X_train = dt_Train.drop('Result', axis=1)         #lấy gtri của các cột trừ cột brand
Y_train = dt_Train.Result                 #lấy gtri của cột brand
X_test = dt_Test.drop('Result', axis=1)            #lấy gtri của các cột trừ cột brand
Y_test = dt_Test.Result                    #lấy gtri của cột brand
Y_test=np.array(Y_test)               #ép tập về dạng mảng
clf = DecisionTreeClassifier(criterion='gini',splitter='random', min_samples_leaf=5).fit(X_train, Y_train) 
y_predict = clf.predict(X_test) 

print ('Precision: ', precision_score(Y_test,y_predict, average='micro')) 
print ('Recall: ', recall_score(Y_test,y_predict, average='micro')) 
print ('F1: ' ,f1_score(Y_test,y_predict, average='micro'))
print('Accuracy: ',accuracy_score(Y_test, y_predict))
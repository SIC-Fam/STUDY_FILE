import pandas as pd
import numpy as np
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Lasso
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error

data = pd.read_csv('DATA_Heart.csv')
dt_Train,dt_Test = train_test_split(data, test_size=0.3, shuffle=False)


def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))
def MAE(y_test, y_pred):
    return mean_absolute_error(y_test, y_pred)
def RMSE(y_test, y_pred):
    return mean_squared_error(y_test, y_pred, squared=False)

X_Train = dt_Train.iloc[:, :12]
Y_Train = dt_Train.iloc[:, 12]
X_Test = dt_Test.iloc[:, :12]
Y_Test = dt_Test.iloc[:, 12]

reg = Lasso().fit(X_Train, Y_Train)
y_pred = reg.predict(X_Test)
y = np.array(Y_Test)

# print("Thuc te   Du doan      Chenh lech")
# for i in range(0,len(y)):
#     print("%.5f" % y[i], "   ", y_pred[i], "   ", abs(y[i]-y_pred[i]))

print("NSE: ", NSE(Y_Test, y_pred))
print ('R2: %.2f' %  r2_score(Y_Test,y_pred)) 
print('MAE:', MAE(Y_Test,y_pred))
print('RMSE:', RMSE(Y_Test, y_pred))
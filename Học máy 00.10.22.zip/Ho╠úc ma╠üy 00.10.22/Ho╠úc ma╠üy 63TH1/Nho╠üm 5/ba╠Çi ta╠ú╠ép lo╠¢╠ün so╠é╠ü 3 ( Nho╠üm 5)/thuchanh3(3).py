from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import davies_bouldin_score
from sklearn.metrics import silhouette_score
from sklearn.model_selection import train_test_split
def get_data_form():
    mean_dist_day = Textbox_mean_dist_day.get()
    mean_over_speed_perc = Textbox_mean_over_speed.get()

    if mean_dist_day == '' or mean_over_speed_perc == '':
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
        return
        

    df = pd.read_csv('driver-data.csv')
    
    # Chia tập dữ liệu thành tập huấn luyện và tập kiểm tra
    dt_Train, dt_Test = train_test_split(df, test_size=0.1, shuffle=True)
    X_train = np.array(dt_Train)
    X_test = np.array(dt_Test)
    #silhouette------------------------------------------------------------------------------
    kmeans = KMeans(n_clusters=4, n_init='auto', random_state=0).fit(X_train)
    predict = kmeans.predict(X_test)

    # Dự đoán nhãn cho tập test
    y_predict = kmeans.predict(X_test)
    silhouette_avg = silhouette_score(X_test, y_predict)
    print("Silhouette score:", silhouette_avg)
    davies_bouldin = davies_bouldin_score(X_test, y_predict)
    print("Davies bouldin score:", davies_bouldin)
    label_mean_dist_day_dudoan = Label(form)
    label_mean_dist_day_silhouette_avg = Label(form)
    label_mean_dist_day_davies_bouldin = Label(form)
    label_mean_dist_day_dudoan = Label(form, text="Nhãn dự đoán là: ")
    label_mean_dist_day_dudoan.grid(row=4, column=1, pady=10)
    label_mean_dist_day_ketqua_dudoan = Label(form)
    label_mean_dist_day_ketqua_dudoan.configure(text=predict[0])
    label_mean_dist_day_ketqua_dudoan.grid(row=4, column=2, pady=10)
   
  
   
    label_sit = Label(form, text="Silhouette score: ")
    label_sit.grid(row=5, column=1, pady=10)
    label_mean_dist_day_silhouette_avg.configure(text=str(silhouette_avg))
    label_mean_dist_day_silhouette_avg.grid(row=5, column=2, pady=10)
    label_da = Label(form, text="Davies bouldin score: ")
    label_da.grid(row=6, column=1, pady=10)
    label_mean_dist_day_davies_bouldin.configure(text=str(davies_bouldin))
    label_mean_dist_day_davies_bouldin.grid(row=6, column=2, pady=10)
    


#form
form = Tk()
form.title("Dự đoán phân nhóm tài xế:")
form.geometry("1000x400")



label_mean_dist_day = Label(form, text="Nhập quãng đường tài xế đã đi: ")
label_mean_dist_day.grid(row=1, column=1, pady=10)
Textbox_mean_dist_day = Entry(form)
Textbox_mean_dist_day.grid(row=1, column=2, pady=10)

label_mean_over_speed = Label(form, text="Nhập phần trăm thời gian tài xế đi vượt tốc độ cho phép: ")
label_mean_over_speed.grid(row=2, column=1, pady=10)
Textbox_mean_over_speed = Entry(form)
Textbox_mean_over_speed.grid(row=2, column=2, pady=10)

button = ttk.Button(form, text="Dự đoán", command=get_data_form)
button.grid(row=3, column=2, pady=10)



form.mainloop()
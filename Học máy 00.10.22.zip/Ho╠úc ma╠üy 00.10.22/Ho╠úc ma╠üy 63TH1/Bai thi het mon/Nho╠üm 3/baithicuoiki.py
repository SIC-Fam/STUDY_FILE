from tkinter import *
from tkinter import messagebox
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.linear_model import Perceptron 
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import accuracy_score

df = pd.read_csv("D:\\kqhoctap2.csv")
X = np.array(df[['Hindi','English','Science','Maths','History','Geograpgy',]].values)    
y = np.array(df['Results'])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3 , shuffle = TRUE)


#Perceptron
pla = Perceptron(penalty='l2',max_iter=3000,random_state=3) 
pla.fit(X_train, y_train) 



#SVC
clf = make_pipeline(StandardScaler(),SVC(gamma='auto',cache_size=500))  
clf.fit(X_train, y_train) 
y_SVC = clf.predict(X_test) 




#form
form = Tk()
form.title("Dự đoán khả năng vượt qua bài kiểm tra:")
form.geometry("1500x1000")


lable_ten = Label(form, text = "Nhập thông tin cho học sinh:(Điểm 0-100)", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)

lable_Hindi = Label(form, text = " Điểm môn tiếng Hindi:")
lable_Hindi.grid(row = 2, column = 1, padx = 40, pady = 10)
textbox_Hindi = Entry(form)
textbox_Hindi.grid(row = 2, column = 2)

lable_English = Label(form, text = "Điểm môn tiếng Anh:")
lable_English.grid(row = 3, column = 1, pady = 10)
textbox_English = Entry(form)
textbox_English.grid(row = 3, column = 2)

lable_Science = Label(form, text = "Điểm môn khoa học:")
lable_Science.grid(row = 4, column = 1,pady = 10)
textbox_Science = Entry(form)
textbox_Science.grid(row = 4, column = 2)

lable_Maths = Label(form, text = "Điểm môn toán:")
lable_Maths.grid(row = 5, column = 1, pady = 10)
textbox_Maths = Entry(form)
textbox_Maths.grid(row = 5, column = 2)

lable_History = Label(form, text = "Điểm môn lịch sử:")
lable_History.grid(row = 6, column = 1, pady = 10 )
textbox_History = Entry(form)
textbox_History.grid(row = 6, column = 2)

lable_Geograpgy = Label(form, text = "Điểm môn địa lý:")
lable_Geograpgy.grid(row = 7, column = 1, pady = 10 )
textbox_Geograpgy = Entry(form)
textbox_Geograpgy.grid(row = 7, column = 2)



#perceptron
y_perceptron = pla.predict(X_test) 

#dudoanperceptrontheotest
lbl1 = Label(form)
lbl1.grid(column=1, row=8)
lbl1.configure(text="Tỉ lệ dự đoán đúng của Perceptron: "+'\n'
                           +"Precision: "+str(precision_score(y_test, y_perceptron, average='macro')*100)+"%"+'\n'
                           +"Recall: "+str(recall_score(y_test, y_perceptron, average='macro')*100)+"%"+'\n'
                           +"F1-score: "+str(f1_score(y_test, y_perceptron, average='macro')*100)+"%"+'\n')


def khanangperceptron():
    y_perceptron = pla.predict(X_test)
    dem=0
    for i in range (len(y_perceptron)):
        if(y_perceptron[i] == y_test[i]):
            dem= dem+1
    count = (dem/len(y_perceptron))*100
    lbl1.configure(text= count)
button_cart1 = Button(form, text = 'Khả năng dự đoán đúng ', command = khanangperceptron)
button_cart1.grid(row = 9, column = 1, padx = 30)
lbl1 = Label(form, text="...")
lbl1.grid(column=2, row=9)


#SVC
y_SVC = clf.predict(X_test)
lbl3 = Label(form)
lbl3.grid(column=3, row=8)
lbl3.configure(text="Tỉ lệ dự đoán đúng của SVC: "+'\n'
                           +"Precision: "+str(precision_score(y_test, y_SVC, average='macro')*100)+"%"+'\n'
                           +"Recall: "+str(recall_score(y_test, y_SVC, average='macro')*100)+"%"+'\n'
                           +"F1-score: "+str(f1_score(y_test, y_SVC, average='macro')*100)+"%"+'\n')
def dudoanSVC():
    Hindi = textbox_Hindi.get()
    English = textbox_English.get()
    Science = textbox_Science.get()
    Maths = textbox_Maths.get()
    History =textbox_History.get()
    Geograpgy =textbox_Geograpgy.get()
    if((Hindi == '') or (English == '') or (Science == '') or (Maths == '') or (History == '')or (Geograpgy == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([Hindi,English,Science,Maths,History,Geograpgy]).reshape(1, -1)
        y_kqua = clf.predict(X_dudoan)
        lbl2.configure(text= y_kqua)
    
button_id3 = Button(form, text = 'Kết quả dự đoán theo ID3', command = dudoanSVC)
button_id3.grid(row = 9, column = 3, pady = 20)
lbl2 = Label(form, text="...")
lbl2.grid(column=4, row=9)

def khanangSVC():
    y_SVC = clf.predict(X_test)
    dem=0
    for i in range (len(y_SVC)):
        if(y_SVC[i] == y_test[i]):
            dem= dem+1
    count = (dem/len(y_SVC))*100
    lbl3.configure(text= count)
button_id31 = Button(form, text = 'Khả năng dự đoán đúng ', command = khanangSVC)
button_id31.grid(row = 10, column = 3, padx = 30)
lbl3 = Label(form, text="...")
lbl3.grid(column=4, row=10)


#Kfold
# Create a KFold cross-validator with K=5
kf = KFold(n_splits=5, shuffle=True, random_state=4)

best_model = None
best_accuracy = 0

for train_index, test_index in kf.split(X):
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]

    # SVC
    clf = make_pipeline(StandardScaler(), SVC(gamma='auto', cache_size=500))
    clf.fit(X_train, y_train)
    y_SVC = clf.predict(X_test)

    # Calculate train accuracy for SVC
    y_train_pred = clf.predict(X_train)
    train_accuracy = accuracy_score(y_train, y_train_pred)

    # Calculate validation accuracy for SVC
    validation_accuracy = accuracy_score(y_test, y_SVC)
    #
    sum_accuracy=validation_accuracy+train_accuracy
    # Compare and choose the best model based on sum accuracy
    if sum_accuracy > best_accuracy:
        best_model = clf
        best_accuracy = sum_accuracy

# best_model now contains the best SVC model based on total accuracy
y_kfold_SVC= best_model.predict(X_test)
lbl4 = Label(form)
lbl4.grid(column=1, row=12)
lbl4.configure(text="Tỉ lệ dự đoán đúng của kfold: " + '\n'
                            + "Precision: " + str(precision_score(y_test, y_kfold_SVC, average='macro') * 100) + "%" + '\n'
                            + "Recall: " + str(recall_score(y_test, y_kfold_SVC, average='macro') * 100) + "%" + '\n'
                            + "F1-score: " + str(f1_score(y_test, y_kfold_SVC, average='macro') * 100) + "%" + '\n'
                            + "Train accuracy: " + str(train_accuracy *100) + "%" + '\n'
                            + "Validation accuracy: " + str(validation_accuracy*100) + "%" + '\n')
                            

def dudoankfold():
    Hindi = textbox_Hindi.get()
    English = textbox_English.get()
    Science = textbox_Science.get()
    Maths = textbox_Maths.get()
    History = textbox_History.get()
    Geograpgy = textbox_Geograpgy.get()
    if (Hindi == '' or English == '' or Science == '' or Maths == '' or History == '' or Geograpgy == ''):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([Hindi, English, Science, Maths, History, Geograpgy]).reshape(1, -1)
        y_kqua = best_model.predict(X_dudoan)
        lbl5.configure(text=y_kqua)

button_id4 = Button(form, text='Kết quả dự đoán theo kfold', command=dudoankfold)
button_id4.grid(row=13, column=1, pady=20)
lbl5 = Label(form, text="...")
lbl5.grid(column=2, row=13)

def khanangkfold():
    y_kfold_SVC = best_model.predict(X_test)
    dem = 0
    for i in range(len(y_kfold_SVC)):
        if (y_kfold_SVC[i] == y_test[i]):
            dem = dem + 1
    count = (dem / len(y_kfold_SVC)) * 100
    lbl4.configure(text=count)

button_id41 = Button(form, text='Khả năng dự đoán đúng ', command=khanangkfold)
button_id41.grid(row=14, column=1, padx=30)
lbl4 = Label(form, text="...")
lbl4.grid(column=2, row=14)

form.mainloop()

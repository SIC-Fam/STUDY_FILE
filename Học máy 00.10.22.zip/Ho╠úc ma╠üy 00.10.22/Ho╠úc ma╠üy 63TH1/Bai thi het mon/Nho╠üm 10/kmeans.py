from sklearn.model_selection import train_test_split 
from sklearn import preprocessing
import pandas as pd
import numpy as np
import random


# Load data
data=pd.read_csv('Customer.csv')
le = preprocessing.LabelEncoder()
data = data.apply(le.fit_transform)
dt_train, dt_test = train_test_split(data, test_size=0.1, shuffle=True)
X_test = np.array(dt_test)


def choncenter(X_test, k):                                   
    return X_test[np.random.choice(X_test.shape[0], k, replace=False)]
def phancum(X_test, centroids, k):
  clusters = {} 
  for i in range(k):
    clusters[i] = []
  for featureset in X_test: 
    khoangcach = [np.linalg.norm(featureset - centroid) for centroid in centroids]
    cluster = khoangcach.index(min(khoangcach))
    clusters[cluster].append(featureset)
  return clusters
  

def has_converged(centers, new_centers):
    return (set([tuple(a) for a in centers]) == 
        set([tuple(a) for a in new_centers]))
        
def update_center(clusters):
  new_centroids = []
  for cluster, data_points in clusters.items():
    new_centroids.append(np.average(data_points,axis=0))
  return new_centroids

# khai báo
# 
max_iter = 10             #số lần lặp tối đa được phép cho thuật toán k-mean
k = 2              
centroids = choncenter(X_test, k)  
for i in range(max_iter):
    clusters = phancum(X_test, centroids, k)
    new_centroids = update_center(clusters)
    if has_converged(centroids, new_centroids):
        print('convered')
        break
    centroids = new_centroids


labels = []
Y = []
for cluster, datapoints in clusters.items():
  for datapoint in datapoints:
    Y.append(datapoint)
    labels.append(cluster)

print(centroids)



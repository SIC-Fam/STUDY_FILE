from tkinter import *
from tkinter import messagebox
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split 
from sklearn import preprocessing
from sklearn.metrics import silhouette_score, davies_bouldin_score
import pandas as pd
import numpy as np


# Load data
data=pd.read_csv('Customer.csv')
le = preprocessing.LabelEncoder()
data = data.apply(le.fit_transform)
dt_train, dt_test = train_test_split(data, test_size=0.1, shuffle=True)
X = np.array(dt_test)

# lựa chọn số cluster tốt nhất
dodo = 0
k = 0          
for i in range(2,10):
    kmeans = KMeans(n_clusters=i,n_init='auto').fit(X)
    y_pred = kmeans.predict(X)
    if (silhouette_score(X, y_pred) > dodo):
        dodo = silhouette_score(X, y_pred)
        k = i   
print("k = ",k)

# Initialize KMeans model

kmeans = KMeans(n_clusters=k, random_state=1, n_init='auto').fit(dt_test)
# random_state=1 : khởi tạo 1 vùng để random data
# n_init='auto': chọn ngấu nhiên tâm

# Create GUI window
window = Tk()
window.title("Phân cụm phim dựa vào đặc điểm khách hàng")

# tạo giao diện form
entry_fields = []
for i, feature in enumerate(dt_test.columns):
    label = Label(window, text=feature)
    label.grid(row=i, column=0, padx=5, pady=5)
    entry = Entry(window)
    entry.grid(row=i, column=1, padx=5, pady=5)
    entry_fields.append(entry)


# bắt lỗi nhập và hiển thị nhãn dự đoán
def predict_cluster():
    # Get input values from entry fields
    new_sample = []
    for entry in entry_fields:
        value = entry.get()
        if value == "":
            messagebox.showerror("Lỗi", "Vui lòng nhập giá trị cho tất cả các ô.")
            return
        try:
            new_sample.append(float(value))
        except ValueError:
            messagebox.showerror("Lỗi", f"Giá trị không hợp lệ: {value}")
            return

    # Predict cluster label for new sample
    cluster_label = kmeans.predict([new_sample])[0]
    result_label.configure(text=f"Nhãn dự đoán: Cụm {cluster_label + 1}")
# Create button to predict cluster label for new sample

predict_button = Button(window, text="Dự đoán cụm", command=predict_cluster)
predict_button.grid(row=len(dt_test.columns), column=0, padx=5, pady=10)

# Create label to display predicted cluster label
result_label = Label(window, text="")
result_label.grid(row=len(dt_test.columns), column=1)


#hiển thị đánh giá chất lượng mô hình
def evaluate_model():
    # Evaluate model using Silhouette and Davies-Bouldin scores
    y_pred = kmeans.predict(dt_test)
    silhouette = silhouette_score(dt_test, y_pred)
    davies_bouldin = davies_bouldin_score(dt_test, y_pred)
    evaluation_label.configure(text=f"Độ đo Silhouette: {silhouette:.10f}\nĐộ đo Davies-Bouldin: {davies_bouldin:.10f}")

# Create button to evaluate model using Silhouette and Davies-Bouldin scores
evaluate_button = Button(window, text="Đánh giá mô hình", command=evaluate_model)
evaluate_button.grid(row=len(dt_test.columns)+1, column=0, padx=5, pady=10)

# Create label to display Silhouette and Davies-Bouldin scores
evaluation_label = Label(window, text="")
evaluation_label.grid(row=len(dt_test.columns)+1, column=1)

window.mainloop()
# print(X)
# print(kmeans.labels_)
# print(kmeans.cluster_centers_)
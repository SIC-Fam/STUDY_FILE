import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
import numpy as np
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error

# đánh giá mô hình dùng độ đo NSE
def nse(targets, predictions):
    return (1-(np.sum((targets-predictions)**2)/np.sum((targets-np.mean(targets))**2)))

# đọc file 
data = pd.read_csv('daily-bike-share.csv')
# data = pd.read_csv('hour.csv')

X = data.iloc[:, 2:-1]
Y = data.iloc[:,  -1]

# print(X)

X_train, X_test, y_train, y_test = train_test_split(X,Y, test_size=0.3, shuffle=True)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

linear = LinearRegression().fit(X_train, y_train)
y_pred = linear.predict(X_test)

param_grid = {
    'hidden_layer_sizes': [(100, 50),(150, 50),(100, 150),(150, 150),(150, 50,100),(150, 150,100),(150, 100,200)],
    'max_iter': [5000]
}

# Tạo mô hình MLPRegressor
regressor = MLPRegressor()
# Sử dụng GridSearchCV để tìm giá trị tối ưu
grid_search = GridSearchCV(regressor, param_grid, cv=5)
grid_search.fit(X_train, y_train)

# Hiển thị kết quả
best_hidden_layer_sizes = grid_search.best_params_['hidden_layer_sizes']
best_score = np.abs(grid_search.best_score_)
print(f"Best Hidden Layer Sizes: {best_hidden_layer_sizes}")
print(f"Best Mean Squared Error: {best_score}")

mlp = MLPRegressor(hidden_layer_sizes=(150,150),max_iter=5000).fit(X_train, y_train)
mlp_y_pred = mlp.predict(X_test)

# print("MLPRegressor: ",mlp.score(X_test, y_test))

print("R2 MLP: ",r2_score(y_test,mlp_y_pred))
print("NSE MLP: ",nse(y_test,mlp_y_pred))
print("MAE MLP: ",mean_absolute_error(y_test,mlp_y_pred))
print("RMSE MLP: ",mean_squared_error(y_test,mlp_y_pred, squared= False))

print("R2 Linear: ",r2_score(y_test,y_pred))
print("NSE Linear: ",nse(y_test,y_pred))
print("MAE Linear: ",mean_absolute_error(y_test,y_pred))
print("RMSE Linear: ",mean_squared_error(y_test,y_pred, squared= False))

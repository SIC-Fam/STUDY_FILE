from tkinter import*
from tkinter import ttk
from tkinter import messagebox
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score,mean_absolute_error, mean_squared_error

# đánh giá mô hình dùng độ đo NSE
def nse(targets, predictions):
    return (1-(np.sum((targets-predictions)**2)/np.sum((targets-np.mean(targets))**2)))

# đọc file 
data = pd.read_csv('daily-bike-share.csv')

X = data.iloc[:, 2:-1].values
Y = data.iloc[:,  -1].values

X_train, X_test, y_train, y_test = train_test_split(X,Y, test_size=0.3, shuffle=True)
# print(X_train,X_test)

#Tạo một cửa sổ mới
window=Tk()  
#Thêm tiêu đề cho cửa sổ
window.title('Dự đoán số lần cho thuê xe đạp')
#Đặt kích thước của cửa sổ
window.geometry("400x650")

label_top = Label(window, text = "Nhập thông tin:", font=("Arial Bold", 10), fg="red")
label_top.grid(row = 1, column = 1, padx = 20, pady = 5)

# Ngày làm việc
lable_workingday = Label(window, text = "Ngày làm việc: ")
lable_workingday.grid(row = 2, column = 1, padx = 40, pady = 10)
combo_workingday = ttk.Combobox(window)
combo_workingday['values']= ("1. Có làm việc", "0. Không")
combo_workingday.current(0)
combo_workingday.grid(row = 2, column = 2)

# Mùa
lable_season = Label(window, text = "Mùa: ")
lable_season.grid(row = 3, column = 1, padx = 40, pady = 10)
combo_season = ttk.Combobox(window)
#Các giá trị của hộp chọn
combo_season['values']= ("1. Mùa xuân", "2. Mùa hè", "3. Mùa thu", "4. Mùa đông")
combo_season["state"] = 'readonly'
#Thiết lập giá trị được chọn
combo_season.current(0)
combo_season.grid(row = 3, column = 2)

# Năm
lable_year = Label(window, text = "Năm: ")
lable_year.grid(row = 4, column = 1, padx = 40, pady = 10)
textbox_year = Entry(window)
textbox_year.grid(row = 4, column = 2)

# Tháng
lable_month = Label(window, text = "Tháng: ")
lable_month.grid(row = 5, column = 1, padx = 40, pady = 10)
textbox_month = Entry(window)
textbox_month.grid(row = 5, column = 2)

# Ngày lễ
lable_holiday = Label(window, text = "Ngày lễ: ")
lable_holiday.grid(row = 6, column = 1, padx = 40, pady = 10)
cb_holiday = IntVar()
checkbox_holiday = Checkbutton(window, variable=cb_holiday)
checkbox_holiday.select()
checkbox_holiday.grid(row = 6, column = 2)

# Ngày trong tuần
lable_weekday = Label(window, text = "Ngày trong tuần: ")
lable_weekday.grid(row = 7, column = 1, padx = 40, pady = 10)
textbox_weekday = Entry(window)
textbox_weekday.grid(row = 7, column = 2)

# Tình trạng thời tiết
lable_weathersit = Label(window, text = "Tình trạng thời tiết: ")
lable_weathersit.grid(row = 8, column = 1, padx = 40, pady = 10)
combo_weathersit = ttk.Combobox(window)
#Các giá trị của hộp chọn
combo_weathersit['values']= ("1. Trong lành", "2. Mây âm u", "3. Mưa nhẹ/tuyết", "4. Mưa lớn/đá/sương mù")
combo_weathersit["state"] = 'readonly'
#Thiết lập giá trị được chọn
combo_weathersit.current(0)
combo_weathersit.grid(row = 8, column = 2)


# Nhiệt độ đo được
lable_temp = Label(window, text = "Nhiệt độ đo được: ")
lable_temp.grid(row = 9, column = 1, padx = 40, pady = 10)
textbox_temp = Entry(window)
textbox_temp.grid(row = 9, column = 2)

# Nhiệt độ cảm nhận
lable_atemp = Label(window, text = "Nhiệt độ cảm nhận: ")
lable_atemp.grid(row = 10, column = 1, padx = 40, pady = 10)
textbox_atemp = Entry(window)
textbox_atemp.grid(row = 10, column = 2)

# dộ ẩm
lable_hum = Label(window, text = "Độ ẩm: ")
lable_hum.grid(row = 11, column = 1, padx = 40, pady = 10)
textbox_hum = Entry(window)
textbox_hum.grid(row = 11, column = 2)

# Tốc độ gió
lable_windspeed = Label(window, text = "Tốc độ gió: ")
lable_windspeed.grid(row = 12, column = 1, padx = 40, pady = 10)
textbox_windspeed = Entry(window)
textbox_windspeed.grid(row = 12, column = 2)



model = MLPRegressor(hidden_layer_sizes=(150,150),max_iter=5000).fit(X_train, y_train)

y_pred = model.predict(X_test)

r2Score = r2_score(y_test,y_pred)
nseScore = nse(y_test,y_pred)
maeScore = mean_absolute_error(y_test,y_pred)
rmseScore = mean_squared_error(y_test,y_pred, squared= False)
# score = model.score(X_test, y_test)

# Đánh giá mô hình phân cụm bằng Silhouette score và Davies-Bouldin score

def getData():
    season = combo_season.get() 
    year = textbox_year.get()
    month = textbox_month.get()
    holiday = cb_holiday.get()
    weekday = textbox_weekday.get()
    workingday = combo_workingday.get()
    weathersit = combo_weathersit.get()
    temp = textbox_temp.get()
    atemp = textbox_atemp.get()
    hum = textbox_hum.get()
    windspeed = textbox_windspeed.get()

    # Xử lý dữ liệu Input
    season = season[0]
    workingday = workingday[0]
    weathersit = weathersit[0]
    year = int(year)-2011

    return season,year,month,holiday,weekday,workingday,weathersit,temp,atemp,hum,windspeed

def predict():
    season,year,month,holiday,weekday,workingday,weathersit,temp,atemp,hum,windspeed = getData()

    if((season == '') or (windspeed == '') or (hum == '') or (atemp == '') or (temp == '')or (workingday == '') or (holiday == '') or (year == '') or (month == '') or (weekday == '') or (weathersit == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        input = np.array([season,year,month,holiday,weekday,workingday,weathersit,temp,atemp,hum,windspeed]).reshape(1,-1).astype(float)
        print(input.astype(float))
        output = model.predict(input)
        # print("Kết quả: ",output)
        label_result = Label(window)
        label_result.grid(column=1, row =14)
        label_result.configure(text = "Output: "+str(int(output[0])))

#Thêm một nút nhấn Click Me
btn = Button(window, text="Xem kết quả", bg="blue", fg="white", command=predict)
btn.grid(row = 13, column = 1, padx = 30)

label_silhouette = Label(window, text="R2")
label_silhouette.grid(row = 15, column=1)
label_silhouette.configure(text="Độ đo: "+'\n'
                           +"R2: "+str(r2Score) +'\n'
                           +"NSE: "+str(nseScore) +'\n'
                           +"MAE: "+str(maeScore) +'\n'
                           +"RMSE: "+str(rmseScore) +'\n'
                           )
#Lặp vô tận để hiển thị cửa sổ
window.mainloop()
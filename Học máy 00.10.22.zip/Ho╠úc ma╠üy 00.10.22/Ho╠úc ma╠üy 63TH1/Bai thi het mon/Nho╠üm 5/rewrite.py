import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
import numpy as np
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error

# đánh giá mô hình dùng độ đo NSE
def nse(targets, predictions):
    return (1-(np.sum((targets-predictions)**2)/np.sum((targets-np.mean(targets))**2)))

# đọc file 
data = pd.read_csv('daily-bike-share.csv')

X = data.iloc[:, 2:-1].values
Y = data.iloc[:,  -1]
# Y = np.array([Y]).T

X_train, X_test, y_train, y_test = train_test_split(X,Y, test_size=0.3, shuffle=True)

w = np.linalg.pinv(X_train.T@X_train)@X_train.T@y_train
y_pred = X_test@w

# # Thêm cột 1 vào ma trận X để tính toán hệ số điều chỉnh
# X = np.concatenate((np.ones((X.shape[0], 1)), X), axis=1)

# # Tính toán hệ số điều chỉnh bằng phương pháp bình phương tối thiểu
# coefficients = np.linalg.pinv(X_train.T@X_train)@X_train.T@y_train
# y_pred_bias = X_test@w

print("R2 Linear: ",r2_score(y_test,y_pred))
print("NSE Linear: ",nse(y_test,y_pred))
print("MAE Linear: ",mean_absolute_error(y_test,y_pred))
print("RMSE Linear: ",mean_squared_error(y_test,y_pred, squared= False))

# bias
# print("R2 Linear: ",r2_score(y_test,y_pred_bias))
# print("NSE Linear: ",nse(y_test,y_pred_bias))
# print("MAE Linear: ",mean_absolute_error(y_test,y_pred_bias))
# print("RMSE Linear: ",mean_squared_error(y_test,y_pred_bias, squared= False))

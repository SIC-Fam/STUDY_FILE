import pandas as pd
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
# Đọc dữ liệu từ tệp csv 'cars.csv' và lưu vào biến data.
data = pd.read_csv('./DataSet/Churn_Modelling.csv') 

X_data = np.array(data[['CreditScore','Geography','Gender','Age','Tenure','Balance','NumOfProducts','HasCrCard','IsActiveMember','EstimatedSalary']].values)
y_data = np.array(data['Exited'].values)

def data_encoder(X) : 
    for i, j in enumerate(X) : 
        for k in range(0, 7) : 
            if j[k]== "Male":
                j[k]=0
            elif j[k]=="Female":
                j[k]=1
            elif j[k]=="France":
                j[k]=2
            elif j[k]=="Spain":
                j[k]=3
            elif j[k]=="Germany":
                j[k]=4
    return X

X_data = data_encoder(X_data)

# Chia dữ liệu thành tập huấn luyện và tập kiểm tra, với tỷ lệ 70% cho tập huấn luyện và 30% cho tập kiểm tra. Dữ liệu không được xáo trộn trước khi chia.
X_train, X_test, y_train, y_test = train_test_split(X_data, y_data, test_size=0.3, shuffle=True)

# Xây dựng mô hình ID3
id3=DecisionTreeClassifier(criterion='gini',max_depth=3, random_state=42)
id3.fit(X_train, y_train)
y_predID3=id3.predict(X_test)
print("--------------------------------ID3--------------------------------")
print('Ti le du doan dung Accuracy cua ID3: ',accuracy_score(y_predID3,y_test))
#average là tham số tùy chọn để xác định cách tính toán
print('Precision ID3: ',precision_score(y_test, y_predID3,average='micro'))
print('recall ID3: ',recall_score(y_test, y_predID3,average='micro'))
print('f1_score ID3: ',f1_score(y_test, y_predID3, average='micro'))


#Xây dựng SVM
pla = SVC(kernel='poly',C=2.3)
pla.fit(X_train, y_train)
y_predSVM = pla.predict(X_test)
print("------------------------------SVM------------------------------")
print('Ti le du doan dung Accuracy cua SVM: ',accuracy_score(y_predSVM,y_test))
#average là tham số tùy chọn để xác định cách tính toán
print('Precision SVM: ',precision_score(y_test, y_predSVM,average='micro'))
print('recall SVM: ',recall_score(y_test, y_predSVM,average='micro'))
print('f1_score SVM: ',f1_score(y_test, y_predSVM, average='micro'))


#xây dựng neural network
mlp = MLPClassifier(hidden_layer_sizes=50, max_iter=300, random_state=5)
mlp.fit(X_train, y_train)
y_predNN = mlp.predict(X_test)
print("--------------------------------Neutral network--------------------------------")
print("Tỉ lệ dự đoán đúng:", accuracy_score(y_test, y_predNN))
print('Precision NN: ',precision_score(y_test, y_predNN,average='micro'))
print('recall NN: ',recall_score(y_test, y_predNN,average='micro'))
print('f1_score NN: ',f1_score(y_test, y_predNN, average='micro'))

#form
form = Tk()
form.title("Dự đoán mức độ gắn bó của nhân viên:")
form.geometry("900x500")



lable_ten = Label(form, text = "Nhập thông tin cho nhân viên:", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)

lable_crSc = Label(form, text = "Điểm tín dụng:")
lable_crSc.grid(row = 2, column = 1,pady = 10)
textbox_crSc = Entry(form)
textbox_crSc.grid(row = 2, column = 2)



lable_Geogr = Label(form, text = "Quốc gia:")
lable_Geogr.grid(row = 3, column = 1, pady = 10)
Geogr = ["France", "Spain","Germany"]
combo_box_Geogr = ttk.Combobox(form, width=17, values=Geogr)
combo_box_Geogr.set("France")
combo_box_Geogr.grid(row=3, column=2, pady=10)

label_sex = Label(form, text="Gender: ")
label_sex.grid(row=4, column=1, pady=10)
sex = ["Female", "Male"]
combo_box_sex = ttk.Combobox(form, width=17, values=sex)
combo_box_sex.set("Male")
combo_box_sex.grid(row=4, column=2, pady=10)

lable_age = Label(form, text = "Tuổi:")
lable_age.grid(row = 5, column = 1, pady = 10 )
textbox_age = Entry(form)
textbox_age.grid(row = 5, column = 2)

lable_Tenur = Label(form, text = "Nhiệm kỳ:")
lable_Tenur.grid(row =2, column = 3, pady = 10 )
textbox_Tenur = Entry(form)
textbox_Tenur.grid(row = 2 , column = 4)

lable_Balance = Label(form, text = "Balance:")
lable_Balance.grid(row =3, column = 3, pady = 10 )
textbox_Balance = Entry(form)
textbox_Balance.grid(row = 3 , column = 4)

lable_NoP = Label(form, text = "Số sản phẩm: ")
lable_NoP.grid(row = 4, column = 3, pady = 10 )
textbox_NoP = Entry(form)
textbox_NoP.grid(row = 4, column = 4)

lable_actM = Label(form, text = "Là 1 active member (1: Nếu đúng và 0: là không phải) ?:")
lable_actM.grid(row = 5, column = 3, pady = 10 )
actv = ["1", "0"]
combo_box_actv = ttk.Combobox(form, width=17, values=actv)
combo_box_actv.set("1")
combo_box_actv.grid(row=5, column=4, pady=10)

lable_HasCrCa = Label(form, text = "Có thẻ tín dụng hay không (1: Nếu đúng và 0: là không phải) ?:")
lable_HasCrCa.grid(row = 6, column = 1, pady = 10 )
HasCrCa = ["1", "0"]
combo_box_HasCrCa = ttk.Combobox(form, width=17, values=HasCrCa)
combo_box_HasCrCa.set("1")
combo_box_HasCrCa.grid(row=6, column=2, pady=10)

lable_Salary = Label(form, text = "Mức lương: ")
lable_Salary.grid(row = 6, column = 3, pady = 10 )
textbox_Salary = Entry(form)
textbox_Salary.grid(row = 6, column = 4)

#du doan ID3
y_id3 = id3.predict(X_test)
lbl3 = Label(form)
lbl3.grid(column=1, row=11)
lbl3.configure(text="Tỉ lệ dự đoán đúng của ID3: "+'\n'
                           +"Precision: "+str(precision_score(y_test, y_id3, average='macro')*100)+"%"+'\n'
                           +"Recall: "+str(recall_score(y_test, y_id3, average='macro')*100)+"%"+'\n'
                           +"F1-score: "+str(f1_score(y_test, y_id3, average='macro')*100)+"%"+'\n')
def dudoanid3():
    CCscore = textbox_crSc.get()
    Geo = combo_box_Geogr.get()
    sex = combo_box_sex.get()
    age = textbox_age.get()
    Tenur =textbox_Tenur.get()
    Balance =textbox_Balance.get()
    NoP =textbox_NoP.get()
    ActM= combo_box_actv.get()
    HasCrCa = combo_box_HasCrCa.get()
    salary = textbox_Salary.get()
    if (sex == "Male"):
        sex = 0
    else:
        sex = 1
    if (Geo == "France"):
        Geo = 2
    elif (Geo == "Spain"):
        Geo = 3
    else:
        Geo = 4
        
    if((CCscore == '') or (Geo== '') or (sex == '') or (age == '') or (Tenur == '') or (Balance == '')or (NoP== '') or (ActM == '') or(HasCrCa == ' ') or (salary == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([ CCscore,Geo,sex,age,Tenur,Balance,NoP,ActM,HasCrCa,salary]).reshape(1, -1)
        y_kqua = id3.predict(X_dudoan)
        lbl2.configure(text= y_kqua)
    
button_id3 = Button(form, text = 'Kết quả dự đoán theo ID3', command = dudoanid3)
button_id3.grid(row = 12, column = 1, pady = 20)
lbl2 = Label(form, text="...")
lbl2.grid(column=1, row=13)

def khanangid3():
    y_id3 = id3.predict(X_test)
    dem=0
    for i in range (len(y_id3)):
        if(y_id3[i] == y_test[i]):
            dem= dem+1
    count = (dem/len(y_id3))*100
    lbl3.configure(text= count)
button_id31 = Button(form, text = 'Khả năng dự đoán đúng ', command = khanangid3)
button_id31.grid(row = 14, column = 1, padx = 30)
lbl3 = Label(form, text="...")
lbl3.grid(column=1, row=15)

form.mainloop()




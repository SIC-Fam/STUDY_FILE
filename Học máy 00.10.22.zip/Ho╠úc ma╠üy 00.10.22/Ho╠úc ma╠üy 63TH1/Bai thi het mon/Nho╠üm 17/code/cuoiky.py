from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import numpy as np
import pandas as pd
from sklearn import metrics
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import precision_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn import metrics, tree

def error(y, y_pred):
    sum=0
    for i in range(0, len(y)):
        sum = sum + abs(y[i] - y_pred[i])
    return sum/len(y) # tra ve sai so trung binh

def carttotnhat(X,y):
    best_treecart = tree.DecisionTreeClassifier(criterion='gini',max_depth=4, random_state=1)
    
    min_error=10000000
    k=5
    kf = KFold(n_splits=k,random_state=None) # tao 1 doi tuong kfold tach du lieu train thanh k tap
    for train_index,validation_index in kf.split(X):
        XKfold_train ,XKfold_validation= X[train_index],X[validation_index] #du lieu input
        yKfold_train ,yKfold_validation= y[train_index],y[validation_index] # gia thuc
        # print("validation index index",X_train.iloc[validation_index])
        lg = tree.DecisionTreeClassifier(criterion='gini',max_depth=4, random_state=1)
        lg.fit(XKfold_train,yKfold_train )
        y_predict_train = lg.predict(XKfold_train) # gia du doan cho tap x train
        y_predict_validation= lg.predict(XKfold_validation) #gia du doan x_validation
        # sau khi du doan tao ra loi cua tap train sau do de tranh
        # truong hop overfiting(dung tren tap train, sai tren tap test)
        # thi dung tap validation det test lai (test trong x train)

        sum_error = mean_absolute_error(y_predict_train,yKfold_train) + mean_absolute_error(yKfold_validation,y_predict_validation)
        if(sum_error<min_error):
            min_error= sum_error
            best_treecart = lg
    return best_treecart

def id3totnhat(X,y):
    best_treeid3 = tree.DecisionTreeClassifier( criterion='entropy',max_depth=4, random_state=1)
    min_error=10000000
    k=5
    kf = KFold(n_splits=k,random_state=None) # tao 1 doi tuong kfold tach du lieu train thanh k tap
    for train_index,validation_index in kf.split(X):
        XKfold_train ,XKfold_validation= X[train_index],X[validation_index] #du lieu input
        yKfold_train ,yKfold_validation= y[train_index],y[validation_index] # gia thuc
        id3 = tree.DecisionTreeClassifier(criterion='entropy',max_depth=4, random_state=1)
        id3.fit(XKfold_train, yKfold_train)
        y_predict_train = id3.predict(XKfold_train) # gia du doan cho tap x train
        y_predict_validation= id3.predict(XKfold_validation) #gia du doan x_validation
        # sau khi du doan tao ra loi cua tap train sau do de tranh
        # truong hop overfiting(dung tren tap train, sai tren tap test)
        # thi dung tap validation det test lai (test trong x train)

        # sum_error = loi tren tap train + loi tren tap validation

        sum_error = mean_absolute_error(y_predict_train,yKfold_train) + mean_absolute_error(yKfold_validation,y_predict_validation)
        if(sum_error<min_error):
            min_error= sum_error
            best_treeid3 = id3
    return best_treeid3

#lien ket data
df = pd.read_csv('D:/cuong/tri-tue-nhan-tao/hoc-may/nhóm_17/code/winequality-red.csv')
X = np.array(df[['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides',
                     'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH',
                     'sulphates', 'alcohol']].values)    
y = np.array(df['quality'])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3 , shuffle = False)

cart = carttotnhat(X_train,y_train)

id3 = id3totnhat(X_train,y_train)

#form
form = Tk()
form.title("Dự đoán chất lượng rượu:")
form.geometry("1000x500")



lable_ten = Label(form, text = "Nhập chất lượng rượu:", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)

lable_fixedAcidity = Label(form, text = " fixed acidity:")
lable_fixedAcidity.grid(row = 2, column = 0, padx = 40, pady = 10)
textbox_fixedAcidity = Entry(form)
textbox_fixedAcidity.grid(row = 2, column = 1)

lable_volatileAcidity = Label(form, text = "volatile acidity:")
lable_volatileAcidity.grid(row = 2, column = 2, pady = 10)
textbox_volatileAcidity = Entry(form)
textbox_volatileAcidity.grid(row = 2, column = 3)

lable_citricAcid = Label(form, text = "citric acid:")   
lable_citricAcid.grid(row = 2, column = 4,pady = 10)
textbox_citricAcid = Entry(form)
textbox_citricAcid.grid(row = 2, column = 5)

lable_residualSugar = Label(form, text = "residual sugar:")
lable_residualSugar.grid(row = 3, column = 0, pady = 10)
textbox_residualSugar = Entry(form)
textbox_residualSugar.grid(row = 3, column = 1)

lable_chlorides = Label(form, text = "chlorides:")
lable_chlorides.grid(row = 3, column = 2, pady = 10 )
textbox_chlorides = Entry(form)
textbox_chlorides.grid(row = 3, column = 3)

lable_fsdioxide = Label(form, text = "free sulfur dioxide:")
lable_fsdioxide.grid(row = 3, column = 4, pady = 10 )
textbox_fsdioxide = Entry(form)
textbox_fsdioxide.grid(row = 3, column = 5)

lable_tsdioxide = Label(form, text = "total sulfur dioxide:")
lable_tsdioxide.grid(row = 4, column = 0, pady = 10 )
textbox_tsdioxide = Entry(form)
textbox_tsdioxide.grid(row = 4, column = 1)

lable_density = Label(form, text = "density:")
lable_density.grid(row = 4, column = 2, pady = 10 )
textbox_density = Entry(form)
textbox_density.grid(row = 4, column = 3)

lable_pH = Label(form, text = "pH:")
lable_pH.grid(row = 4, column = 4, pady = 10 )
textbox_pH = Entry(form)
textbox_pH.grid(row = 4, column = 5)

lable_sulphates = Label(form, text = "sulphates:")
lable_sulphates.grid(row = 5, column = 0, pady = 10 )
textbox_sulphates = Entry(form)
textbox_sulphates.grid(row = 5, column = 1)

lable_alcohol = Label(form, text = "alcohol:")
lable_alcohol.grid(row = 5, column = 2, pady = 10 )
textbox_alcohol = Entry(form)
textbox_alcohol.grid(row = 5, column = 3)

#cart
#dudoancarttheotest
y_cart = cart.predict(X_test)
lbl1 = Label(form)
lbl1.grid(column=1, row=8)
lbl1.configure(text="Tỉ lệ dự đoán đúng của CART: "+'\n'
                           +"accuracy_score: "+ str(metrics.accuracy_score(y_test, y_cart)*100)+"%"+'\n'
                           +"Precision: "+str(precision_score(y_test, y_cart, average='macro')*100)+"%"+'\n'
                           +"Recall: "+str(recall_score(y_test, y_cart, average='macro')*100)+"%"+'\n'
                           +"F1-score: "+str(f1_score(y_test, y_cart, average='macro')*100)+"%"+'\n')
def dudoancart():
    fixedAcidity = textbox_fixedAcidity.get()
    volatileAcidity = textbox_volatileAcidity.get()
    citricAcid = textbox_citricAcid.get()
    residualSugar = textbox_residualSugar.get()
    chlorides = textbox_chlorides.get()
    fsdioxide = textbox_fsdioxide.get()
    tsdioxide = textbox_tsdioxide.get()
    density = textbox_density.get()
    pH = textbox_pH.get()
    sulphates = textbox_sulphates.get()
    alcohol = textbox_alcohol.get()
    if((fixedAcidity == '') or (residualSugar == '') or (volatileAcidity == '') or (citricAcid == '') or (chlorides == '')or (fsdioxide == '') or (tsdioxide == '')
       or (density == '') or (pH == '') or (sulphates == '') or (alcohol == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([fixedAcidity,residualSugar,volatileAcidity,citricAcid,chlorides,fsdioxide,tsdioxide,density,pH,sulphates,alcohol]).reshape(1, -1)
        y_kqua = cart.predict(X_dudoan)
        lbl.configure(text= y_kqua)
button_cart = Button(form, text = 'Kết quả dự đoán theo CART', command = dudoancart)
button_cart.grid(row = 9, column = 1, pady = 20)
lbl = Label(form, text="...")
lbl.grid(column=2, row=9)

def khanangcart():
    y_cart = cart.predict(X_test)
    dem=0
    for i in range (len(y_cart)):
        if(y_cart[i] == y_test[i]):
            dem= dem+1
    count = (dem/len(y_cart))*100
    lbl1.configure(text= count)
button_cart1 = Button(form, text = 'Khả năng dự đoán đúng ', command = khanangcart)
button_cart1.grid(row = 10, column = 1, padx = 30)
lbl1 = Label(form, text="...")
lbl1.grid(column=2, row=10)

#id3
#dudoanid3test
y_id3 = id3.predict(X_test)
lbl3 = Label(form)
lbl3.grid(column=3, row=8)
lbl3.configure(text="Tỉ lệ dự đoán đúng của ID3: "+'\n'
                           +"accuracy_score: "+ str(metrics.accuracy_score(y_test, y_id3)*100)+"%"+'\n'
                           +"Precision: "+str(precision_score(y_test, y_id3, average='macro')*100)+"%"+'\n'
                           +"Recall: "+str(recall_score(y_test, y_id3, average='macro')*100)+"%"+'\n'
                           +"F1-score: "+str(f1_score(y_test, y_id3, average='macro')*100)+"%"+'\n')
def dudoanid3():
    fixedAcidity = textbox_fixedAcidity.get()
    volatileAcidity = textbox_volatileAcidity.get()
    citricAcid = textbox_citricAcid.get()
    residualSugar = textbox_residualSugar.get()
    chlorides = textbox_chlorides.get()
    fsdioxide = textbox_fsdioxide.get()
    tsdioxide = textbox_tsdioxide.get()
    density = textbox_density.get()
    pH = textbox_pH.get()
    sulphates = textbox_sulphates.get()
    alcohol = textbox_alcohol.get()
    if((fixedAcidity == '') or (residualSugar == '') or (volatileAcidity == '') or (citricAcid == '') or (chlorides == '')or (fsdioxide == '') or (tsdioxide == '')
       or (density == '') or (pH == '') or (sulphates == '') or (alcohol == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([fixedAcidity,residualSugar,volatileAcidity,citricAcid,chlorides,fsdioxide,tsdioxide,density,pH,sulphates,alcohol]).reshape(1, -1)
        y_kqua = cart.predict(X_dudoan)
        lbl2.configure(text= y_kqua)
    
button_id3 = Button(form, text = 'Kết quả dự đoán theo ID3', command = dudoanid3)
button_id3.grid(row = 9, column = 3, pady = 20)
lbl2 = Label(form, text="...")
lbl2.grid(column=4, row=9)

def khanangid3():
    y_id3 = id3.predict(X_test)
    dem=0
    for i in range (len(y_id3)):
        if(y_id3[i] == y_test[i]):
            dem= dem+1
    count = (dem/len(y_id3))*100
    lbl3.configure(text= count)
button_id31 = Button(form, text = 'Khả năng dự đoán đúng ', command = khanangid3)
button_id31.grid(row = 10, column = 3, padx = 30)
lbl3 = Label(form, text="...")
lbl3.grid(column=4, row=10)


form.mainloop()

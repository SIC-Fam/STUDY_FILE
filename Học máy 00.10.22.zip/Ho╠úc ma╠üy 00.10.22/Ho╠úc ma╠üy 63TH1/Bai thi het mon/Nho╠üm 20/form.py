import sys
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, KFold
from sklearn.svm import SVC
from sklearn.linear_model import Perceptron
from sklearn.linear_model import LinearRegression
from sklearn.metrics import accuracy_score, r2_score, mean_absolute_error, mean_squared_error
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QTextEdit

class MachineLearningApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle('Machine Learning App')
        self.setGeometry(100, 100, 400, 300)

        # Load and preprocess the data
        self.load_data()

        # Create buttons and labels
        self.svm_button = QPushButton('Run SVM Classifier', self)
        self.svm_button.clicked.connect(self.run_svm_classifier)
        self.perceptron_button = QPushButton('Run Perceptron Classifier', self)
        self.perceptron_button.clicked.connect(self.run_perceptron_classifier)
        self.linear_regression_button = QPushButton('Run Linear Regression', self)
        self.linear_regression_button.clicked.connect(self.run_linear_regression)
        self.result_text = QTextEdit(self)

        # Create a vertical layout
        layout = QVBoxLayout()
        layout.addWidget(self.svm_button)
        layout.addWidget(self.perceptron_button)
        layout.addWidget(self.linear_regression_button)
        layout.addWidget(self.result_text)
        self.setLayout(layout)

    def load_data(self):
        self.df = pd.read_csv('E:/Project/python/btaplon2/data.csv')
        X_data = np.array(self.df.iloc[:, 1:-1].values)
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(X_data, self.df['Bankrupt?'].values, test_size=0.3, random_state=42)

    def run_svm_classifier(self):
        svm_classifier = SVC(kernel='rbf', C=1.0, gamma='scale')
        svm_classifier.fit(self.X_train, self.y_train)
        y_pred = svm_classifier.predict(self.X_test)
        accuracy = accuracy_score(self.y_test, y_pred)
        self.result_text.setPlainText(f'SVM Classifier Accuracy: {accuracy * 100:.2f}%')

    def run_perceptron_classifier(self):
        pla = Perceptron()
        pla.fit(self.X_train, self.y_train)
        y_predict = pla.predict(self.X_test)
        correct_predictions = (y_predict == self.y_test).sum()
        accuracy = correct_predictions / len(self.y_test)
        self.result_text.setPlainText(f'Perceptron Accuracy: {accuracy * 100:.2f}%')

    def run_linear_regression(self):
        k = 3
        kf = KFold(n_splits=k, random_state=None)
        
        def error(y, y_pred):
            sum = 0
            for i in range(0, len(y)):
                sum = sum + abs(y[i] - y_pred[i])
            return sum / len(y)
        
        def NSE(y_test, y_pred):
            return 1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2))
        
        def MAE(y_test, y_pred):
            return mean_absolute_error(y_test, y_pred)
        
        def RMSE(y_test, y_pred):
            return mean_squared_error(y_test, y_pred, squared=False)
        
        min_error = 999999
        best_regr = None
        
        for train_index, validation_index in kf.split(self.df):
            X_train = self.df.iloc[train_index, [1, 2, 3, 4, 5, 6, 7, 8]]
            X_validation = self.df.iloc[validation_index, [1, 2, 3, 4, 5, 6, 7, 8]]
            y_train, y_validation = self.df.iloc[train_index, 0], self.df.iloc[validation_index, 0]
        
            lr = LinearRegression()
            lr.fit(X_train, y_train)
            y_train_pred = lr.predict(X_train)
            y_validation_pred = lr.predict(X_validation)
        
            y_train = np.array(y_train)
            y_validation = np.array(y_validation)
        
            sum_error = error(y_train, y_train_pred) + error(y_validation, y_validation_pred)
            
            if sum_error < min_error:
                min_error = sum_error
                best_regr = lr
        
        if best_regr is not None:
            X_test = self.df.iloc[:, [1, 2, 3, 4, 5, 6, 7, 8]]
            y_test_pred = best_regr.predict(X_test)
            y_test = np.array(self.df.iloc[:, 0])
        
            result = "Linear Regression:\n"
            result += "Thực tế     Dự đoán     Sai số tuyệt đối\n"
            for i in range(0, len(y_test)):
                result += f'{y_test[i]}   {y_test_pred[i]:.2f}   {abs(y_test[i] - y_test_pred[i]):.2f}\n'
        
            result += f'NSE: {NSE(y_test, y_test_pred):.2f}\n'
            result += f'R2: {r2_score(y_test, y_test_pred):.2f}\n'
            result += f'MAE: {MAE(y_test, y_test_pred):.2f}\n'
            result += f'RMSE: {RMSE(y_test, y_test_pred):.2f}\n'
        
            self.result_text.setPlainText(result)
        else:
            self.result_text.setPlainText("Không có mô hình tốt nhất được tìm thấy trong K-fold cross-validation.")

def main():
    app = QApplication(sys.argv)
    ml_app = MachineLearningApp()
    ml_app.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()

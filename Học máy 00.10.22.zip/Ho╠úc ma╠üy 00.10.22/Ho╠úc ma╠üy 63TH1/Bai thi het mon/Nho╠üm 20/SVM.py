import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

# Đọc dữ liệu từ file CSV
df = pd.read_csv('E:/Project/python/btaplon2/data.csv')

# Tách dữ liệu đầu vào và đầu ra
X = df.drop('Bankrupt?', axis=1)
y = df['Bankrupt?']

# Chia dữ liệu thành tập huấn luyện và tập kiểm tra
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Tạo mô hình SVM
svm_classifier = SVC(kernel='rbf', C=1.0, gamma='scale')  # Chỉnh tham số theo yêu cầu

# Huấn luyện mô hình
svm_classifier.fit(X_train, y_train)

# Dự đoán kết quả trên tập kiểm tra
y_pred = svm_classifier.predict(X_test)

# Tính độ chính xác
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy}')

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron

# Đọc dữ liệu từ tệp CSV
df = pd.read_csv('E:/Project/python/btaplon2/data.csv')
X_data = np.array(df.iloc[:, 1:-1].values)  # Lấy tất cả các cột ngoại trừ cột đầu và cột cuối

# Chia dữ liệu thành tập huấn luyện và tập kiểm tra
X_train, X_test, y_train, y_test = train_test_split(X_data, df['Bankrupt?'].values, test_size=0.3, random_state=42)

# Tạo và huấn luyện mô hình Perceptron
pla = Perceptron()
pla.fit(X_train, y_train)

# Dự đoán trên tập kiểm tra
y_predict = pla.predict(X_test)

# Tính tỷ lệ dự đoán đúng
correct_predictions = (y_predict == y_test).sum()
accuracy = correct_predictions / len(y_test)
print('Tỷ lệ dự đoán đúng:', accuracy)

import pandas as pd
from sklearn.metrics import r2_score 
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split  #chia dữ liệu thành 2 phần
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
import numpy as np

# Đọc dữ liệu từ tệp "data.csv"
data = pd.read_csv('E:/Project/python/btaplon2/data.csv')

# Tạo tập train và tập test
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle=False)

k = 3
kf = KFold(n_splits=k, random_state=None)

def error(y, y_pred):
    sum = 0
    for i in range(0, len(y)):
        sum = sum + abs(y[i] - y_pred[i])
    return sum / len(y)

def NSE(y_test, y_pred):
    return 1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2))

def MAE(y_test, y_pred):
    return mean_absolute_error(y_test, y_pred)

def RMSE(y_test, y_pred):
    return mean_squared_error(y_test, y_pred, squared=False)

min_error = 999999
best_regr = None

for train_index, validation_index in kf.split(dt_Train):
    X_train = dt_Train.iloc[train_index, [1, 2, 3, 4, 5, 6, 7, 8]]  # Chọn các trường dữ liệu tương ứng với cột 1 đến cột 8
    X_validation = dt_Train.iloc[validation_index, [1, 2, 3, 4, 5, 6, 7, 8]]
    y_train, y_validation = dt_Train.iloc[train_index, 0], dt_Train.iloc[validation_index, 0]

    lr = LinearRegression()
    lr.fit(X_train, y_train)
    y_train_pred = lr.predict(X_train)
    y_validation_pred = lr.predict(X_validation)

    y_train = np.array(y_train)
    y_validation = np.array(y_validation)

    sum_error = error(y_train, y_train_pred) + error(y_validation, y_validation_pred)
    
    if sum_error < min_error:
        min_error = sum_error
        best_regr = lr

if best_regr is not None:
    X_test = dt_Test.iloc[:, [1, 2, 3, 4, 5, 6, 7, 8]]
    y_test_pred = best_regr.predict(X_test)
    y_test = np.array(dt_Test.iloc[:, 0])

    print("Thực tế     Dự đoán     Sai số tuyệt đối")
    for i in range(0, len(y_test)):
        print(y_test[i], " ", y_test_pred[i], " ", abs(y_test[i] - y_test_pred[i]))

    print("NSE:", NSE(y_test, y_test_pred))
    print('R2:', r2_score(y_test, y_test_pred))
    print('MAE:', MAE(y_test, y_test_pred))
    print('RMSE:', RMSE(y_test, y_test_pred))
else:
    print("Không có mô hình tốt nhất được tìm thấy trong K-fold cross-validation.")
#Gọi các thư viện cần thiết
from math import inf
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,precision_score,f1_score,recall_score
import numpy as np
import pandas as pd
from tkinter import *                           #Khai báo thư viện
from tkinter import messagebox
from tkinter import ttk
#Đọc dữ liệu từ file csv và xử lí dữ liệu
data = pd.read_csv("hcvdat01.csv")              #đọc dữ liệu từ file
data = data.drop('ID',axis=1)                   #loại bỏ cột ID bằng phương pháp drop
X = data[['Age','Sex','ALB','ALP','ALT','AST','BIL','CHE','CHOL','CREA','GGT','PROT']]                          #lấy các cột gán biến x
y = np.array(data['Category'])                    #lấy cột nhãn và chuyển nó thành một mảng numpy và gán cho biến y.
le = LabelEncoder()                             #khởi tạo một đối tượng LabelEncoder từ thư viện sklearn.preprocessing và sử dụng nó để mã hóa cột 'Sex' trong X thành các giá trị số.
X.iloc[:, 1] = le.fit_transform(X.iloc[:, 1])
#y = le.fit_transform(y)
X_Train,X_Test,Y_Train,Y_Test = train_test_split(X,y,test_size=0.3,shuffle=True)    #chia dữ liệu thành tập huấn và tập kiểm tra theo tỉ lệ 70% huấn luyện và 30% kiểm tra
                                                                                    #Biến shuffle=True được sử dụng để xáo trộn dữ liệu trước khi chia.
model_score = []                                #tạo một list rỗng model_score để lưu trữ điểm số của các mô hình.
model = [None,None,None]                        #tạo một list model gồm 3 phần tử None để lưu trữ các mô hình.
#mô hình id3
model[0] = DecisionTreeClassifier(criterion='entropy')      #khởi tạo một mô hình DecisionTreeClassifier từ thư viện sklearn.tree với tiêu chí chia nhánh là 'entropy'.
model[0].fit(X_Train,Y_Train)                               #huấn luyện mô hình model[0] trên dữ liệu huấn luyện X_Train và Y_Train.
Y1_pred = model[0].predict(X_Test)                         
acc_score1 = accuracy_score(Y_Test,Y1_pred)                 #dự đoán nhãn cho dữ liệu kiểm tra X_Test bằng cách sử dụng mô hình đã huấn luyện và gán kết quả vào Y1_pred.
pre_score1 = precision_score(Y_Test,Y1_pred,average = 'weighted',zero_division=1)       #tính toán các điểm số đánh giá (accuracy, precision, recall, f1) giữa nhãn thực tế Y_Test và nhãn dự đoán Y1_pred.
rec_score1 = recall_score(Y_Test,Y1_pred,average = 'weighted',zero_division=1)          
f1_score1 = f1_score(Y_Test,Y1_pred,average = 'weighted')
id3_score = (acc_score1 + pre_score1 + rec_score1 + f1_score1) / 4                      #tính toán điểm số tổng hợp id3_score bằng cách lấy trung bình cộng của accuracy, precision, recall và f1.
model_score.append(id3_score)                               #thêm id3_score vào danh sách model_score.
#mô hình neural_network
model[1] = MLPClassifier(hidden_layer_sizes=10,activation='tanh',max_iter = 10000)      #tạo mô hình MLPClassifier từ thư viện sklearn.neural_network. hidden_layer_sizes=10 chỉ định số lượng nút trong mỗi tầng ẩn, activation='tanh' chỉ định hàm kích hoạt là hàm tanh và max_iter=10000 chỉ định số lần lặp tối đa để huấn luyện mô hình.
model[1].fit(X_Train,Y_Train)                               #huấn luyện mô hình model[1] trên dữ liệu huấn luyện X_Train và Y_Train.
Y2_pred = model[1].predict(X_Test)                          #dự đoán nhãn cho dữ liệu kiểm tra X_Test bằng cách sử dụng mô hình đã huấn luyện và gán kết quả vào Y2_pred.
acc_score2 = accuracy_score(Y_Test,Y2_pred)                 #tính toán các điểm số đánh giá (accuracy, precision, recall, f1) giữa nhãn thực tế Y_Test và nhãn dự đoán Y2_pred.
pre_score2 = precision_score(Y_Test,Y2_pred,average = 'weighted',zero_division=1)
rec_score2 = recall_score(Y_Test,Y2_pred,average = 'weighted',zero_division=1)
f1_score2 = f1_score(Y_Test,Y2_pred,average = 'weighted')
mlp_score = (acc_score2 + pre_score2 + rec_score2 + f1_score2) / 4             #tính toán điểm số tổng hợp mlp_score bằng cách lấy trung bình cộng của accuracy, precision, recall và f1. 
model_score.append(mlp_score)                               #mlp_score được thêm vào danh sách model_score.
#mô hình support vector machine
model[2] = SVC(kernel='linear',C=0.5)                       #tạo mô hình SVC (Support Vector Machine) từ thư viện sklearn.svm. kernel='linear' chỉ định sử dụng kernel tuyến tính và C=0.5 chỉ định siêu tham số C có giá trị là 0.5.
model[2].fit(X_Train,Y_Train)                               #huấn luyện mô hình model[2] trên dữ liệu huấn luyện X_Train và Y_Train.
Y3_pred = model[2].predict(X_Test)                          #dự đoán nhãn cho dữ liệu kiểm tra X_Test bằng cách sử dụng mô hình đã huấn luyện và gán kết quả vào Y3_pred.
acc_score3 = accuracy_score(Y_Test,Y3_pred)                 #tính toán các điểm số đánh giá (accuracy, precision, recall, f1) giữa nhãn thực tế Y_Test và nhãn dự đoán Y3_pred.
pre_score3 = precision_score(Y_Test,Y3_pred,average = 'weighted',zero_division=1)
rec_score3 = recall_score(Y_Test,Y3_pred,average = 'weighted',zero_division=1)
f1_score3 = f1_score(Y_Test,Y3_pred,average = 'weighted')
svm_score = (acc_score3 + pre_score3 + rec_score3 + f1_score3) / 4              #tính toán điểm số tổng hợp svm_score bằng cách lấy trung bình cộng của accuracy, precision, recall và f1.

#chọn mô hình tốt nhất
model_score.append(svm_score)                               #thêm điểm số của mô hình SVM (svm_score) vào danh sách model_score.
best_score = max(model_score)                               #tìm điểm số cao nhất trong danh sách model_score bằng cách sử dụng hàm max.
best_model_index = model_score.index(best_score)            #tìm chỉ mục của điểm số cao nhất trong danh sách model_score bằng cách sử dụng hàm index.
print("Best model :")
if(best_model_index == 0):
    print("DecisionTree with id3")
if(best_model_index == 1):
    print("Neural_network (mlp)")                           #in ra màn hình mô hình tốt nhất
if(best_model_index == 2):
    print("Support Vector Machine")

form = Tk()
form.title("Dự đoán những người bệnh gan và những người hiến máu:")     #tạo ra một giao diện đồ họa sử dụng thư viện Tkinter với tiêu đề "Dự đoán những người bệnh gan và những người hiến máu:" và kích thước cửa sổ 1000x700 pixels.
form.geometry("1000x900")



lable_ten = Label(form, text = "Thông tin:", font=("Arial Bold", 10), fg="red") #tạo một nhãn (label) Thông tin, font kiểu chữ, 10 là kích cỡ, fg là mãu chữ
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)               #gắn vào cửa sổ giao diện grid, row là hàng ,column là cột , padx là chiều ngang, pady là chiều dọc


lable_age = Label(form, text = "Tuổi:")
lable_age.grid(row = 3, column = 1, pady = 10)
textbox_age = Entry(form)                               #tạo một hộp văn bản (textbox) có tên là "textbox_age"
textbox_age.grid(row = 3, column = 2)                   #đặt hộp văn bản "textbox_age" trong cửa sổ giao diện ở hàng 3, cột 2

label_sex = Label(form, text="Gender: ")
label_sex.grid(row=4, column=1, pady=10)
sex = ["Female", "Male"]
combobox_sex = ttk.Combobox(form, width=17, values=sex)
combobox_sex.set("Male")
combobox_sex.grid(row=4, column=2, pady=10)                     

lable_alb = Label(form, text = "Xét nghiệm máu Albumin:")
lable_alb.grid(row = 5, column = 1, pady = 10)
textbox_alb = Entry(form)
textbox_alb.grid(row = 5, column = 2)

lable_alp = Label(form, text = "Alkaline phosphatase:")
lable_alp.grid(row = 6, column = 1, pady = 10 )
textbox_alp = Entry(form)
textbox_alp.grid(row = 6, column = 2)

lable_alt = Label(form, text = "Alanine Transaminase:")
lable_alt.grid(row = 7, column = 1, pady = 10 )
textbox_alt = Entry(form)
textbox_alt.grid(row = 7, column = 2)

lable_ast = Label(form, text = "Aspartate Transaminase:")
lable_ast.grid(row = 8, column = 1, pady = 10 )
textbox_ast = Entry(form)
textbox_ast.grid(row = 8, column = 2)

lable_bil = Label(form, text = "Bilirubin:")
lable_bil.grid(row = 9, column = 1, pady = 10 )
textbox_bil = Entry(form)
textbox_bil.grid(row = 9, column = 2)

lable_che = Label(form, text = "Acetylcholinesterase:")
lable_che.grid(row = 10, column = 1, pady = 10 )
textbox_che = Entry(form)
textbox_che.grid(row = 10, column = 2)

lable_chol = Label(form, text = "Cholesterol:")
lable_chol.grid(row = 11, column = 1, pady = 10 )
textbox_chol = Entry(form)
textbox_chol.grid(row = 11, column = 2)

lable_crea = Label(form, text = "Creatinine:")
lable_crea.grid(row = 12, column = 1, pady = 10 )
textbox_crea = Entry(form)
textbox_crea.grid(row = 12, column = 2)

lable_ggt = Label(form, text = "Gamma-Glutamyl Transferase:")
lable_ggt.grid(row = 13, column = 1, pady = 10 )
textbox_ggt = Entry(form)
textbox_ggt.grid(row = 13, column = 2)

lable_prot = Label(form, text = "Proteins:")
lable_prot.grid(row = 14, column = 1, pady = 10 )
textbox_prot = Entry(form)
textbox_prot.grid(row = 14, column = 2)

lbl1 = Label(form)              #tạo một nhãn (label) mới trong giao diện đồ họa Tkinter được gắn vào cửa sổ giao diện "form".
lbl1.grid(column=1, row=15)     #đặt nhãn "lbl1" ở cột 1, hàng 15 trong giao diện đồ họa Tkinter.
if(best_model_index==0):        #kiểm tra giá trị của biến best_model_index. Nếu nó bằng 0, nghĩa là mô hình đầu tiên là mô hình tốt nhất, thì nội dung và văn bản của nhãn sẽ được cấu hình lại.
    lbl1.configure(text="Điểm mô hình tốt nhất: \n"     #cấu hình lại nội dung và văn bản của nhãn "lbl1" bằng cách đặt văn bản mới. bao gồm thông tin về các điểm đánh giá của mô hình như bên dưới
                           +"accracy_score: "+str(acc_score1)+'\n'
                           +"Precision: "+str(pre_score1)+'\n'
                           +"Recall: "+str(rec_score1)+'\n'
                           +"F1-score: "+str(f1_score1)+'\n')
if(best_model_index==1):
    lbl1.configure(text="Điểm mô hình tốt nhất: \n"+"accracy_score: "+str(acc_score2)+'\n'
                           +"Precision: "+str(pre_score2)+'\n'
                           +"Recall: "+str(rec_score2)+'\n'
                           +"F1-score: "+str(f1_score2)+'\n')
if(best_model_index==2):
    lbl1.configure(text="Điểm mô hình tốt nhất: \n"+"accracy_score: "+str(acc_score3)+'\n'
                           +"Precision: "+str(pre_score3)+'\n'
                           +"Recall: "+str(rec_score3)+"%"+'\n'
                           +"F1-score: "+str(f1_score3)+'\n')
def dudoan():
    age = textbox_age.get()
    sex = combobox_sex.get()
    alb = textbox_alb.get()             #dự đoán dựa trên thông tin người dùng đã nhập vào các hộp văn bản.
    alp =textbox_alp.get()
    alt =textbox_alt.get()
    ast = textbox_ast.get()
    bil = textbox_bil.get()
    che = textbox_che.get()
    chol = textbox_chol.get()
    crea = textbox_crea.get()
    ggt = textbox_ggt.get()
    prot = textbox_prot.get()
    if (sex == "Male"):
        sex = 0
    else:
        sex = 1
    if(age == '') or (sex == '') or (alb == '') or (alp == '')or (alt == '') or (bil == '') or (ast == '') or(che =='') or (chol == '') or (crea == '') or (ggt == '') or (prot == ''):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([age,sex,alb,alp,alt,ast,bil,che,chol,crea,ggt,prot]).reshape(1, -1)
        y_kqua = model[best_model_index].predict(X_dudoan)
        lbl2.configure(text="Kết quả: "+str(y_kqua))      #tổgn hợp văn bản "Kết quả: " kèm theo giá trị dự đoán y_kqua rồi hiển thị trên giao diện
button = Button(form, text = "Dự đoán bằng mô hình tốt nhất: ", command = dudoan)     # tạo một nút button để kích hoạt hàm dudoan() khi người dùng nhấp vào nút.
button.grid(row = 17, column = 1, pady = 20)
lbl2 = Label(form, text="...")
lbl2.grid(column=1, row=18)      
def khanangmohinh():
    if(best_model_index==0):
        lbl3.configure(text=str(acc_score1*100)+"%")
    if(best_model_index==1):
        lbl3.configure(text=str(acc_score2*100)+"%")
    if(best_model_index==2):
        lbl3.configure(text=str(acc_score3*100)+"%")
button1 = Button(form, text = 'Khả năng dự đoán đúng của mô hình tốt nhất: ', command = khanangmohinh)
button1.grid(row = 17, column = 5, padx = 30)
lbl3 = Label(form, text="...")
lbl3.grid(column=5, row=18)

form.mainloop()             #gọi hàm mainloop() để chạy giao diện

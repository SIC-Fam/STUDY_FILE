import numpy as np 
import pandas as pd 
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import Perceptron 
from sklearn import preprocessing 
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import KFold
data = pd.read_csv('heart.csv') 
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True) #chia dữ liệu thành 70% 30% để huấn luyện mô hình, true là lấy ngẫu nhiên
def error(y,y_pred):
    sum=0
    for i in range(0,len(y)): #để tính sai số giữa dự đoán và giá trị thực tế
        sum = sum + abs(y[i] - y_pred[i])
    return sum/len(y) #trả về trung bình sai số tuyệt đối của dự đoán so với giá trị thực tế
min=999999
min2=99999
k = 3
kf = KFold(n_splits=k, random_state=None)
for train_index, validation_index in kf.split(dt_Train):
    le=preprocessing.LabelEncoder() #để mã hoá các biến hạng mục trong dataframe
    data=data.apply(le.fit_transform) #chuyển các biến hạng mục thành các giá trị số nguyên


    X_train=dt_Train.iloc[train_index, :13]  
    y_train=dt_Train.iloc[train_index, 13] 
    X_test=dt_Train.iloc[train_index,:13] 
    y_test=dt_Train.iloc[train_index,13]

    X_train=np.array(X_train)#ép kiểu về mảng
    y_train=np.array(y_train)
    X_test=np.array(X_test)
    y_test=np.array(y_test)

    pla = Perceptron(penalty='l2').fit(X_train, y_train) #Khởi tạo một mô hình Perceptron với hình phạt 'l2'.
    y_train_pred = pla.predict(X_train)
    y_validation_pred = pla.predict(X_test)

    pla2=SVC(kernel='linear', C=1, random_state=42).fit(X_train,y_train) #kernel tuyến tính, tham số C=1 và seed ngẫu nhiên bằng 42.
    y_train_pred2 = pla2.predict(X_train)
    y_validation_pred2 = pla2.predict(X_test)

    y_train = np.array(y_train)
    y_test = np.array(y_test)

    sum_error = error(y_train,y_train_pred)+error(y_test, y_validation_pred)
    if(sum_error < min): #Chọn mô hình có train error + validation error là nhỏ nhất
        min = sum_error
        pla1=pla

    sum_error2 = error(y_train,y_train_pred2)+error(y_test, y_validation_pred2)
    if(sum_error2 < min2): #Chọn mô hình có train error + validation error là nhỏ nhất
        min2 = sum_error2
        pla3=pla2



X_test = np.array(dt_Test.iloc[:, :13]) 
y_test = np.array(dt_Test.iloc[:, 13]) 

#giaodien
form = Tk()
form.title("Dự đoán nhồi máu cơ tim:")
form.configure(background="azure")
form.geometry("750x700")

lable_age = Label(form, text = "Age:")
lable_age.grid(row = 1, column = 1, padx = 40, pady = 10)
textbox_age = Entry(form)
textbox_age.grid(row = 1, column = 2)

lable_sex = Label(form, text = "Sex(0-1):")
lable_sex.grid(row = 2, column = 1, padx = 40, pady = 10)
textbox_sex = Entry(form)
textbox_sex.grid(row = 2, column = 2)

lable_cp = Label(form, text = "Cp(0-3):")
lable_cp.grid(row = 3, column = 1, pady = 10)
textbox_cp = Entry(form)
textbox_cp.grid(row = 3, column = 2)

lable_trtbps = Label(form, text = "Trtbps:")
lable_trtbps.grid(row = 4, column = 1,pady = 10)
textbox_trtbps = Entry(form)
textbox_trtbps.grid(row = 4, column = 2)

lable_chol = Label(form, text = "Chol(100-300):")
lable_chol.grid(row = 5, column = 1, pady = 10)
textbox_chol = Entry(form)
textbox_chol.grid(row = 5, column = 2)

lable_fbs = Label(form, text = "Fbs (0-1):")
lable_fbs.grid(row = 6, column = 1, pady = 10 )
textbox_fbs = Entry(form)
textbox_fbs.grid(row = 6, column = 2)

lable_restecg = Label(form, text = "Restecg (0-1):")
lable_restecg.grid(row = 7, column = 1, pady = 10 )
textbox_restecg = Entry(form)
textbox_restecg.grid(row = 7, column = 2)

lable_thalachh = Label(form, text = "Thalachh(60-205):")
lable_thalachh.grid(row = 8, column = 1, pady = 10 )
textbox_thalachh = Entry(form)
textbox_thalachh.grid(row = 8, column = 2)

lable_exng = Label(form, text = "Exng (0-1):")
lable_exng.grid(row = 9, column = 1, pady = 10 )
textbox_exng = Entry(form)
textbox_exng.grid(row = 9, column = 2)

lable_oldpeak = Label(form, text = "Oldpeak (0-6):")
lable_oldpeak.grid(row = 10, column = 1, pady = 10 )
textbox_oldpeak = Entry(form)
textbox_oldpeak.grid(row = 10, column = 2)

lable_slp = Label(form, text = "Slp (0-2):")
lable_slp.grid(row = 11, column = 1, pady = 10 )
textbox_slp = Entry(form)
textbox_slp.grid(row = 11, column = 2)

lable_caa = Label(form, text = "Caa (0-4):")
lable_caa.grid(row = 12, column = 1, pady = 10 )
textbox_caa = Entry(form)
textbox_caa.grid(row = 12, column = 2)

lable_thall = Label(form, text = "Thall (1-3):")
lable_thall.grid(row = 13, column = 1, pady = 10 )
textbox_thall = Entry(form)
textbox_thall.grid(row = 13, column = 2)
#perceptron
y_perc = pla1.predict(X_test)
lbl1 = Label(form)
lbl1.grid(column=1, row=14)
lbl1.configure(text="Tỉ lệ dự đoán đúng của dudoanperctest: "+'\n'
                            # +"accuracy_score: "+str(accuracy_score(y_test, y_perc)*100)+"%"+'\n'
                            +"Precision: "+str(precision_score(y_test, y_perc, average='micro')*100)+"%"+'\n'
                            +"Recall: "+str(recall_score(y_test, y_perc, average='micro')*100)+"%"+'\n'
                            +"F1-score: "+str(f1_score(y_test, y_perc, average='micro')*100)+"%"+'\n')
def dudoanperceptron():
    age = pd.to_numeric(textbox_age.get()) # chuyển đổi giá trị nhập vào thành một kiểu dữ liệu số,Lấy giá trị nhập vào từ một hộp văn bản
    sex = pd.to_numeric(textbox_sex.get())
    cp = pd.to_numeric(textbox_cp.get())
    trtbps = pd.to_numeric(textbox_trtbps.get())
    chol = pd.to_numeric(textbox_chol.get())
    fbs = pd.to_numeric(textbox_fbs.get())
    restecg = pd.to_numeric(textbox_restecg.get())
    thalachh = pd.to_numeric(textbox_thalachh.get())
    exng = pd.to_numeric(textbox_exng.get())
    oldpeak = pd.to_numeric(textbox_oldpeak.get())
    slp = pd.to_numeric(textbox_slp.get())
    caa = pd.to_numeric(textbox_caa.get())
    thall = pd.to_numeric(textbox_thall.get())
    if((age == '') or (sex == '') or (cp == '') or (trtbps == '') or (chol == '')or (fbs == '')or (restecg == '')or (thalachh == '')or (exng == '') or (oldpeak == '') or (slp == '') or (caa == '') or (thall == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([age,sex,cp,trtbps,chol,fbs,thalachh,restecg,exng,oldpeak,slp,caa,thall]).reshape(1, -1) #reshape(1, -1) thay đổi hình dạng của mảng thành một hàng (1 hàng) và số cột tương ứng (số thuộc tính)
        y_kqua = pla1.predict(X_dudoan)#sử dụng mô hình Perceptron đã huấn luyện (pla1) để dự đoán kết quả bệnh tim dựa trên giá trị thu thập từ giao diện
        lbl.configure(text= y_kqua)# giá trị dự đoán (y_kqua) được hiển thị

button_cart = Button(form, text = 'Kết quả dự đoán theo perceptron', command = dudoanperceptron)#command: Xác định chức năng được gọi khi nút được nhấn
button_cart.grid(row = 15, column = 1, pady = 20)
lbl = Label(form, text="...")
lbl.grid(column=2, row=15)

def khanangper(): #hàm tính accuracy_score
    y_perc = pla1.predict(X_test)
    dem=0
    for i in range (len(y_perc)):
        if(y_perc[i] == y_test[i]):
            dem= dem+1
    count = (dem/len(y_perc))*100
    lbl1.configure(text= count)

button_cart1 = Button(form, text = 'Khả năng dự đoán đúng ', command = khanangper) #command: Xác định chức năng được gọi khi nút được nhấn
button_cart1.grid(row = 16, column = 1, padx = 30)
lbl1 = Label(form, text="...")
lbl1.grid(column=2, row=16)

#SVM
y_svm = pla3.predict(X_test)
lbl3 = Label(form)
lbl3.grid(column=3, row=14)
lbl3.configure(text="Tỉ lệ dự đoán đúng của dudoansvmtest: "+'\n'
                            # +"accuracy_score: "+str(accuracy_score(y_test, y_svm)*100)+"%"+'\n'
                            +"Precision: "+str(precision_score(y_test, y_svm, average='micro')*100)+"%"+'\n'
                            +"Recall: "+str(recall_score(y_test, y_svm, average='micro')*100)+"%"+'\n'
                            +"F1-score: "+str(f1_score(y_test, y_svm, average='micro')*100)+"%"+'\n'
                           )

def dudoansvm():
    age = textbox_age.get() #Lấy giá trị nhập vào từ một hộp văn bản
    sex = textbox_sex.get()
    cp = textbox_cp.get()
    trtbps = textbox_trtbps.get()
    chol = textbox_chol.get()
    fbs = textbox_fbs.get()
    restecg = textbox_restecg.get()
    thalachh = textbox_thalachh.get()
    exng = textbox_exng.get()
    oldpeak = textbox_oldpeak.get()
    slp = textbox_slp.get()
    caa = textbox_caa.get()
    thall = textbox_thall.get()
    if((age == '') or (sex == '') or (cp == '') or (trtbps == '') or (chol == '')or (fbs == '')or (restecg == '')or (thalachh == '')or (exng == '') or (oldpeak == '') or (slp == '') or (caa == '') or (thall == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([age,sex,cp,trtbps,chol,fbs,thalachh,restecg,exng,oldpeak,slp,caa,thall]).reshape(1, -1) #reshape(1, -1) thay đổi hình dạng của mảng thành một hàng (1 hàng) và số cột tương ứng (số thuộc tính)
        y_kqua = pla3.predict(X_dudoan) #sử dụng mô hình Perceptron đã huấn luyện (pla1) để dự đoán kết quả bệnh tim dựa trên giá trị thu thập từ giao diện
        lbl2.configure(text= y_kqua) # giá trị dự đoán (y_kqua) được hiển thị
    
button_id3 = Button(form, text = 'Kết quả dự đoán theo SVM', command = dudoansvm) #command: Xác định chức năng được gọi khi nút được nhấn
button_id3.grid(row = 15, column = 3, pady = 20)
lbl2 = Label(form, text="...")
lbl2.grid(column=4, row=15)

def khanangsvm(): #hàm tính accuracy_score
    y_svm = pla3.predict(X_test)
    dem=0
    for i in range (len(y_svm)):
        if(y_svm[i] == y_test[i]):
            dem= dem+1
    count = (dem/len(y_svm))*100
    lbl3.configure(text= count)
button_id31 = Button(form, text = 'Khả năng dự đoán đúng ', command = khanangsvm)
button_id31.grid(row = 16, column = 3, padx = 30)
lbl3 = Label(form, text="...")
lbl3.grid(column=4, row=16)
form.mainloop()


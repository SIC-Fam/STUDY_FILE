import math

class TreeNode:
    def __init__(self, feature=None, value=None, left=None, right=None, output=None):
        self.feature = feature  # Chứa chỉ số của thuộc tính được chọn tại node này
        self.value = value  # Chứa giá trị của thuộc tính nếu node là một nút lá
        self.left = left  # Con trỏ đến nút con bên trái
        self.right = right  # Con trỏ đến nút con bên phải
        self.output = output  # Kết quả dự đoán nếu node là một nút lá

def calculate_entropy(data):
    # Tính entropy dựa trên dữ liệu đầu vào
    class_counts = {}
    for row in data:
        label = row[-1]
        class_counts[label] = class_counts.get(label, 0) + 1

    entropy = 0
    for count in class_counts.values():
        probability = count / len(data)
        entropy -= probability * math.log2(probability)

    return entropy

def calculate_gini_index(data):
    # Tính Gini index dựa trên dữ liệu đầu vào
    class_counts = {}
    for row in data:
        label = row[-1]
        class_counts[label] = class_counts.get(label, 0) + 1

    gini_index = 1
    total_instances = len(data)
    for count in class_counts.values():
        probability = count / total_instances
        gini_index -= probability ** 2

    return gini_index

def split_data(data, feature_index, value):
    # Chia dữ liệu thành hai phần dựa trên giá trị của thuộc tính tại chỉ số feature_index
    left_data = []
    right_data = []
    for row in data:
        if row[feature_index] < value:
            left_data.append(row)
        else:
            right_data.append(row)
    return left_data, right_data

def id3(data, features):
    # Xây dựng cây quyết định sử dụng thuật toán ID3
    if len(set(row[-1] for row in data)) == 1:
        # Nếu tất cả các dòng có nhãn giống nhau, trả về nút lá với nhãn đó
        return TreeNode(output=data[0][-1])

    if len(features) == 0:
        # Nếu đã sử dụng hết các thuộc tính, trả về nút lá với nhãn phổ biến nhất
        label_counts = {}
        for row in data:
            label_counts[row[-1]] = label_counts.get(row[-1], 0) + 1
        most_common_label = max(label_counts, key=label_counts.get)
        return TreeNode(output=most_common_label)

    best_feature_index = 0
    best_split_value = 0
    best_info_gain = -1

    entropy = calculate_entropy(data)
    for feature_index in range(len(features) - 1):
        values = set(row[feature_index] for row in data)
        for value in values:
            left_data, right_data = split_data(data, feature_index, value)
            if len(left_data) == 0 or len(right_data) == 0:
                continue

            left_entropy = calculate_entropy(left_data)
            right_entropy = calculate_entropy(right_data)
            info_gain = entropy - (len(left_data) / len(data)) * left_entropy - (len(right_data) / len(data)) * right_entropy

            if info_gain > best_info_gain:
                best_feature_index = feature_index
                best_split_value = value
                best_info_gain = info_gain

    if best_info_gain == -1:
        # Không tìm thấy chia nhỏ nào mang lại thông tin lợi nhuận, trả về nút lá với nhãn phổ biến nhất
        label_counts = {}
        for row in data:
            label_counts[row[-1]] = label_counts.get(row[-1], 0) + 1
        most_common_label = max(label_counts, key=label_counts.get)
        return TreeNode(output=most_common_label)

    left_data, right_data = split_data(data, best_feature_index, best_split_value)
    left_features = features[:best_feature_index] + features[best_feature_index + 1:]
    right_features = left_features

    left_child = id3(left_data, left_features)
    right_child = id3(right_data, right_features)

    return TreeNode(feature=best_feature_index, value=best_split_value, left=left_child, right=right_child)

def cart(data, features):
    # Xây dựng cây quyết định sử dụng thuật toán CART
    if len(set(row[-1] for row in data)) == 1:
        # Nếu tất cả các dòng có nhãn giống nhau, trả về nút lá với nhãn đó
        return TreeNode(output=data[0][-1])

    if len(features) == 0:
        # Nếu đã sử dụng hết các thuộc tính, trả về nút lá với nhãn phổ biến nhất
        label_counts = {}
        for row in data:
            label_counts[row[-1]] = label_counts.get(row[-1], 0) + 1
        most_common_label = max(label_counts, key=label_counts.get)
        return TreeNode(output=most_common_label)

    best_feature_index = 0
    best_split_value = 0
    best_gini_index = 1

    for feature_index in range(len(features) - 1):
        values = set(row[feature_index] for row in data)
        for value in values:
            left_data, right_data = split_data(data, feature_index, value)
            if len(left_data) == 0 or len(right_data) == 0:
                continue

            gini_index = (len(left_data) / len(data)) * calculate_gini_index(left_data) + (len(right_data) / len(data)) * calculate_gini_index(right_data)

            if gini_index < best_gini_index:
                best_feature_index = feature_index
                best_split_value = value
                best_gini_index = gini_index

    left_data, right_data = split_data(data, best_feature_index, best_split_value)
    left_features = features[:best_feature_index] + features[best_feature_index + 1:]
    right_features = left_features

    left_child = cart(left_data, left_features)
    right_child = cart(right_data, right_features)

    return TreeNode(feature=best_feature_index, value=best_split_value, left=left_child, right=right_child)

# Đoạn mã chính để kiểm tra các hàm
if __name__ == "__main__":
    # Dữ liệu đầu vào và danh sách các thuộc tính
    data = [
        # ... (Dữ liệu đầu vào của bạn)
    ]
    features = [
        # ... (Danh sách các thuộc tính của dữ liệu)
    ]

    # Xây dựng cây quyết định sử dụng thuật toán ID3
    id3_tree = id3(data, features)

    # Xây dựng cây quyết định sử dụng thuật toán CART
    cart_tree = cart(data, features)

from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score, recall_score, f1_score

data = pd.read_csv('cardata.csv')
data['Fuel_Type'] = data['Fuel_Type'].map({'Petrol': 0, 'Diesel': 1})
data['Seller_Type'] = data['Seller_Type'].map({'Dealer': 0, 'Individual': 1})
data['Transmission'] = data['Transmission'].map({'Manual': 0, 'Automatic': 1})
X = np.array(data[['Year','Selling_Price','Present_Price','Kms_Driven','Fuel_Type','Seller_Type','Transmission']].values)    
y = np.array(data['Owner'])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, shuffle=False)

# CART
cart = DecisionTreeClassifier(criterion='gini', max_depth=4, random_state=42)
cart.fit(X_train, y_train)

# ID3
id3 = DecisionTreeClassifier(criterion='entropy', max_depth=4, random_state=42)
id3.fit(X_train, y_train)

# K-fold
k = 5
kf = KFold(n_splits=k)

precision_scores = []
recall_scores = []
f1_scores = []

# Dùng hàm split để chia dữ liệu thành các folds và thực hiện cross-validation
for train_index, test_index in kf.split(X):
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]

    # CART
    cart.fit(X_train, y_train)
    y_cart = cart.predict(X_test)

    # ID3
    id3.fit(X_train, y_train)
    y_id3 = id3.predict(X_test)

    # Tính các metrics
    precision_cart = precision_score(y_test, y_cart, average='weighted',zero_division=1) * 100
    recall_cart = recall_score(y_test, y_cart, average='weighted',zero_division=1) * 100
    f1_cart = f1_score(y_test, y_cart, average='weighted',zero_division=1) * 100

    precision_id3 = precision_score(y_test, y_id3, average='weighted',zero_division=1) * 100
    recall_id3 = recall_score(y_test, y_id3, average='weighted',zero_division=1) * 100
    f1_id3 = f1_score(y_test, y_id3, average='weighted',zero_division=1) * 100

    precision_scores.append((precision_cart, precision_id3))
    recall_scores.append((recall_cart, recall_id3))
    f1_scores.append((f1_cart, f1_id3))

# Tính train accuracy cho CART
train_accuracy_cart = cart.score(X_train, y_train)
print("Train Accuracy CART:", train_accuracy_cart)

# Tính train accuracy cho ID3
train_accuracy_id3 = id3.score(X_train, y_train)
print("Train Accuracy ID3:", train_accuracy_id3)

# Tính validation accuracy cho CART
val_accuracy_cart = cart.score(X_test, y_test)
print("Validation Accuracy CART:", val_accuracy_cart)

# Tính validation accuracy cho ID3
val_accuracy_id3 = id3.score(X_test, y_test)
print("Validation Accuracy ID3:", val_accuracy_id3)

#form
form = Tk()
form.title("Dự đoán chất lượng ô tô:")
form.geometry("1000x700")

label_ten = Label(form, text="Nhập thông tin cho ô tô:", font=("Arial Bold", 10), fg="red")
label_ten.grid(row=1, column=1, padx=40, pady=10)

label_year = Label(form, text=" Năm sản xuất:")
label_year.grid(row=2, column=1, padx=40, pady=10)
textbox_year = Entry(form)
textbox_year.grid(row=2, column=2)

label_Selling_Price = Label(form, text="giá gốc:")
label_Selling_Price.grid(row=3, column=1, pady=10)
textbox_Selling_Price = Entry(form)
textbox_Selling_Price.grid(row=3, column=2)

label_Present_Price = Label(form, text="giá bán lại:")
label_Present_Price.grid(row=4, column=1, pady=10)
textbox_Present_Price = Entry(form)
textbox_Present_Price.grid(row=4, column=2)

label_Kms_Driven = Label(form, text="KM đã chạy:")
label_Kms_Driven.grid(row=5, column=1, pady=10)
textbox_Kms_Driven = Entry(form)
textbox_Kms_Driven.grid(row=5, column=2)

label_Fuel_Type = Label(form, text="Loại xăng:")
label_Fuel_Type.grid(row=6, column=1, pady=10)
textbox_Fuel_Type = Entry(form)
textbox_Fuel_Type.grid(row=6, column=2)

label_Seller_Type = Label(form, text="Phương pháp chuyển nhượng:")
label_Seller_Type.grid(row=7, column=1, pady=10)
textbox_Seller_Type = Entry(form)
textbox_Seller_Type.grid(row=7, column=2)

label_Transmission = Label(form, text="Loại hộp số:")
label_Transmission.grid(row=8, column=1, pady=10)
textbox_Transmission = Entry(form)
textbox_Transmission.grid(row=8, column=2)


label_train_accuracy_cart = Label(form, text="Train Accuracy CART: {:.4f}".format(train_accuracy_cart))
label_train_accuracy_cart.grid(row=11, column=1, padx=10, pady=5)

label_train_accuracy_id3 = Label(form, text="Train Accuracy ID3: {:.4f}".format(train_accuracy_id3))
label_train_accuracy_id3.grid(row=11, column=3, padx=10, pady=5)

label_val_accuracy_cart = Label(form, text="Validation Accuracy CART: {:.4f}".format(val_accuracy_cart))
label_val_accuracy_cart.grid(row=12, column=1, padx=10, pady=5)

label_val_accuracy_id3 = Label(form, text="Validation Accuracy ID3: {:.4f}".format(val_accuracy_id3))
label_val_accuracy_id3.grid(row=12, column=3, padx=10, pady=5)

def update_accuracy_labels():
    label_train_accuracy_cart.config(text="Train Accuracy CART: {:.4f}".format(train_accuracy_cart))
    label_train_accuracy_id3.config(text="Train Accuracy ID3: {:.4f}".format(train_accuracy_id3))
    label_val_accuracy_cart.config(text="Validation Accuracy CART: {:.4f}".format(val_accuracy_cart))
    label_val_accuracy_id3.config(text="Validation Accuracy ID3: {:.4f}".format(val_accuracy_id3))

# Gọi hàm update_accuracy_labels() sau khi tính toán train_accuracy và val_accuracy ở đâu đó trong mã của bạn.


#cart
y_cart = cart.predict(X_test)
lbl1 = Label(form)
lbl1.grid(column=1, row=9)
lbl1.configure(text="Tỉ lệ dự đoán đúng của CART: "+'\n'
                            +"Precision: "+str(precision_score(y_test, y_cart, average='weighted',zero_division=1)*100)+"%"+'\n'
                            +"Recall: "+str(recall_score(y_test, y_cart, average='macro')*100)+"%"+'\n'
                            +"F1-score: "+str(f1_score(y_test, y_cart, average='macro')*100)+"%"+'\n')
def dudoancart():
    
    year = float(textbox_year.get())
    Selling_Price = float(textbox_Selling_Price.get())
    Present_Price = float(textbox_Present_Price.get())
    Kms_Driven = float(textbox_Kms_Driven.get())
    Fuel_Type = float(textbox_Fuel_Type.get())  
    Seller_Type = float(textbox_Seller_Type.get())  
    Transmission = float(textbox_Transmission.get())  
        
    X_dudoan = np.array([year, Selling_Price, Present_Price, Kms_Driven, Fuel_Type, Seller_Type, Transmission]).reshape(1, -1)
    y_kqua = cart.predict(X_dudoan)
    lbl.configure(text=y_kqua)


button_cart = Button(form, text='Kết quả dự đoán theo CART', command=dudoancart)
button_cart.grid(row=10, column=1, pady=20)
lbl = Label(form, text="...")
lbl.grid(column=2, row=10)

#id3
y_id3 = id3.predict(X_test)
lbl3 = Label(form)
lbl3.grid(column=3, row=9)
lbl3.configure(text="Tỉ lệ dự đoán đúng của ID3: "+'\n'
                           +"Precision: "+str(precision_score(y_test, y_id3, average='weighted',zero_division=1)*100)+"%"+'\n'
                           +"Recall: "+str(recall_score(y_test, y_id3, average='macro')*100)+"%"+'\n'
                           +"F1-score: "+str(f1_score(y_test, y_id3, average='macro')*100)+"%"+'\n')
def dudoanid3():
    year = float(textbox_year.get())
    Selling_Price = float(textbox_Selling_Price.get())
    Present_Price = float(textbox_Present_Price.get())
    Kms_Driven = float(textbox_Kms_Driven.get())
    Fuel_Type = float(textbox_Fuel_Type.get())  
    Seller_Type = float(textbox_Seller_Type.get())  
    Transmission = float(textbox_Transmission.get()) 
    
    X_dudoan = np.array([year, Selling_Price, Present_Price, Kms_Driven, Fuel_Type, Seller_Type, Transmission]).reshape(1, -1)
    y_kqua = id3.predict(X_dudoan)
    lbl2.configure(text= y_kqua)
    
button_id3 = Button(form, text = 'Kết quả dự đoán theo ID3', command = dudoanid3)
button_id3.grid(row = 10, column = 3, pady = 20)
lbl2 = Label(form, text="...")
lbl2.grid(column=4, row=10)

form.mainloop()
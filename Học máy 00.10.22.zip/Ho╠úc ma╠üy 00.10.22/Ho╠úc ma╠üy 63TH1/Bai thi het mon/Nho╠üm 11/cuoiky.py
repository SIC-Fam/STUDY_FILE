from sklearn.model_selection import KFold
import pandas as pd
import numpy as np
import math
from tkinter import *
from tkinter import messagebox
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score


def entropy(data, target):
    count = {}
    for d in data:
        if d[target] not in count:
            count[d[target]] = 0
        count[d[target]] += 1

    entropy = 0
    for freq in count.values():
        p = freq / len(data)
        entropy += -p * math.log2(p)
    return entropy

def information_gain(data, attribute, target):
    values = {}
    for d in data:
        if d[attribute] not in values:
            values[d[attribute]] = []
        values[d[attribute]].append(d)

    gain = entropy(data, target)
    for val in values.values():
        p = len(val) / len(data)
        gain -= p * entropy(val, target)
    return gain

def majority_vote(data, target):
    count = {}
    for d in data:
        if d[target] not in count:
            count[d[target]] = 0
        count[d[target]] += 1
    majority_class = max(count, key=count.get)
    return majority_class

def id3(data, attributes, target):
    # Trường hợp dừng khi tất cả các mẫu cùng thuộc một lớp
    if all(d[target] == data[0][target] for d in data):
        return data[0][target]
    
    # Trường hợp dừng khi không còn thuộc tính để chia
    if len(attributes) == 0:
        return majority_vote(data, target)

    # Chọn thuộc tính có information gain lớn nhất để chia
    best_attribute = max(attributes, key=lambda a: information_gain(data, a, target))
    tree = {best_attribute: {}}
    values = set(d[best_attribute] for d in data)
    for value in values:
        subset = [d for d in data if d[best_attribute] == value]
        sub_attributes = [a for a in attributes if a != best_attribute]
        tree[best_attribute][value] = id3(subset, sub_attributes, target)

    return tree
def predict(sample, tree):
    # Trường hợp cây là một lá, trả về nhãn của lá đó
    if not isinstance(tree, dict):
        return tree

    # Lấy thuộc tính đầu tiên của cây
    attribute = next(iter(tree))
    # Lấy giá trị của thuộc tính trong mẫu
    value = sample[attribute]

    # Kiểm tra xem giá trị có trong cây không
    if value in tree[attribute]:
        # Gọi đệ quy với cây con tương ứng với giá trị
        subtree = tree[attribute][value]
        return predict(sample, subtree)
    else:
        # Giá trị không có trong cây, trả về None
        return None

def error(y_train,y_pred):
    sum=0
    for i in range(0,len(y_train)):
        sum = sum + abs(y_train[i] - y_pred[i])
    return sum/len(y_train)  # tra ve trung binh

def k_fold(model):
    min=999999
    # phan Số lượng fold(chai 70% train thanh 5p bang nhau)
    k = 5
    regr = None
    # Khởi tạo đối tượng KFold
    kf = KFold(n_splits=k, random_state=None)
    for train_index, validation_index in kf.split(dt_Train):
        X_train, X_validation = dt_Train.iloc[train_index,:7], dt_Train.iloc[validation_index, :7]
        y_train, y_validation = dt_Train.iloc[train_index, 7], dt_Train.iloc[validation_index, 7]
        # Huấn luyện mô hình trên tập train
        model.fit(X_train, y_train)
        y_train_pred = model.predict(X_train)
        y_validation_pred = model.predict(X_validation)
        y_train = np.array(y_train)
        y_validation = np.array(y_validation)
        #tim tong do sai lech de so sanh cai nao nho nhat
        sum_error = error(y_train,y_train_pred)+error(y_validation, y_validation_pred)
        #Chọn mô hình có (train error + validation error) là nhỏ nhất
        if(sum_error < min):
            min = sum_error
            regr=model #la mo hinh nho nhat trong 5 mo hinh dc train
    return regr

# Loading the dataset
data = pd.read_csv('../milknew.csv') 
## Khai báo thư viện nhận các giá trị các nhãn
le=preprocessing.LabelEncoder() 
#Chuyển đổi các nhãn thành các số
data=data.apply(le.fit_transform) 
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True)
#Lấy dữ liệu từ cột đầu đến cột cuối để train
X_train = dt_Train.iloc[:, :7]
y_train = dt_Train.iloc[:, 7]
X_test = dt_Test.iloc[:, :7]
y_test = dt_Test.iloc[:, 7]

#ID3(KF)
super_model1 = k_fold(DecisionTreeClassifier(criterion="entropy",max_leaf_nodes=10, min_samples_leaf=5))
#CART(KF)
super_model2 = k_fold(DecisionTreeClassifier(criterion="gini",max_leaf_nodes=10, min_samples_leaf=5))


#id3(custom)
data = data.to_dict('records')
# Thuộc tính đầu vào và đầu ra
attributes = ['pH', 'Temprature', 'Odor', 'Fat', 'Turbidity', 'Colour']
target = 'Grade'
decision_tree = id3(data, attributes, target)
test_samples = dt_Test.to_dict('records')
predictions = []
for sample in test_samples:
    prediction = predict(sample, decision_tree)
    predictions.append(prediction)
y_pred = np.array(predictions)
print('Accuracy(ID3): %.9f' % accuracy_score(y_test, y_pred))
print('Precision: %.9f' % precision_score(y_test, y_pred, average='macro'))
print('Recall: %.9f' % recall_score(y_test,y_pred, average='macro'))
print('F1: %.9f' % f1_score(y_test, y_pred, average='macro'))

#Giao dien
#form
form = Tk()
form.title("Chất lượng sữa")
form.geometry("650x600")



lable_ten1 = Label(form, text = "Nhập thông tin cho các nhãn:", font=("Arial Bold", 10), fg="red")
lable_ten1.grid(row = 1, column = 1, padx = 40, pady = 10)

lable_ph = Label(form, text = "pH:")
lable_ph.grid(row = 2, column = 1, pady = 10)
textbox_ph = Entry(form)
textbox_ph.grid(row = 2, column = 2, pady = 10)

lable_temprature = Label(form, text = "Temprature:")
lable_temprature.grid(row = 3, column = 1, pady = 10)
textbox_temprature = Entry(form)
textbox_temprature.grid(row = 3, column = 2, pady = 10)

lable_taste = Label(form, text = "Taste:")
lable_taste.grid(row = 4, column = 1, pady = 10)
textbox_taste = Entry(form)
textbox_taste.grid(row = 4, column = 2, pady = 10)

lable_odor = Label(form, text = "Odor:")
lable_odor.grid(row = 5, column = 1, pady = 10)
textbox_odor = Entry(form)
textbox_odor.grid(row = 5, column = 2, pady = 10)

lable_fat = Label(form, text = "Fat:")
lable_fat.grid(row = 6, column = 1, pady = 10)
textbox_fat = Entry(form)
textbox_fat.grid(row = 6, column = 2, pady = 10)

lable_turbidity = Label(form, text = "Turbidity:")
lable_turbidity.grid(row = 7, column = 1, pady = 10)
textbox_turbidity = Entry(form)
textbox_turbidity.grid(row = 7, column = 2, pady = 10)

lable_colour = Label(form, text = "Colour:")
lable_colour.grid(row = 8, column = 1, pady = 10)
textbox_colour = Entry(form)
textbox_colour.grid(row = 8, column = 2, pady = 10)

lable_ten2 = Label(form, text = "Chất lượng mô hình:", font=("Arial Bold", 10), fg="red")
lable_ten2.grid(row = 11, column = 1, padx = 40, pady = 10)



y_test_pred=super_model1.predict(dt_Test.iloc[:,:7])
lbl1 = Label(form)
lbl1.grid(column=1, row=13, pady = 10)
lbl1.configure(text="Tỉ lệ dự đoán đúng của ID3: "+'\n'
                           +"Accuracy: "+str(accuracy_score(y_test, y_test_pred)*100)+"%"+'\n'
                           +"Precision: "+str(precision_score(y_test, y_test_pred, average='macro')*100)+"%"+'\n'
                           +"Recall: "+str(recall_score(y_test, y_test_pred, average='macro')*100)+"%"+'\n'
                           +"F1-score: "+str(f1_score(y_test, y_test_pred, average='macro')*100)+"%"+'\n')





y_test_pred=super_model2.predict(dt_Test.iloc[:,:7])
lbl1 = Label(form)
lbl1.grid(column=2, row=13, pady = 10)
lbl1.configure(text="Tỉ lệ dự đoán đúng của CART: "+'\n'
                           +"Accuracy: "+str(accuracy_score(y_test, y_test_pred)*100)+"%"+'\n'
                           +"Precision: "+str(precision_score(y_test, y_test_pred, average='macro')*100)+"%"+'\n'
                           +"Recall: "+str(recall_score(y_test, y_test_pred, average='macro')*100)+"%"+'\n'
                           +"F1-score: "+str(f1_score(y_test, y_test_pred, average='macro')*100)+"%"+'\n')


def dudoanid3():
    ph = textbox_ph.get()
    temprature = textbox_temprature.get()
    taste = textbox_taste.get()
    odor = textbox_odor.get()
    fat =textbox_fat.get()
    turbidity =textbox_turbidity.get()
    colour =textbox_colour.get()
    if((ph == '') or (temprature == '') or (taste == '') or (odor == '') or (fat == '')or (turbidity == '') or (colour == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([ph, temprature, taste, odor, fat, turbidity, colour]).reshape(1, -1)
        if(super_model2.predict(X_dudoan) == [1]):
            y_kqua = ['[low]']
        elif(super_model2.predict(X_dudoan) == [0]):
            y_kqua = ['[high]']
        else:
            y_kqua = ["[medium]"]
        lbl2.configure(text= y_kqua)
    
button_id3 = Button(form, text = 'Kết quả dự đoán theo ID3', command = dudoanid3)
button_id3.grid(row = 3, column = 4, pady = 20)
lbl2 = Label(form, text="   ...")
lbl2.grid(column=5, row=3, padx = 15)

def dudoancart():
    ph = textbox_ph.get()
    temprature = textbox_temprature.get()
    taste = textbox_taste.get()
    odor = textbox_odor.get()
    fat =textbox_fat.get()
    turbidity =textbox_turbidity.get()
    colour =textbox_colour.get()
    if((ph == '') or (temprature == '') or (taste == '') or (odor == '') or (fat == '')or (turbidity == '') or (colour == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([ph, temprature, taste, odor, fat, turbidity, colour]).reshape(1, -1)
        if(super_model2.predict(X_dudoan) == [1]):
            y_kqua = ['[low]']
        elif(super_model2.predict(X_dudoan) == [0]):
            y_kqua = ['[high]']
        else:
            y_kqua = ["[medium]"]
        lbl3.configure(text= y_kqua)
    
button_cart = Button(form, text = 'Kết quả dự đoán theo Cart', command = dudoancart)
button_cart.grid(row = 4, column = 4, pady = 20)
lbl3 = Label(form, text="   ...")
lbl3.grid(column=5, row=4, padx = 15)


form.mainloop()
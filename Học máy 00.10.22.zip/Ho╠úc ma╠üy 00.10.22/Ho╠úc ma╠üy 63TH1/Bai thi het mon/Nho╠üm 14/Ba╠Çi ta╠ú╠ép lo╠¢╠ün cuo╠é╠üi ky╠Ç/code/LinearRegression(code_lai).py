import numpy as np
import pandas as pd
import math
import random
from random import randint
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge
from sklearn.linear_model import Lasso
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from tkinter import *
from tkinter import messagebox
from tkinter import ttk

data = pd.read_csv("./archive/SynchronousMachine.csv")

def NSE(y_tt, y_pred):
     return (1-(np.sum((y_tt - y_pred)**2)/np.sum((y_tt - np.mean(y_tt))**2)))

def grad_dh(X, Y, w, m):
    gd = (1 / m) * X.T @ (X @ w - Y)
    return gd

# todo: lost function
def grad_mm(X, Y, w, m):
    return (1/(2*m)) * np.sum( ( Y - X.dot(w)) **2)

def random_w(l):
    w = []
    for i in range(l):
        w.append(randint(int(-len(X[0])), int(len(X[0]))))
    return w

# todo: prediction
def predict(x, w):
    return x @ w.T

data = np.array(data)

# le = preprocessing.LabelEncoder()
# data = np.array(data.apply(le.fit_transform))

dt_train, dt_test = train_test_split(data, test_size=0.3, shuffle=True)

# ! hồi quy
X_train_hq = dt_train[:, :4]
Y_train_hq = dt_train[:, 4]
X_test_hq = dt_test[:, :4]
Y_test_hq = dt_test[:, 4]

# ! nơ ron
# X_train_nr = dt_train[:, :4]
# Y_train_nr = dt_train[:, 4]
# X_test_nr = dt_test[:, :4]
# Y_test_nr = dt_test[:, 4]

X = X_train_hq
Y = Y_train_hq

l = len(X_train_hq[0])
m = len(X_train_hq) # ! so luong mau

eta = 0.02

# todo: khởi tạo w ngẫu nhiên
w = random_w(l)

# ! w(t+1) = w(t) - eta * yixi
for i in range(900000):
    grad_value = grad_dh(X, Y, w, m)
    w = w - eta * grad_value

y_pred = predict(X, w)

window = Tk()
window.title('Bài tập cuối kỳ')
window.geometry('600x600') 

lable_TaiHienTai = Label(window, text="Tải hiện tại (l_y: 3 - 6): ")
lable_TaiHienTai .grid(row=1, column=1, pady=10)
textbox_TaiHienTai = Entry(window)
textbox_TaiHienTai.grid(row=1, column=2)

lable_HeSoCongSuat = Label(window, text="Hệ số công suất (PF: 0.65 - 1): ")
lable_HeSoCongSuat.grid(row=2, column=1, pady=10)
textbox_HeSoCongSuat = Entry(window)
textbox_HeSoCongSuat.grid(row=2, column=2)

lable_LoiHeSoCongSuat = Label(window, text="Lỗi hệ số công suất (e_PF: 0 - 0.35): ")
lable_LoiHeSoCongSuat.grid(row=3, column=1, pady=10)
textbox_LoiHeSoCongSuat = Entry(window)
textbox_LoiHeSoCongSuat.grid(row=3, column=2)

lable_ThayDoiDongDien = Label(window, text="Thay đổi dòng điện kích thích (d_if: 0.04 - 0.77): ")
lable_ThayDoiDongDien.grid(row=4, column=1, pady=10, padx=40)
textbox_ThayDoiDongDien = Entry(window)
textbox_ThayDoiDongDien.grid(row=4, column=2)

lable_DongKichThich = Label(window, text="Dòng kích thích của máy đồng bộ (l_f: 1.22 - 1.95): ")
lable_DongKichThich.grid(row=5, column=1, pady=10)
textbox_DongKichThich = Entry(window)
textbox_DongKichThich.grid(row=5, column=2)

lbl_linear = Label(window)
lbl_linear.grid(column=1, row=7, pady=10)
lbl_linear.configure(text="Tỉ lệ dự đoán Linear: " + '\n'
                    + "r2_score : "+str(r2_score(Y, y_pred) * 100) + "%" + '\n'
                    + "NSE: " + str(NSE(Y, y_pred) * 100) + "%")

def TinhkqDuLieuMoi():
    TaiHienTai = textbox_TaiHienTai.get()
    HeSoCongSuat = textbox_HeSoCongSuat.get()
    LoiHeSoCongSuat = textbox_LoiHeSoCongSuat.get()
    ThayDoiDongDien = textbox_ThayDoiDongDien.get()
    DongKichThich = textbox_DongKichThich.get()
    if ((TaiHienTai == '') or (HeSoCongSuat == '') or (LoiHeSoCongSuat == '') or (ThayDoiDongDien == '') or (DongKichThich == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_new = np.array([float(TaiHienTai), float(HeSoCongSuat), float(LoiHeSoCongSuat), float(ThayDoiDongDien)]).reshape(1, -1)
        Y_new = np.array([float(DongKichThich)])

        y_pred_new = predict(X_new, w)

        ssnn = 0
        for i in range(len(Y_new)):
            ssnn +=  abs(Y_new[i] - y_pred_new[i])
        ssnn = (1 - ssnn / len(Y_new)) * 100

        NewResult_ln.configure(text=y_pred_new)
        NewResult_ln_dd.configure(text=str(ssnn) + "%")

XacNhan = ttk.Button(window,text="xác nhận",command=TinhkqDuLieuMoi)
XacNhan.grid(row=6, column=1, pady=10)

kqDuLieuMoi = Label(window,text="Kết quả dữ liệu mới", font=('cambria',12, 'bold'))
kqDuLieuMoi.grid(column=1, row= 8, pady=10)

lbl_NewResult_ln = Label(window, text='Linear:')
lbl_NewResult_ln.grid(column=1, row=9,pady=5)
lbl_NewResult_ln_dd = Label(window, text='Tỉ lệ dự đoán đúng:')
lbl_NewResult_ln_dd.grid(column=1, row=10,pady=5)

NewResult_ln = Label(window, text='...')
NewResult_ln.grid(column=2, row=9, pady=5)
NewResult_ln_dd = Label(window, text='...')
NewResult_ln_dd.grid(column=2, row=10, pady=5)

window.mainloop()
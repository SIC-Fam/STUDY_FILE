import numpy as np
import pandas as pd
import math
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge
from sklearn.linear_model import Lasso
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from tkinter import *
from tkinter import messagebox
from tkinter import ttk

data = pd.read_csv("./archive/SynchronousMachine.csv")

# todo: độ đo NSE
def NSE(y_tt, y_pred):
     return (1-(np.sum((y_tt - y_pred)**2)/np.sum((y_tt - np.mean(y_tt))**2)))

# todo: mảng data
data = np.array(data)

# todo: lấy 90% dữ liệu làm tập train, 10% còn lại dùng làm tập test
dt_train, dt_test = train_test_split(data, test_size=0.1, shuffle=True)
# ! nơ ron
X_train_nr = dt_train[:, :4]
Y_train_nr = dt_train[:, 4]
X_test_nr = dt_test[:, :4]
Y_test_nr = dt_test[:, 4]

# todo: activation: hàm kích hoạt
# todo: hidden_layer: số lớp ẩn, mỗi lớp sẽ có 120 nơ ron
# todo: alpha: hệ số góc
# todo: random_state: Xác định việc tạo số ngẫu nhiên cho trọng số
# todo: early_stopping: dừng sớm, nếu mà điểm xác thực sau có kết quả giống điểm xác thực thì sẽ dừng lại -> đang để False nên không hoạt động
nr = MLPRegressor(
    activation='relu',
    hidden_layer_sizes=(20, 120),
    alpha=0.001,
    random_state=20).fit(X_train_nr, Y_train_nr)

# todo: giá trị dự đoán
y_pred = nr.predict(X_test_nr)

print('\n')

print('Neural r2_score = ', r2_score(Y_test_nr, y_pred))
print('Neural NSE = ', NSE(Y_test_nr, y_pred))
print('Neural mean_absolute_error = ', mean_absolute_error(Y_test_nr, y_pred))
print('Neural mean_squared_error = ', mean_squared_error(Y_test_nr, y_pred), '\n')

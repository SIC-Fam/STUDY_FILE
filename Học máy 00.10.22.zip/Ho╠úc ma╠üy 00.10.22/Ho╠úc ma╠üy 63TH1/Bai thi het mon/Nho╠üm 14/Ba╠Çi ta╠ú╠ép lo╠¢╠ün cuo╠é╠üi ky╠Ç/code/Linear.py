import numpy as np
import pandas as pd
import math
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge
from sklearn.linear_model import Lasso
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from tkinter import *
from tkinter import messagebox
from tkinter import ttk

data = pd.read_csv("./archive/SynchronousMachine.csv")

# todo: độ đo NSE
def NSE(y_tt, y_pred):
     return (1-(np.sum((y_tt - y_pred)**2)/np.sum((y_tt - np.mean(y_tt))**2)))

# todo: mảng data
data = np.array(data)

# todo: lấy 90% dữ liệu làm tập train, 10% còn lại dùng làm tập test
dt_train, dt_test = train_test_split(data, test_size=0.1, shuffle=True)

# ! hồi quy
X_train_hq = dt_train[:, :4]
Y_train_hq = dt_train[:, 4]
X_test_hq = dt_test[:, :4]
Y_test_hq = dt_test[:, 4]

line = LinearRegression().fit(X_train_hq, Y_train_hq)

# todo: giá trị dự đoán
y_pred_lin = line.predict(X_test_hq)

print('\n')

print("Linear r2_score = ", r2_score(Y_test_hq, y_pred_lin))
print("Linear NSE = ", NSE(Y_test_hq, y_pred_lin))
print("Linear mean_absolute_error = ", mean_absolute_error(Y_test_hq, y_pred_lin))
print("Linear mean_squared_error = ", mean_squared_error(Y_test_hq, y_pred_lin), '\n')
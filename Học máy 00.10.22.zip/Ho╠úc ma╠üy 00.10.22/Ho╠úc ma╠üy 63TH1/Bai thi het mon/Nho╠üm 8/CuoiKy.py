from tkinter import *
from tkinter import messagebox
from sklearn.model_selection import train_test_split
from sklearn.metrics import silhouette_score, davies_bouldin_score
import numpy as np
import pandas as pd

#đọc dữ liệu
df = pd.read_csv('D:/code hoc may/cuoiky/train1.csv') # đọc tập csv và lưu trữ dạng dataframe
#chọn ô để huấn luyện dữ liệu
selected_columns = ['battery_power', 'dual_sim', 'fc', 'four_g', 'int_memory', 'm_dep', 'mobile_wt', 'n_cores', 'pc',
                     'px_height', 'px_width', 'ram', 'sc_h', 'sc_w', 'talk_time', 'three_g', 'touch_screen']
data = np.array(df[selected_columns].values)
train_data, test_data = train_test_split(data, test_size=0.1, random_state=42, shuffle=True)
 
#lớp kmeans  
class KMeans:
    #khởi tạo đối tượng
    def __init__(self, num_clusters=8, max_iters=300):
        self.num_clusters = num_clusters #số lượng cụm
        self.max_iters = max_iters #số lần lắp tối đa
        self.centroids = None #vị trí tâm
        self.clusters = None #điểm dữ liệu thuộc 
    #phương thức fit huấn luyện 
    def fit(self, X):
        #khởi tạo tâm ngẫu nhiên
        self.centroids = X[np.random.choice(range(len(X)), self.num_clusters, replace=False)]
        for _ in range(self.max_iters): 
            self.clusters = [[] for _ in range(self.num_clusters)] #tạo ds cụm rỗng
            #tính khoảng cách
            for x in X:
                distances = [np.linalg.norm(x - centroid) for centroid in self.centroids]
                cluster_idx = np.argmin(distances)
                self.clusters[cluster_idx].append(x)
            #tính trung bình cụm
            new_centroids = [] 
            for cluster in self.clusters:
                new_centroid = np.mean(cluster, axis=0)
                new_centroids.append(new_centroid)
            
            if np.allclose(new_centroids, self.centroids):
                break
            self.centroids = new_centroids
    #dự đoán nhãn
    def predict(self, X):
        cluster_labels = [np.argmin([np.linalg.norm(x - centroid) for centroid in self.centroids]) for x in X]
        return cluster_labels

def evaluate_model():
    test_labels = kmeans.predict(test_data)
    silhouette = silhouette_score(test_data, test_labels)
    davies_bouldin = davies_bouldin_score(test_data, test_labels)
    evaluation_label.configure(text=f"Độ đo Silhouette: {silhouette:.10f}\nĐộ đo Davies-Bouldin: {davies_bouldin:.10f}")


num_clusters = 10
b = []
for i in range(2, num_clusters + 1):
    kmeans = KMeans(num_clusters=i)
    kmeans.fit(train_data)
    test_labels = kmeans.predict(test_data)
    silhouette = silhouette_score(test_data, test_labels)
    davies_bouldin = davies_bouldin_score(test_data, test_labels)
    new_list = [silhouette, davies_bouldin, i]
    b.append(new_list)
max_b = max(b)
print(max_b)

kmeans = KMeans(num_clusters=2)
kmeans.fit(train_data)

form = Tk()
form.title("Dự đoán nhãn phân cụm Ung thư vú")
form.geometry("300x700")

def predict_cluster():
    new_sample = []
    for entry in entry_fields:
        value = entry.get()
        if value == "":
            messagebox.showerror("Lỗi", "Vui lòng điền đầy đủ thông tin vào các trường.")
            return
        try:
            new_sample.append(float(value))
        except ValueError:
            messagebox.showerror("Lỗi", f"Giá trị không hợp lệ: {value}")
            return

    cluster_label = kmeans.predict(np.array([new_sample]))[0]
    result_label.configure(text=f"Nhãn dự đoán: Cụm {cluster_label + 1}")

entry_fields = []
labels = ['battery_power', 'dual_sim', 'fc', 'four_g', 'int_memory', 'm_dep', 'mobile_wt', 'n_cores', 'pc',
          'px_height', 'px_width', 'ram', 'sc_h', 'sc_w', 'talk_time', 'three_g', 'touch_screen']

for i, label in enumerate(labels):
    label = Label(form, text=label)
    label.grid(row=i, column=0, sticky='e')
    entry = Entry(form)
    entry.grid(row=i, column=1)
    entry_fields.append(entry)

predict_button = Button(form, text="Dự đoán Cụm", command=predict_cluster)
predict_button.grid(row=len(labels), columnspan=2, pady=10)
evaluate_button = Button(form, text="Đánh giá Mô hình", command=evaluate_model)
evaluate_button.grid(row=len(labels) + 1, columnspan=2, pady=10)

result_label = Label(form, text="")
result_label.grid(row=len(labels) + 2, columnspan=2)

evaluation_label = Label(form, text="")
evaluation_label.grid(row=len(labels) + 3, columnspan=2)

form.mainloop()
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.metrics import silhouette_score,davies_bouldin_score
from scipy.spatial.distance import cdist
from sklearn.cluster import KMeans

data = pd.read_csv('Credit Card Customer Data.csv')
le = preprocessing.LabelEncoder()         #khoi tao ra vi du
data = data.apply(le.fit_transform)       #ma hoa

dt_Train, dt_Test = train_test_split(data, test_size=0.1, shuffle=True)
X_train = dt_Train.drop(['Sl_No'], axis=1)
X_test = dt_Test.drop(['Sl_No'], axis=1)
X_train = np.array(X_train)


#Khởi tạo các centers ban đầu.
def kmeans_init_centers(X, k):
    # randomly pick k rows of X as initial centers
    return X[np.random.choice(X.shape[0], k, replace=False)]

#Gán nhán mới cho các điểm khi biết các centers.
def kmeans_predict_labels(X, centers):
  D = cdist(X, centers)
  # Trả về giá trị nhỏ nhất của D
  return np.argmin(D, axis = 1)

#Cập nhật các centers mới dữa trên dữ liệu vừa được gán nhãn.
def kmeans_update_centers(X, labels, k):
    centers = np.zeros((k, X.shape[1]))
    for k in range(k):
        # Trả về tất cả các điểm được gán vào cụm thứ k
        Xk = X[labels == k, :]
        # Tính trung bình cộng các điểm để xác định tâm mới
        centers[k,:] = np.mean(Xk, axis = 0)
    return centers

#Kiểm tra điều kiện dừng của thuật toán.
def kmeans_has_converged(centers, new_centers):
    # Trả về True nếu tâm cụm này bằng tâm cụm trước đó
    return (set([tuple(a) for a in centers]) == set([tuple(a) for a in new_centers]))

#Hàm K-means
def k_means(X, k, max_iter):
    centers = kmeans_init_centers(X,k)
    labels = np.zeros(X.shape[0])
    times = 0
    while times<max_iter:
        labels = kmeans_predict_labels(X, centers)
        new_centers = kmeans_update_centers(X, labels, k)
        if kmeans_has_converged(centers, new_centers):
            break
        centers = new_centers
        times += 1
    return (centers, labels, times)
#Hàm tìm k tốt nhất
def find_best_k(X):
    best_k = 1  # Thay đổi giá trị ban đầu của best_k
    best_sil_score = -1  # Thay đổi giá trị ban đầu của best_sil_score
    #Lưu trữ giá trị cho biểu đồ
    sil_score_data = []
    k_val = []
    for k in range(2,11):  # lặp lại cho tất cả các giá trị k từ 2 đến 10
        labels = k_means(X, k, max_iter)[1]  # gọi hàm k_means
        sil_score = silhouette_score(X, labels)  # gọi hàm silhouette_score

        sil_score_data.append(sil_score)
        k_val.append(k)

        if sil_score > best_sil_score:  # nếu giá trị silhouette lớn hơn giá trị silhouette tốt nhất
            best_sil_score = sil_score  # cập nhật giá trị silhouette tốt nhất
            best_k = k  # cập nhật giá trị k tốt nhất
    # messagebox.showinfo("Số cụm tốt nhất", f"Số cụm tốt nhất là: {best_k}")  # hiển thị thông điệp
    print(f"Số cụm tốt nhất là: {best_k}")

    #Vẽ đồ thị
    plt.plot(k_val, sil_score_data, marker='o')
    plt.xlabel('Số cụm k')
    plt.ylabel('Giá trị silhouette')
    plt.title('Đồ thị Silhouette Score theo số cụm k')
    plt.grid()
    plt.show()

    return best_k

max_iter = 32
best_k = find_best_k(X_train)
kmeans = k_means(X_train,best_k,max_iter)
[centers, labels, it] = kmeans
print("Tâm cụm: ",centers)
print("Nhãn: ",labels)

#form
window = Tk()
window.title('BTL3_KMeans')
window.geometry('800x500')
window.configure(background= 'cyan')
lable_MaKH = Label(window, text="Mã khách hàng:", bg="cyan")
lable_MaKH.grid(row=1, column=1, padx=40, pady=10)
lable_AvgCreditLimit = Label(window, text="Hạn mức thẻ tín dụng trung bình cho khách hàng:", bg="cyan")
lable_AvgCreditLimit.grid(row=2, column=1, pady=10)
lable_TotalCreditCards = Label(window, text="Tổng số lượng thẻ mà khách hàng sở hữu:", bg="cyan")
lable_TotalCreditCards.grid(row=3, column=1, pady=10)
lable_TotalVisitsBank = Label(window, text="Tổng số lượt truy cập tại ngân hàng của khách hàng:", bg="cyan")
lable_TotalVisitsBank.grid(row=4, column=1, pady=10)
lable_TotalVisitsOnline = Label(window, text="Tổng số lượt truy cập trực tuyến của khách hàng:", bg="cyan")
lable_TotalVisitsOnline.grid(row=5, column=1, pady=10)
lable_TotalCallsMade = Label(window, text="Tổng số cuộc gọi của Khách hàng tới Ngân hàng:", bg="cyan")
lable_TotalCallsMade.grid(row=6, column=1, pady=10)

textbox_MaKH = Entry(window)
textbox_MaKH.grid(row=1, column=2)
textbox_AvgCreditLimit = Entry(window)
textbox_AvgCreditLimit.grid(row=2, column=2)
textbox_TotalCreditCards = Entry(window)
textbox_TotalCreditCards.grid(row=3, column=2)
textbox_TotalVisitsBank = Entry(window)
textbox_TotalVisitsBank.grid(row=4, column=2)
textbox_TotalVisitsOnline = Entry(window)
textbox_TotalVisitsOnline.grid(row=5, column=2)
textbox_TotalCallsMade = Entry(window)
textbox_TotalCallsMade.grid(row=6, column=2)

def dudoankmean():
    MaKH = textbox_MaKH.get()
    AvgCreditLimit = textbox_AvgCreditLimit.get()
    TotalCreditCards = textbox_TotalCreditCards.get()
    TotalVisitsBank = textbox_TotalVisitsBank.get()
    TotalVisitsOnline = textbox_TotalVisitsOnline.get()
    TotalCallsMade = textbox_TotalCallsMade.get()
    if ((MaKH == '') or (AvgCreditLimit == '') or (TotalCreditCards == '') or (TotalVisitsBank == '') or (TotalVisitsOnline == '') or (TotalCallsMade == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        nhan = kmeans_predict_labels([[int(MaKH), int(AvgCreditLimit), int(TotalCreditCards), int(TotalVisitsBank), int(TotalVisitsOnline), int(TotalCallsMade)]],centers)
        Nhan.configure(text="Cụm: " + str(nhan[0]), bg="cyan")
style = ttk.Style()
style.configure('Cyan.TButton', background='cyan')
XacNhan = ttk.Button(window, text="Xác nhận",command=dudoankmean, style='Cyan.TButton')
XacNhan.grid(row=7, column=2, padx=40, pady=10)
Silhouette = Label(window)
Silhouette.grid(row=8, column=1)
Silhouette.configure(text="Độ đo đánh giá chất lượng mô hình Silhouette là:"+str(silhouette_score(X_train, labels)), bg="cyan")
DaviesBouldin = Label(window)
DaviesBouldin.grid(row=9, column=1)
DaviesBouldin.configure(text="Độ đo đánh giá chất lượng mô hình DaviesBouldin là:"+str(davies_bouldin_score(X_train, labels)), bg="cyan")
Nhan = Label(window)
Nhan.grid(row=10, column=1)
window.mainloop()
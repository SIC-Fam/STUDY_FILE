import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split 
from sklearn.svm import SVC
from random import randint
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn import preprocessing
from tkinter import messagebox
from sklearn.model_selection import KFold
#đọc dữ liệu
data = pd.read_csv('D:\\programming\\python\\hoc_may\\bai_tap_lon_cuoi_ky\\LoanDT.csv') 
#chuẩn hóa dữ liệu
le = preprocessing.LabelEncoder()
data = data.apply(le.fit_transform)
#Lấy những cột cần thiết
data=(data[['loan_status','Principal','terms','past_due_days','age','education','Gender']])
#chia data làm 10 phần 7 phần làm data_train dùng để huấn luyện,3 phần làm data test dùng để thử
#shuffle true là có xáo trộn dữ liệu
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True) 

#lớp perceptron
class MyPerceptron:
    ## Hàm Khởi tạo
    def __init__(self, xTrain, yTrain) -> None: #none không trả về giá trị nào
        self.X = np.array(xTrain)                ## Lưu tập dữ liệu đầu vào
        self.Y = np.array([list(map(lambda x: 1 if x == 1 else -1, yTrain))]).T      ## Lưu tập nhãn dạng ma trận 1 cột
        self.w = []                                 ## Khởi tạo bộ trọng số w
        for i in range(len(self.X[0])):
            #self.w.append(randint(int(-len(self.X[0]*2)), int(len(self.X[0])*2)))           ## Sinh ngẫu nhiên bộ trọng số w
            self.w.append(randint(-12,12)) #random từ -12,12
        self.w = np.array([self.w])              ## Lưu lại bộ trọng số dưới dạng ma trận hàng
    
    ## Hàm kiểm tra xem nhãn được được đánh dấu đúng hay sai
    def check(self, x, y):
        xi = np.array(x)                         ## Lưu xi
        res = self.w@xi                             ## Tính nhãn dự đoán res = y^ = w*xi
        return True if res*y >= 0 else False        ## Nếu res (giá trị dự đoán) * y (giá trị thực tế) >=0 (cùng phía) thì nhãn được gán đúng

    ## Hàm kiểm tra xem toàn bộ nhãn đã được đánh dấu đúng chưa
    def stop(self):
        for i, v in enumerate(self.X):              ## Duyệt toàn bộ dữ liệu đầu vào
            if  self.check(v, self.Y[i])==False:        ## Kiểm tra nếu gặp một bộ bị gán nhãn sai thì trả về False và vị trí bộ dữ liệu bị gán sai
                return False, i         
        return True,-1                           ## Chạy được đến đây tức là toàn bộ các bộ dữ liệu đã được gán nhãn đúng

    ## Hàm train mô hình
    def fit(self, eta = 0.001):                     
        count = 0                                   ## Khởi tạo biến đếm số lần lặp
        while count < 1000:                         ## Sử dụng thuật toán gradient descent để tính đạo hàm hàm mất mát = 0, số lần lặp là 1000
            check, index = self.stop()              ## Lấy về giá trị kiểm tra và chỉ số từ hàm stop()
            if check:                               ## Nếu check là True thì kết thúc
                return
            yixi = (np.array([self.Y[index]])*np.array([self.X[index]]))
            self.w = self.w + eta*yixi              ## Cập nhật lại hàm mất mát với hệ số học eta mặc định = 0.001
            count += 1                              ## Tăng biến đếm

    ## Hàm dự đoán
    def predict(self, xTest):
        test = np.array(xTest)                   ## Lưu tập dữ liệu test
        res = (test@self.w.T)                ## Tính toán nhãn dự đoán của tập dữ liệu
        return list(map(lambda x: 0 if x < 0 else 1, res))                              ## Biến đổi tập nhãn dự đoán thành dạng số 0 1 rồi trả về


print(data)
print(dt_Train)
print(dt_Test)
def error(y_test,y_pred): #tong thuc te du doan chenh lech
   sum=0
   for i in range(0,len(y_test)):
      sum=sum+(np.abs(np.array(y_test[i])-np.array(y_pred[i])))
   return sum/len(y_test)#trả về giá trị trênh lệch
# Tạo cross-validator sử dụng KFold với k fold, n_splits = k = 5 tức là chia ra 5 tập fold
k=5
kf=KFold(n_splits=k,random_state=None) #chia tập dữ liệu thành 5 phần
min_svm=999
min_per=999
for Trainning_Set,Validation_Set in kf.split(dt_Train): #chọn ngẫu nhiên 4 phần là data train và 1 phần làm validation
   #cắt dữ liệu vào các biến tương ứng (X chứa các thuộc tính | Y chứa nhãn)
   X_Train=dt_Train.iloc[Trainning_Set,1:7]  #lấy phần mẫu trainning set trong dt_train , tu cot 1 den cot 6
   X_Validation=dt_Train.iloc[Validation_Set,1:7] #lấy phần mẫu của validation set trong dt_train , tu cot 1 den cot 6
   Y_Train=dt_Train.iloc[Trainning_Set,0] #lấy phần nhãn trainning set trong dt_train là cột 0
   Y_Validation=dt_Train.iloc[Validation_Set,0]#lấy phần nhãn của validation set trong dt_train là cột 0

   X_Train=np.array(X_Train)#ép kiểu về mảng
   Y_Train=np.array(Y_Train)
   X_Validation=np.array(X_Validation)
   Y_Validation=np.array(Y_Validation)


   SVM=SVC(max_iter=-1,kernel='linear',random_state=1,tol=0.0001) #khoi tao mo hinh SVM
   SVM.fit(X_Train,Y_Train) # huấn luyện
   Y_Train_pred_svm=SVM.predict(X_Train)#dự đoán nhãn của bộ dữ liệu trainning
   Y_Validation_pred_svm=SVM.predict(X_Validation)#dự đoán nhãn của bộ dữ liệu validation
   
   
   per=MyPerceptron(X_Train,Y_Train) #khoi tao mo hinh Perceptron
   per.fit(eta=0.001) # huấn luyện
   Y_Train_pred_per=per.predict(X_Train)#dự đoán nhãn của bộ dữ liệu trainning
   Y_Validation_pred_per=per.predict(X_Validation)#dự đoán nhãn của bộ dữ liệu validation

    #tìm mô hình tốt nhất của SVM
   sum_er_svm=error(Y_Train,Y_Train_pred_svm)+error(Y_Validation,Y_Validation_pred_svm) # tính tổng của train error và validation error
   if (sum_er_svm<min_svm): #tim min de dua ra mo hinh tot nhat
      min_svm=sum_er_svm
      lrd1=SVM # trả về mô hình tốt nhất
    
    #tìm mô hình tốt nhất của perceptron
   sum_er_per=error(Y_Train,Y_Train_pred_per)+error(Y_Validation,Y_Validation_pred_per) # tính tổng của train error và validation error
   if (sum_er_per<min_per): #tim min de dua ra mo hinh tot nhat
      min_per=sum_er_per
      lrd2=per # trả về mô hình tốt nhất

X_test = np.array(dt_Test.drop('loan_status', axis=1)) #ép kiểu về mảng , xóa cột loanstatus
Y_test = np.array(dt_Test.loan_status) #ép kiểu về mảng và lấy cột loanstatus

y_predict_svm = lrd1.predict(X_test)# dự đoán bằng mô hình svm
y_predict_per = lrd2.predict(X_test) #dự đoán bằng mô hình perceptron

#in ra các độ đo của mô hình SVM
print('Accuracy SVM: ',accuracy_score(Y_test, y_predict_svm))
print('Precision SVM: ',precision_score(Y_test, y_predict_svm,average='micro'))
print('recall SVM: ',recall_score(Y_test, y_predict_svm,average='micro'))
print('F1_score SVM: ',f1_score(Y_test, y_predict_svm, average='micro'))

#in ra các độ đo của mô hình per
print('Accuracy PLA: ',accuracy_score(Y_test, y_predict_per))
print('Precision PLA: ',precision_score(Y_test, y_predict_per,average='micro'))
print('recall PLA: ',recall_score(Y_test, y_predict_per,average='micro'))
print('F1_score PLA: ',f1_score(Y_test, y_predict_per, average='micro'))

from tkinter import *
from tkinter import ttk
# Tạo cửa sổ chính của ứng dụng GUI
window = Tk()
#tiêu đề
window.title("Dự đoán khách hàng đã trả khoản vay hay chưa")
#Kích thước
window.geometry('750x500')
# màu nền của cửa sổ
window.configure(background = "pink")

Principal = Label(window ,text = "Số tiền vay ban đầu").grid(row=1, column=1, padx=40, pady=10)
txtPrincipal = Entry(window)
txtPrincipal.grid(row=1, column=3,pady=10)

Terms = Label(window ,text = "Chu kỳ thanh toán").grid(row=2, column=1, padx=40, pady=10)
txtTerms = Entry(window)
txtTerms.grid(row=2, column=3,pady=10)

past_due_days = Label(window ,text = "Số ngày đã quá hạn khoản vay").grid(row=3, column=1, padx=40, pady=10)
txtpast_due_days = Entry(window)
txtpast_due_days.grid(row=3, column=3,pady=10)

Age = Label(window ,text = "Tuổi").grid(row=4, column=1, padx=40, pady=10)
txtAge = Entry(window)
txtAge.grid(row=4, column=3,pady=10)

Edu = Label(window ,text = "Học Vấn").grid(row=5, column=1, padx=40, pady=10)
HV=['college','High School or Below','Bechalor','Master or Above']#các giá trị của cbb
txtEdu = ttk.Combobox(window,values=HV)
txtEdu.set('High School or Below')
txtEdu.grid(row=5, column=3,pady=10)

Gender = Label(window ,text = "Giới tính").grid(row=6, column=1, padx=40, pady=10)
GT=['Male','Female']#các giá trị của cbb
txtGender = ttk.Combobox(window,values=GT)
txtGender.set('Male')
txtGender.grid(row=6, column=3,pady=10)

#hàm lấy dữ liệu và dự đoán mẫu của dữ liệu từ form
def SVMM():
    prince=txtPrincipal.get()# lấy dữ liệu từ texbox
    terms=txtTerms.get()
    past=txtpast_due_days.get()
    age=txtAge.get()
    edu=txtEdu.get()
    gen=txtGender.get()
    if (gen == "Male"):#chuẩn hóa dữ liệu
        gen = 1
    else:
        gen = 0
    if (edu=='Bechalor'):
        edu= 0
    elif(edu=='High School or Below'):
        edu = 1
    elif (edu=='Master or Above'):
        edu=2
    elif (edu=='college'):
        edu== 3
    
    
    if((prince == '') or (terms == '') or (past == '') or (age == '') or (edu == '') or (gen == '')):#kiểm tra đã nhập đủ thông tin chưa
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([[prince,terms,past,age,edu,gen]]).reshape(1,-1)#ép kiểu đưa về mảng
        y_kqua = lrd1.predict(X_dudoan)#dự đoán bằng mô hình 
        print(y_kqua)
        if (y_kqua==1):
            lbl.configure(text='Đã trả hết khoản vay')#gán thông báo ra lable
        else:
            lbl.configure(text='Chưa trả hết khoản vay')
        
#đưa ra tỉ lệ dự đoán của mô hình svm
Tyle1=Label(window,text='Tỷ lệ dự đoán SVM'+'\n'
            "Độ đo Accuracy_of_SVM : "+str(accuracy_score(Y_test, y_predict_svm)*100)+"%"+'\n'
            "Độ đo precision_score of SVM : " +str(precision_score(Y_test,y_predict_svm, average='micro')*100)+"%"+'\n'
            "Độ đo Recall score of SVM : "+ str(recall_score(Y_test, y_predict_svm, average='micro')*100)+"%"+'\n'
           "Độ đo F1_score of SVM : "+str(f1_score(Y_test, y_predict_svm, average='micro')*100)+"%" )
Tyle1.grid(row=9,column=1,pady=20,padx=15)
#đưa ra tỉ lệ dự đoán của mô hinh perceptron
Tyle2=Label(window,text='Tỷ lệ dự đoán PLA'+'\n'
            "Độ đo Accuracy_of_PLA : "+str(accuracy_score(Y_test, y_predict_per)*100)+"%"+'\n'
            "Độ đo precision_score of PLA : " +str(precision_score(Y_test,y_predict_per, average='micro')*100)+"%"+'\n'
            "Độ đo Recall score of PLA: "+ str(recall_score(Y_test, y_predict_per, average='micro')*100)+"%"+'\n'
           "Độ đo F1_score of PLA : "+str(f1_score(Y_test, y_predict_per, average='micro')*100)+"%" )
Tyle2.grid(row=9,column=3,pady=20,padx=15)
#tạo một button 
xacnhan=Button(window,text="Dự đoán theo SVM",command=SVMM).grid(row=14, column=2,pady=10)#command thì thực hiện hàm SVMM
lblLOP=Label(window, text = 'Kết quả dự đoán là :  ').grid(row=15, column=1,pady=10)
lbl=Label(window,text='....')
lbl.grid(row=15, column=3,pady=10)






window.mainloop()
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import numpy as np
import pandas as pd
from sklearn import metrics
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import precision_score, mean_absolute_error
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn import metrics, tree


def error(y, y_pred):
    sum=0
    for i in range(0, len(y)):
        sum = sum + abs(y[i] - y_pred[i])
    return sum/len(y) # tra ve sai so trung binh

def carttotnhat(X,y):
    best_treecart = tree.DecisionTreeClassifier(criterion='gini',max_depth=4, random_state=1)
    
    min_error=99999999
    k=5
    kf = KFold(n_splits=k,random_state=None) # tao 1 doi tuong kfold tach du lieu train thanh k tap
    for train_index,validation_index in kf.split(X):
        XKfold_train ,XKfold_validation= X[train_index],X[validation_index] #du lieu input
        yKfold_train ,yKfold_validation= y[train_index],y[validation_index] # gia thuc
        # print("validation index index",X_train.iloc[validation_index])
        lg = tree.DecisionTreeClassifier(criterion='gini',max_depth=4, random_state=1)
        lg.fit(XKfold_train,yKfold_train )
        y_predict_train = lg.predict(XKfold_train) # gia du doan cho tap x train
        y_predict_validation= lg.predict(XKfold_validation) #gia du doan x_validation
        # sau khi du doan tao ra loi cua tap train sau do de tranh
        # truong hop overfiting(dung tren tap train, sai tren tap test)
        # thi dung tap validation det test lai (test trong x train)

        sum_error = mean_absolute_error(y_predict_train,yKfold_train) + mean_absolute_error(yKfold_validation,y_predict_validation)
        if(sum_error<min_error):
            min_error= sum_error
            best_treecart = lg
    return best_treecart

def id3totnhat(X,y):
    best_treeid3 = tree.DecisionTreeClassifier( criterion='entropy',max_depth=4, random_state=1)
    min_error=99999999
    k=5
    kf = KFold(n_splits=k,random_state=None) # tao 1 doi tuong kfold tach du lieu train thanh k tap
    for train_index,validation_index in kf.split(X):
        XKfold_train ,XKfold_validation= X[train_index],X[validation_index] #du lieu input
        yKfold_train ,yKfold_validation= y[train_index],y[validation_index] # gia thuc
        id3 = tree.DecisionTreeClassifier(criterion='entropy',max_depth=4, random_state=1)
        id3.fit(XKfold_train, yKfold_train)
        y_predict_train = id3.predict(XKfold_train) # gia du doan cho tap x train
        y_predict_validation= id3.predict(XKfold_validation) #gia du doan x_validation
        # sau khi du doan tao ra loi cua tap train sau do de tranh
        # truong hop overfiting(dung tren tap train, sai tren tap test)
        # thi dung tap validation det test lai (test trong x train)

        # sum_error = loi tren tap train + loi tren tap validation

        sum_error = mean_absolute_error(y_predict_train,yKfold_train) + mean_absolute_error(yKfold_validation,y_predict_validation)
        if(sum_error<min_error):
            min_error= sum_error
            best_treeid3 = id3
    return best_treeid3

df = pd.read_csv("C:\\Users\\vuhoa\\Downloads\\student-mat-1.csv")
# df['species']=df['species'].map({'setosa': 0, 'versicolor':1, 'virginica': 2})
X = np.array(df[['ID','age','traveltime','studytime','famrel','freetime','goout','Dalc','Walc','health','absences']].values)
y = np.array(df['failures'])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3 , shuffle = True)
 
cart = carttotnhat(X_train,y_train)

id3 = id3totnhat(X_train,y_train)

dt_Train, dt_Test = train_test_split(df, test_size=0.3,shuffle=False )
x_data=df[['ID','age','traveltime','studytime','famrel','freetime','goout','Dalc','Walc','health','absences']]
y_data = df['failures']
#print('data X: \n', x_data)
#print('data Y: \n',y_data)
print('Tập dữ liệu tập train chiếm 70% : \n', dt_Train)
#print('Tập dữ liệu test chiếm 30% : \n', dt_Test)
#plt.show()
# print(clf.predict(X_Test))


# form
form = Tk() # Khởi tạo đối tượng Tk()
form.title("Dự đoán ảnh hưởng rượu bia đối với học sinh:") # title của form
form.geometry("800x650") # kích thước của form

# Khai báo label
lable_ten = Label(form, text="Nhập thông tin :", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row=1, column=1, padx=40, pady=10) # xét vị trí cho label

lable_ID = Label(form, text = "ID")
lable_ID.grid(row = 2, column = 1, pady = 10, padx = 40 )
textbox_ID = Entry(form)
textbox_ID.grid(row = 2, column = 2)

lable_age = Label(form, text = "age")
lable_age.grid(row = 3, column = 1, pady = 10, padx = 40 )
textbox_age = Entry(form)
textbox_age.grid(row = 3, column = 2)

lable_traveltime = Label(form, text = "traveltime")
lable_traveltime.grid(row = 4, column = 1, pady = 10, padx = 40 )
textbox_traveltime = Entry(form)
textbox_traveltime.grid(row = 4, column = 2)

lable_studytime = Label(form, text = "studytime")
lable_studytime.grid(row = 5, column = 1, pady = 10, padx = 40 )
textbox_studytime = Entry(form)
textbox_studytime.grid(row = 5, column = 2)

lable_famrel = Label(form, text = "famrel")
lable_famrel.grid(row = 6, column = 1, pady = 10, padx = 40 )
textbox_famrel = Entry(form)
textbox_famrel.grid(row = 6, column = 2)

lable_freetime = Label(form, text = "freetime")
lable_freetime.grid(row = 7, column = 1, pady = 10, padx = 40 )
textbox_freetime = Entry(form)
textbox_freetime.grid(row = 7, column = 2)

lable_goout = Label(form, text = "goout")
lable_goout.grid(row = 8, column = 1, pady = 10, padx = 40 )
textbox_goout = Entry(form)
textbox_goout.grid(row = 8, column = 2)

lable_Dalc = Label(form, text = "Dalc")
lable_Dalc.grid(row = 9, column = 1, pady = 10, padx = 40 )
textbox_Dalc = Entry(form)
textbox_Dalc.grid(row = 9, column = 2)

lable_Walc = Label(form, text = "Walc")
lable_Walc.grid(row = 11, column = 1, pady = 10, padx = 40 )
textbox_Walc = Entry(form)
textbox_Walc.grid(row = 11, column = 2)

lable_health = Label(form, text = "health")
lable_health.grid(row = 12, column = 1, pady = 10, padx = 40 )
textbox_health = Entry(form)
textbox_health.grid(row = 12, column = 2)

lable_absences = Label(form, text = "absences")
lable_absences.grid(row = 13, column = 1, pady = 10, padx = 40 )
textbox_absences = Entry(form)
textbox_absences.grid(row = 13, column = 2)



#logistic
#dudoanlogistictheotest
y_cart = cart.predict(X_test)
lbl1 = Label(form) #khởi tạo lable
lbl1.grid(column=1, row=16)
lbl1.configure(text="Tỉ lệ dự đoán đúng của CART : "+'\n'
                           +"do chinh xac accuracy_score: "+ str(metrics.accuracy_score(y_test, y_cart)*100)+"%"+'\n'
                           +"Precision: "+str(precision_score(y_test, y_cart, average='micro')*100)+"%"+'\n'
                           +"Recall: "+str(recall_score(y_test, y_cart, average='micro')*100)+"%"+'\n'
                           +"F1-score: "+str(f1_score(y_test, y_cart, average='weighted')*100)+"%"+'\n')
def dudoancart():
    ID = textbox_ID.get()
    age = textbox_age.get()
    traveltime = textbox_traveltime.get()
    studytime = textbox_studytime.get()
    famrel = textbox_famrel.get()
    freetime = textbox_freetime.get()
    goout = textbox_goout.get()
    Dalc = textbox_Dalc.get()
    Walc = textbox_Walc.get()
    health = textbox_health.get()
    absences = textbox_absences.get()
    
    if ((ID == '') or (age == '') or (traveltime == '') or (studytime == '') or (famrel == '') or (freetime == '') or (
            goout == '') or (Dalc == '') or (Walc == '')) or (health == '') or (absences == ''):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([ID,age,traveltime,studytime,famrel,freetime,goout,Dalc,Walc,health,absences],dtype=float).reshape(1, -1)
        y_kqua = cart.predict(X_dudoan)
        lbl.configure(text= y_kqua)
        button_cart = Button(form, text = 'Kết quả dự đoán theo CART', command = dudoancart)
        button_cart.grid(row = 7, column = 1, pady = 20)
        lbl = Label(form, text="...")
        lbl.grid(column=2, row=7)

def khanangcart():
    y_cart = cart.predict(X_test)
    dem=0
    for i in range (len(y_cart)):
        if(y_cart[i] == y_test[i]):
            dem= dem+1
    count = (dem/len(y_cart))*100
    lbl1.configure(text= count)
button_cart1 = Button(form, text = 'Khả năng dự đoán đúng của Cart ', command = khanangcart)
button_cart1.grid(row = 19, column = 3, padx = 30)
lbl1 = Label(form, text="...")
lbl1.grid(column=4, row=19)




#dudoanid3test
y_id3 = id3.predict(X_test)
lbl3 = Label(form)
lbl3.grid(column=3, row=16)
lbl3.configure(text="Tỉ lệ dự đoán đúng của ID3: "+'\n'
                           +"do chinh xac accuracy_score: "+ str(metrics.accuracy_score(y_test, y_id3)*100)+"%"+'\n'
                           +"Precision: "+str(precision_score(y_test, y_id3, average='micro')*100)+"%"+'\n'
                           +"Recall: "+str(recall_score(y_test, y_id3, average='micro')*100)+"%"+'\n'
                           +"F1-score: "+str(f1_score(y_test, y_id3, average='weighted')*100)+"%"+'\n')


def dudoan_id3():
    ID = textbox_ID.get()
    age = textbox_age.get()
    traveltime = textbox_traveltime.get()
    studytime = textbox_studytime.get()
    famrel = textbox_famrel.get()
    freetime = textbox_freetime.get()
    goout = textbox_goout.get()
    Dalc = textbox_Dalc.get()
    Walc = textbox_Walc.get()
    health = textbox_health.get()
    absences = textbox_absences.get()
    if ((ID == '') or (age == '') or (traveltime == '') or (studytime == '') or (famrel == '') or (freetime == '') or (
            goout == '') or (Dalc == '') or (Walc == '')) or (health == '') or (absences == ''):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([ID,age,traveltime,studytime,famrel,freetime,goout,Dalc,Walc,health,absences],dtype=float).reshape(1, -1)
        y_kqua = id3.predict(X_dudoan)
        lbl2.configure(text= y_kqua)

button_id3 = Button(form, text = 'Kết quả dự đoán theo ID3', command = dudoan_id3)
button_id3.grid(row = 19, column = 1, pady = 20)
lbl2 = Label(form, text="...")
lbl2.grid(column=2, row=19)



form.mainloop()

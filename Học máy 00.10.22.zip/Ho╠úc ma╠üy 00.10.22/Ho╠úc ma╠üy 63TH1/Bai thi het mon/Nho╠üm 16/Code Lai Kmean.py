
import random
import numpy as np
import pandas as pd
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import tkinter as tk
from sklearn.model_selection import train_test_split
import random
def Khoangcach(point1,point2):
    point1=np.array(point1)
    point2=np.array(point2)
    point=point1-point2
    # print(point)
    kc=sum(i**2 for i in point.reshape(-1,1))**(1/2)
    return kc
# a=np.array([1,2,3])
# b=np.array([2,3,4])
# print(Khoangcach(a,b))
def KcNgannhat(point ,centers):
    kc=[Khoangcach(point,centers[i]) for i in range(len(centers))]
    # print(kc)
    return kc.index(min(kc))
def Tinhlaitam(data,labels,k):
    newcenter=[]
    for i in range(k):
        kq=[]
        count=0
        for j in range(len(data)):
            if(labels[j]==i):
                kq=kq+[data[j]]
                count=count+1
        
        kq=np.array(kq)
        kq=np.sum(kq,axis=0)
        # print(type(kq))
        kq=[k/count for k in kq]   
        
        newcenter=newcenter+[kq]
        # print(newcenter)
    return np.array(newcenter)
    # return 1


def Kmean(data,k,maxIter=100):
    # print(type(data))
    # print(len(data))
    # print(data[0])
    #tạo bừa k tâm lấy trong tập dữ liệu
    centers=[data[random.randint(0,len(data))]  for i in range(k)]
    centers=np.array(centers)
    for loop in range(maxIter):
        #gan nhan cho tung điểm
        labels=[KcNgannhat(data[i],centers) for i in range(len(data))]
        new_centers = Tinhlaitam(data,labels,k)

        
        if np.all(centers == new_centers):
            break

    centers = new_centers
    def predict(new_data):
        new_labels = [KcNgannhat(data[i],centers) for i in range(len(new_data))]
        return new_labels
    
    def silhouette_score():
        num_samples = data.shape[0]
        s = 0
        for i in range(num_samples):
            a_i = np.mean([Khoangcach(data[i] , data[j]) for j in range(num_samples) if labels[j] == labels[i]])
            b_i = min([np.mean([Khoangcach(data[i] , data[j]) for j in range(num_samples) if labels[j] != labels[i]])])
            s += (b_i - a_i) / max(a_i, b_i)
        return s / num_samples

    def davies_bouldin_index():
        db = 0
        for i in range(k):
            d_i = np.max([np.mean([np.linalg.norm(centers[i] - centers[j])]) for j in range(k) if j != i])# Trung bình khoảng cách giữa hai trọng tâm của 2 cụm
            db += max([np.mean([np.linalg.norm(data[p] - centers[i])]) for p in range(data.shape[0]) if labels[p] == i]) / d_i #Trung bình khoảng cách giữa các điểm trong cụm với trọng tâm của cụm
        return db / k
    return centers, labels, predict, silhouette_score, davies_bouldin_index
    
def timk():
    bestsilhoute=-1
    bestk=0
    for i in range(2,10):
        centers, labels, predict, silhouette_score, davies_bouldin_index = Kmean(dtTrain, i)
        nowsilhouete=silhouette_score()
        if nowsilhouete> bestsilhoute:
            bestsilhoute= nowsilhouete
            bestk=i
    print("Best K:" +str(bestk))
    return bestk

#=====================================================================================
index=0 #tạo biến lấy random 1 dòng code trong datatest
df=pd.read_csv('./cod.csv') #đọc file dữ liệu
# originTest=df
# label_encoder = LabelEncoder()
# df = df.apply(label_encoder.fit_transform)
dtTrain, dtTest = train_test_split(df, test_size=0.1, shuffle = True) #chia dữ liệu
originTest=dtTest # lấy dữ liệu test nguyên bản có cột tên 

dtTrain=dtTrain.iloc[:,1:] #loại cột tên
dtTrain=np.array(dtTrain)
dtTest=dtTest.iloc[:,1:] #loại cột tên
dtTrain=np.array(dtTrain)
# print(dtTrain)
#=====================================================================================
# np.random.seed(0)
# data = np.random.rand(201, 2)

# k = 3 # Number of clusters
# centers, labels, predict, silhouette_score, davies_bouldin_index = Kmean(dtTrain, k)


centers, labels, predict, silhouette_score, davies_bouldin_index = Kmean(dtTrain, 3)
print("Các Cụm:")
print(centers)
print("Labels:")
print(labels)


# new_data = np.array([[0.2, 0.3], [0.7, 0.9]])
# new_labels = predict(new_data)
# print("Kết Quả dự đoán:")
# print(new_labels)


sil_score = silhouette_score()
db_index = davies_bouldin_index()
print("Các Độ Đo: ")
print(f"Silhouette Score: {sil_score}")
print(f"Davies-Bouldin Index: {db_index}")

#Form==================================================================================
# form
form = Tk()
form.title("Phân cụm người chơi game CALL OF DUCATI:")
form.geometry("1000x1000")



lable_ten = Label(form, text = "Nhập thông tin Người chơi:", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)
#1
nameLbl = Label(form, text = " Names:")
nameLbl.grid(row = 2, column = 1, padx = 40, pady = 10)
nameTxt = Entry(form)
nameTxt.grid(row = 2, column = 2)
#2
winLbl = Label(form, text = " Wins:")
winLbl.grid(row = 3, column = 1, padx = 40, pady = 10)
winsTxt = Entry(form)
winsTxt.grid(row = 3, column = 2)
#3
killLbl = Label(form, text = " Kills:")
killLbl.grid(row = 4, column = 1, padx = 40, pady = 10)
killsTxt = Entry(form)
killsTxt.grid(row = 4, column = 2)
#4
kdratioLbl = Label(form, text = " KdRatio:")
kdratioLbl.grid(row = 5, column = 1, padx = 40, pady = 10)
kdratioTxt = Entry(form)
kdratioTxt.grid(row = 5, column = 2)
#5
killstreakLbl = Label(form, text = " Killstreak:")
killstreakLbl.grid(row = 6, column = 1, padx = 40, pady = 10)
killstreakTxt = Entry(form)
killstreakTxt.grid(row = 6, column = 2)
#6
levelLbl = Label(form, text = " Level:")
levelLbl.grid(row = 7, column = 1, padx = 40, pady = 10)
levelTxt = Entry(form)
levelTxt.grid(row = 7, column = 2)
#7
loseLbl = Label(form, text = " loses:")
loseLbl.grid(row = 8, column = 1, padx = 40, pady = 10)
losesTxt = Entry(form)
losesTxt.grid(row = 8, column = 2)
#8
prestigeLbl = Label(form, text = " Prestige:")
prestigeLbl.grid(row = 9, column = 1, padx = 40, pady = 10)
prestigeTxt = Entry(form)
prestigeTxt.grid(row = 9, column = 2)
#9
hitsLbl = Label(form, text = " Hits:")
hitsLbl.grid(row = 10, column = 1, padx = 40, pady = 10)
hitsTxt = Entry(form)
hitsTxt.grid(row = 10, column = 2)
#10



#2
timeplayedLbl = Label(form, text = " TimePlayed:")
timeplayedLbl.grid(row = 2, column = 3, padx = 40, pady = 10)
timeplayedTxt = Entry(form)
timeplayedTxt.grid(row = 2, column = 4)
#3
headshotsLbl = Label(form, text = " Headshots:")
headshotsLbl.grid(row = 3, column = 3, padx = 40, pady = 10)
headshotsTxt = Entry(form)
headshotsTxt.grid(row = 3, column = 4)
#4
averagetimeLbl = Label(form, text = " AverageTime:")
averagetimeLbl.grid(row = 4, column = 3, padx = 40, pady = 10)
averagetimeTxt = Entry(form)
averagetimeTxt.grid(row = 4, column = 4)
#5
gameplayedLbl = Label(form, text = " GamePlayed:")
gameplayedLbl.grid(row = 5, column = 3, padx = 40, pady = 10)
gameplayedTxt = Entry(form)
gameplayedTxt.grid(row = 5, column = 4)
#6
assistsLbl = Label(form, text = " Assists:")
assistsLbl.grid(row = 6, column = 3, padx = 40, pady = 10)
assistsTxt = Entry(form)
assistsTxt.grid(row = 6, column = 4)
#7
missesLbl = Label(form, text = " Misses:")
missesLbl.grid(row = 7, column = 3, padx = 40, pady = 10)
missesTxt = Entry(form)
missesTxt.grid(row = 7, column = 4)
#8
xpLbl = Label(form, text = " Xp:")
xpLbl.grid(row = 8, column = 3, padx = 40, pady = 10)
xpTxt = Entry(form)
xpTxt.grid(row = 8, column = 4)
#9
scoreperminuteLbl = Label(form, text = " ScorePerMinute:")
scoreperminuteLbl.grid(row = 9, column = 3, padx = 40, pady = 10)
scoreperminuteTxt = Entry(form)
scoreperminuteTxt.grid(row = 9, column = 4)
#10
shotsLbl = Label(form, text = " Shots:")
shotsLbl.grid(row = 10, column = 3, padx = 40, pady = 10)
shotsTxt = Entry(form)
shotsTxt.grid(row = 10, column = 4)

deathsLbl = Label(form, text = " Deadths:")
deathsLbl.grid(row = 11, column = 1, padx = 40, pady = 10)
deathsTxt = Entry(form)
deathsTxt.grid(row = 11, column = 2)





lbl1 = Label(form)
lbl1.grid(column=1, row=12,padx=20,pady=20)
lbl1.configure(text="Tỉ lệ dự đoán đúng của Kmean: "+'\n'+"Silhoutte: "+str(sil_score)+'\n'+"Davie_bouldin: "+str(db_index)+'\n')


def diendulieu(): #hàm lấy ngẫu nhiên một bộ dữ liệu từ datatest 
    global index
    index=random.randint(0,len(dtTest)) #lấy ngẫu nhiên 1 bộ trong datatest
    test=originTest.iloc[index]

    nameTxt.delete(0, tk.END)
    nameTxt.insert(tk.END,test[0])
    winsTxt.delete(0, tk.END)
    winsTxt.insert(tk.END,test[1])
    killsTxt.delete(0, tk.END)
    killsTxt.insert(tk.END,test[2])
    kdratioTxt.delete(0, tk.END)
    kdratioTxt.insert(tk.END,test[3])
    killstreakTxt.delete(0, tk.END)
    killstreakTxt.insert(tk.END,test[4])
    levelTxt.delete(0, tk.END)
    levelTxt.insert(tk.END,test[5])
    losesTxt.delete(0, tk.END)
    losesTxt.insert(tk.END,test[6])
    prestigeTxt.delete(0, tk.END)
    prestigeTxt.insert(tk.END,test[7])
    hitsTxt.delete(0, tk.END)
    hitsTxt.insert(tk.END,test[8])
    timeplayedTxt.delete(0, tk.END)
    timeplayedTxt.insert(tk.END,test[9])
    headshotsTxt.delete(0, tk.END)
    headshotsTxt.insert(tk.END,test[10])
    averagetimeTxt.delete(0, tk.END)
    averagetimeTxt.insert(tk.END,test[11])
    gameplayedTxt.delete(0, tk.END)
    gameplayedTxt.insert(tk.END,test[12])
    assistsTxt.delete(0, tk.END)
    assistsTxt.insert(tk.END,test[13])
    missesTxt.delete(0, tk.END)
    missesTxt.insert(tk.END,test[14])
    xpTxt.delete(0, tk.END)
    xpTxt.insert(tk.END,test[15])
    scoreperminuteTxt.delete(0, tk.END)
    scoreperminuteTxt.insert(tk.END,test[16])
    shotsTxt.delete(0, tk.END)
    shotsTxt.insert(tk.END,test[17])
    deathsTxt.delete(0, tk.END)
    deathsTxt.insert(tk.END,test[18])


    
    # print(test)
    # print(index)
# lấy random ngẫu nhiên một bộ dữ liệu từ tập test đem đi phân cụm
button_Random= Button(form, text = 'Điền dữ liệu',command=diendulieu)
button_Random.grid(row = 12, column = 3, padx = 20)

def phancum(): #hàm thực hiện phân cụm cho dữ liệu được lấy random từ datatest
    # test=np.array(dtTest.iloc[index])
    test=[dtTest.iloc[index]]
    test=np.array(test)
    # print(test)
    
    ketqua=predict(test)
    lblCum.configure(text=ketqua)
    # print(index)
    # print(ketqua)
    

button_Phancum = Button(form, text = 'Phân cụm',command=phancum)
button_Phancum.grid(row = 13, column = 3, padx = 20)
lblCum = Label(form, text="...")
lblCum.grid(column=4, row=12,padx=20)


form.mainloop()

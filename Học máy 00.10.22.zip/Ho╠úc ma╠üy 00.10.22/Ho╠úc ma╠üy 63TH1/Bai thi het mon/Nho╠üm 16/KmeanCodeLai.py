
import random
import numpy as np
def Khoangcach(point1,point2):
    point1=np.array(point1)
    point2=np.array(point2)
    point=point1-point2
    # print(point)
    kc=sum(i**2 for i in point.reshape(-1,1))**(1/2)
    return kc
# a=np.array([1,2,3])
# b=np.array([2,3,4])
# print(Khoangcach(a,b))
def KcNgannhat(point ,centers):
    kc=[Khoangcach(point,centers[i]) for i in range(len(centers))]
    # print(kc)
    return kc.index(min(kc))
def Tinhlaitam(data,labels,k):
    newcenter=[]
    for i in range(k):
        kq=[]
        count=0
        for j in range(len(data)):
            if(labels[j]==i):
                kq=kq+[data[j]]
                count=count+1
        
        kq=np.array(kq)
        kq=np.sum(kq,axis=0)
        # print(type(kq))
        kq=[k/count for k in kq]   
        
        newcenter=newcenter+[kq]
        # print(newcenter)
    return np.array(newcenter)
    # return 1


def Kmean(data,k,maxIter=100):
    print(type(data))
    centers=[data[random.randint(0,len(data))]  for i in range(k)]
    centers=np.array(centers)
    for loop in range(maxIter):
        #gan nhan cho tung điểm
        labels=[KcNgannhat(data[i],centers) for i in range(len(data))]
        new_centers = Tinhlaitam(data,labels,k)

        
        if np.all(centers == new_centers):
            break

    centers = new_centers
    def predict(new_data):
        new_labels = [KcNgannhat(data[i],centers) for i in range(len(new_data))]
        return new_labels
    
    def silhouette_score():
        num_samples = data.shape[0]
        s = 0
        for i in range(num_samples):
            a_i = np.mean([Khoangcach(data[i] , data[j]) for j in range(num_samples) if labels[j] == labels[i]])
            b_i = min([np.mean([Khoangcach(data[i] , data[j]) for j in range(num_samples) if labels[j] != labels[i]])])
            s += (b_i - a_i) / max(a_i, b_i)
        return s / num_samples

    def davies_bouldin_index():
        db = 0
        for i in range(k):
            d_i = np.max([np.mean([Khoangcach(centers[i] , centers[j])]) for j in range(k) if j != i])# Trung bình khoảng cách giữa hai trọng tâm của 2 cụm
            db += max([np.mean([Khoangcach(data[p] , centers[i])]) for p in range(data.shape[0]) if labels[p] == i]) / d_i #Trung bình khoảng cách giữa các điểm trong cụm với trọng tâm của cụm
        return db / k
    return centers, labels, predict, silhouette_score, davies_bouldin_index
    
def timk():
    bestsilhoute=-1
    bestk=0
    for i in range(2,10):
        centers, labels, predict, silhouette_score, davies_bouldin_index = Kmean(data, i)
        nowsilhouete=silhouette_score()
        if nowsilhouete> bestsilhoute:
            bestsilhoute= nowsilhouete
            bestk=i
    print("Best K:" +str(bestk))
    return bestk

#=====================================================================================

#=====================================================================================
np.random.seed(0)
data = np.random.rand(200, 2)




centers, labels, predict, silhouette_score, davies_bouldin_index = Kmean(data, timk())
print("Các Cụm:")
print(centers)
print("Label:")
print(labels)


new_data = np.array([[0.2, 0.3], [0.7, 0.9]])
new_labels = predict(new_data)
print("Kết Quả dự đoán:")
print(new_labels)


sil_score = silhouette_score()
db_index = davies_bouldin_index()
print("Các Độ Đo: ")
print(f"Silhouette Score: {sil_score}")
print(f"Davies-Bouldin Index: {db_index}")

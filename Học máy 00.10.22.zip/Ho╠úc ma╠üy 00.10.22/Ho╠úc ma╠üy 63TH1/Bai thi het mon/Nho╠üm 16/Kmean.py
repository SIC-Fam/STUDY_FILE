from sklearn.cluster import KMeans
import random
import numpy as np
import pandas as pd
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import tkinter as tk
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import silhouette_score, davies_bouldin_score
from sklearn.model_selection import train_test_split
index=0 #tạo biến lấy random 1 dòng code trong datatest
df=pd.read_csv('./cod.csv') #đọc file dữ liệu
# originTest=df
# label_encoder = LabelEncoder()
# df = df.apply(label_encoder.fit_transform)
dtTrain, dtTest = train_test_split(df, test_size=0.1, shuffle = True) #chia dữ liệu

originTest=dtTest # lấy dữ liệu test nguyên bản có cột tên 

dtTrain=dtTrain.iloc[:,1:] #loại cột tên
dtTest=dtTest.iloc[:,1:] #loại cột tên

def timk():
    bestsilhoute=-1
    bestk=0
    for i in range(10,1,-1):
        kmeans = KMeans(n_clusters=i, n_init='auto').fit(dtTrain.values)
        nowsilhouete=silhouette_score(dtTrain, kmeans.labels_)
        print(nowsilhouete)
        if nowsilhouete> bestsilhoute:
            bestsilhoute= nowsilhouete
            bestk=i
    print("Best K:" +str(bestk))
    return bestk

kmeans = KMeans(n_clusters=timk(), n_init='auto').fit(dtTrain.values) #tạo mô hình kmean với 4 cụm
test= kmeans.predict(dtTest)
# print(kmeans.labels_)
# print(dtTest.shape)
silhouette=silhouette_score(dtTrain, kmeans.labels_) #càng lớn càng tốt
davies_bouldin=davies_bouldin_score(dtTrain, kmeans.labels_) #càng nhỏ càng tốt

print(test)
# print(kmeans.cluster_centers_)

# form
form = Tk()
form.title("Phân cụm người chơi game CALL OF DUCATI:")
form.geometry("1000x1000")



lable_ten = Label(form, text = "Nhập thông tin Người chơi:", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)
#1
nameLbl = Label(form, text = " Names:")
nameLbl.grid(row = 2, column = 1, padx = 40, pady = 10)
nameTxt = Entry(form)
nameTxt.grid(row = 2, column = 2)
#2
winLbl = Label(form, text = " Wins:")
winLbl.grid(row = 3, column = 1, padx = 40, pady = 10)
winsTxt = Entry(form)
winsTxt.grid(row = 3, column = 2)
#3
killLbl = Label(form, text = " Kills:")
killLbl.grid(row = 4, column = 1, padx = 40, pady = 10)
killsTxt = Entry(form)
killsTxt.grid(row = 4, column = 2)
#4
kdratioLbl = Label(form, text = " KdRatio:")
kdratioLbl.grid(row = 5, column = 1, padx = 40, pady = 10)
kdratioTxt = Entry(form)
kdratioTxt.grid(row = 5, column = 2)
#5
killstreakLbl = Label(form, text = " Killstreak:")
killstreakLbl.grid(row = 6, column = 1, padx = 40, pady = 10)
killstreakTxt = Entry(form)
killstreakTxt.grid(row = 6, column = 2)
#6
levelLbl = Label(form, text = " Level:")
levelLbl.grid(row = 7, column = 1, padx = 40, pady = 10)
levelTxt = Entry(form)
levelTxt.grid(row = 7, column = 2)
#7
loseLbl = Label(form, text = " loses:")
loseLbl.grid(row = 8, column = 1, padx = 40, pady = 10)
losesTxt = Entry(form)
losesTxt.grid(row = 8, column = 2)
#8
prestigeLbl = Label(form, text = " Prestige:")
prestigeLbl.grid(row = 9, column = 1, padx = 40, pady = 10)
prestigeTxt = Entry(form)
prestigeTxt.grid(row = 9, column = 2)
#9
hitsLbl = Label(form, text = " Hits:")
hitsLbl.grid(row = 10, column = 1, padx = 40, pady = 10)
hitsTxt = Entry(form)
hitsTxt.grid(row = 10, column = 2)
#10



#2
timeplayedLbl = Label(form, text = " TimePlayed:")
timeplayedLbl.grid(row = 2, column = 3, padx = 40, pady = 10)
timeplayedTxt = Entry(form)
timeplayedTxt.grid(row = 2, column = 4)
#3
headshotsLbl = Label(form, text = " Headshots:")
headshotsLbl.grid(row = 3, column = 3, padx = 40, pady = 10)
headshotsTxt = Entry(form)
headshotsTxt.grid(row = 3, column = 4)
#4
averagetimeLbl = Label(form, text = " AverageTime:")
averagetimeLbl.grid(row = 4, column = 3, padx = 40, pady = 10)
averagetimeTxt = Entry(form)
averagetimeTxt.grid(row = 4, column = 4)
#5
gameplayedLbl = Label(form, text = " GamePlayed:")
gameplayedLbl.grid(row = 5, column = 3, padx = 40, pady = 10)
gameplayedTxt = Entry(form)
gameplayedTxt.grid(row = 5, column = 4)
#6
assistsLbl = Label(form, text = " Assists:")
assistsLbl.grid(row = 6, column = 3, padx = 40, pady = 10)
assistsTxt = Entry(form)
assistsTxt.grid(row = 6, column = 4)
#7
missesLbl = Label(form, text = " Misses:")
missesLbl.grid(row = 7, column = 3, padx = 40, pady = 10)
missesTxt = Entry(form)
missesTxt.grid(row = 7, column = 4)
#8
xpLbl = Label(form, text = " Xp:")
xpLbl.grid(row = 8, column = 3, padx = 40, pady = 10)
xpTxt = Entry(form)
xpTxt.grid(row = 8, column = 4)
#9
scoreperminuteLbl = Label(form, text = " ScorePerMinute:")
scoreperminuteLbl.grid(row = 9, column = 3, padx = 40, pady = 10)
scoreperminuteTxt = Entry(form)
scoreperminuteTxt.grid(row = 9, column = 4)
#10
shotsLbl = Label(form, text = " Shots:")
shotsLbl.grid(row = 10, column = 3, padx = 40, pady = 10)
shotsTxt = Entry(form)
shotsTxt.grid(row = 10, column = 4)

deathsLbl = Label(form, text = " Deadths:")
deathsLbl.grid(row = 11, column = 1, padx = 40, pady = 10)
deathsTxt = Entry(form)
deathsTxt.grid(row = 11, column = 2)





lbl1 = Label(form)
lbl1.grid(column=1, row=12,padx=20,pady=20)
lbl1.configure(text="Tỉ lệ dự đoán đúng của Kmean: "+'\n'+"Silhoutte: "+str(silhouette)+'\n'+"Davie_bouldin: "+str(davies_bouldin)+'\n')


def diendulieu(): #hàm lấy ngẫu nhiên một bộ dữ liệu từ datatest 
    global index
    index=random.randint(0,len(dtTest)) #lấy ngẫu nhiên 1 bộ trong datatest
    test=originTest.iloc[index]

    nameTxt.delete(0, tk.END)
    nameTxt.insert(tk.END,test[0])
    winsTxt.delete(0, tk.END)
    winsTxt.insert(tk.END,test[1])
    killsTxt.delete(0, tk.END)
    killsTxt.insert(tk.END,test[2])
    kdratioTxt.delete(0, tk.END)
    kdratioTxt.insert(tk.END,test[3])
    killstreakTxt.delete(0, tk.END)
    killstreakTxt.insert(tk.END,test[4])
    levelTxt.delete(0, tk.END)
    levelTxt.insert(tk.END,test[5])
    losesTxt.delete(0, tk.END)
    losesTxt.insert(tk.END,test[6])
    prestigeTxt.delete(0, tk.END)
    prestigeTxt.insert(tk.END,test[7])
    hitsTxt.delete(0, tk.END)
    hitsTxt.insert(tk.END,test[8])
    timeplayedTxt.delete(0, tk.END)
    timeplayedTxt.insert(tk.END,test[9])
    headshotsTxt.delete(0, tk.END)
    headshotsTxt.insert(tk.END,test[10])
    averagetimeTxt.delete(0, tk.END)
    averagetimeTxt.insert(tk.END,test[11])
    gameplayedTxt.delete(0, tk.END)
    gameplayedTxt.insert(tk.END,test[12])
    assistsTxt.delete(0, tk.END)
    assistsTxt.insert(tk.END,test[13])
    missesTxt.delete(0, tk.END)
    missesTxt.insert(tk.END,test[14])
    xpTxt.delete(0, tk.END)
    xpTxt.insert(tk.END,test[15])
    scoreperminuteTxt.delete(0, tk.END)
    scoreperminuteTxt.insert(tk.END,test[16])
    shotsTxt.delete(0, tk.END)
    shotsTxt.insert(tk.END,test[17])
    deathsTxt.delete(0, tk.END)
    deathsTxt.insert(tk.END,test[18])


    
    print(test)
    print(index)
# lấy random ngẫu nhiên một bộ dữ liệu từ tập test đem đi phân cụm
button_Random= Button(form, text = 'Điền dữ liệu',command=diendulieu)
button_Random.grid(row = 12, column = 3, padx = 20)

def phancum(): #hàm thực hiện phân cụm cho dữ liệu được lấy random từ datatest
    # test=np.array(dtTest.iloc[index])
    test=[dtTest.iloc[index]]
    test=np.array(test)
    # print(test)
    
    global kmeans
    ketqua=kmeans.predict(test)
    lblCum.configure(text=ketqua)
    # print(index)
    print(ketqua)
    

button_Phancum = Button(form, text = 'Phân cụm',command=phancum)
button_Phancum.grid(row = 13, column = 3, padx = 20)
lblCum = Label(form, text="...")
lblCum.grid(column=4, row=12,padx=20)


form.mainloop()
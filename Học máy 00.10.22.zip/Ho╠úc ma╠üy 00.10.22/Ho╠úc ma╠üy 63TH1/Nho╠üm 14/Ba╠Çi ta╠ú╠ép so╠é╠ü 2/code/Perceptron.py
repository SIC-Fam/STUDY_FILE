import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
from sklearn import preprocessing
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
import math

# ! ==> Perceptron là một thuật toán Classification <phân lớp> cho trường hợp đơn giản nhất

# todo: dùng thư viện pandas để đọc dữ liệu từ file
data = pd.read_csv('./archive/online_shoppers_intention.csv')

# todo: mã hóa giá trị chữ thành giá trị số
le = preprocessing.LabelEncoder()
data = data.apply(le.fit_transform)

# todo: chia dữ liệu ra: 70% là tập train và 30# là tập test 
# ? shuffle: là lấy ngẫu nhiên dữ liệu
dt_train, dt_test = train_test_split(data, test_size=0.3, shuffle=True)

# ! Cái này là của tập train
# todo: chia tập train ra, x_train là giá trị để huấn luyện, y_train là nhãn
X_train = np.array(dt_train.drop('Revenue', axis=1))
Y_train = np.array(dt_train.Revenue)

# ! Cái này là của tập test
X_test = np.array(dt_test.drop('Revenue', axis=1))
Y_test = np.array(dt_test.Revenue)

# ? Cô mà hỏi là: Các em có thay bộ giá trị trong mô hình không ?
# Trả lời: có, và thấy kết quả sau khi thay nó khác nhau, kq thấp hơn hay cao hơn thì chạy chương trình mới thấy được
# todo: max_iter: số lần lặp tối đa trên tập train
# todo: shuffle: True là lấy ngãu nhiên
# todo: tol: giới hạn để dừng huấn luyện mô hình 
# todo: alpha: là hệ số góc
pct = Perceptron(max_iter=10000, shuffle=True, tol=1.0, alpha=2.0).fit(X_train, Y_train) # todo: khai báo mô hình Perceptron, .fit() dùng để huấn luyện mô hình
y_pred = pct.predict(X_test)

count = 0
for i in range(len(Y_test)):
    # todo: 
    if Y_test[i] == y_pred[i]:
        count += 1

# todo: đánh giá mức độ 
# print("Số lần đúng = ", count)
# print("accuracy_score = ", accuracy_score(Y_test, y_pred))
# print("precision_score = ", precision_score(Y_test, y_pred))
# print("recall_score = ", recall_score(Y_test, y_pred))

# print("Tỉ lệ dự đoan sai: ", 1 - 3331 / len(Y_test))

print("Nhãn lớp Y:")
print(data.iloc[:, 17])

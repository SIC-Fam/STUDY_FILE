import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn import preprocessing
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor

data = pd.read_csv('./archive/online_shoppers_intention.csv')

le = preprocessing.LabelEncoder()
data = data.apply(le.fit_transform)

dt_train, dt_test = train_test_split(data, test_size=0.3, shuffle=True)

X_train = np.array(dt_train.drop('Revenue', axis=1))
Y_train = np.array(dt_train.Revenue)
X_test = np.array(dt_test.drop('Revenue', axis=1))
Y_test = np.array(dt_test.Revenue)

# todo  max_depth: độ sâu tối đa của cây <nếu để mặc định thì chương trình sẽ mở rộng tới khi nào đạt được giá trị min_samples_split>
# todo  min_samples_split: số lượng mẫu tối thiểu cần thiết để phân chia nút nội bộ>
# todo  min_samples_leaf: số lượng mẫu tối thiểu cần có ở một nút lá>

clf = DecisionTreeClassifier(criterion='gini', splitter='best', max_depth=5, min_samples_leaf=5)
clf = clf.fit(X_train, Y_train)
y_pred = clf.predict(X_test)

count = 0

for i in range(len(Y_test)):
    if (y_pred[i] == Y_test[i]):
        count += 1

# print("Số lần đúng = ", count)
# print("accuracy_score = ", accuracy_score(Y_test, y_pred))
# print("precision_score = ", precision_score(Y_test, y_pred))
# print("recall_score = ", recall_score(Y_test, y_pred))

print("Tỉ lệ dự đoan sai: ", 1 - 3315 / len(Y_test))

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn import preprocessing
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score

# ! > 80%
data = pd.read_csv('./archive/online_shoppers_intention.csv')

le = preprocessing.LabelEncoder()
data = data.apply(le.fit_transform)

dt_train, dt_test = train_test_split(data, test_size=0.3, shuffle=True)

X_train = np.array(dt_train.drop('Revenue', axis=1))
Y_train = np.array(dt_train.Revenue)
X_test = np.array(dt_test.drop('Revenue', axis=1))
Y_test = np.array(dt_test.Revenue)

svm = SVC(C=1000.0, ).fit(X_train, Y_train)
y_pred = svm.predict(X_test)

count = 0
for i in range(len(Y_test)):
    if Y_test[i] == y_pred[i]:
        count += 1

# print("Số lần đúng = ", count)
# print("accuracy_score = ", accuracy_score(Y_test, y_pred))
# print("precision_score = ", precision_score(Y_test, y_pred))
# print("recall_score = ", recall_score(Y_test, y_pred))

print("Tỉ lệ dự đoan sai: ", 1 - 3314 / len(Y_test))


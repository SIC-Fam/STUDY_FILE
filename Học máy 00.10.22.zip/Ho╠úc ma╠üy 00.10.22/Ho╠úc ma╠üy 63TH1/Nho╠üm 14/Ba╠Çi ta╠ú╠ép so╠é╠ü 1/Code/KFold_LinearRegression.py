import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
# from Mesure_regression import NSE
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error

# Loading the dataset
data = pd.read_csv('./archive/AirFoilSelfNoise.csv')
dt_Train, dt_Test = train_test_split(data, test_size=0.3 , shuffle = False)

# todo: tinh error, y thuc te, y_pred: dl du doan
def error(y,y_pred):
    sum=0
    for i in range(0,len(y)):
        sum = sum + abs(y[i] - y_pred[i])
    return sum/len(y)  # todo: tra ve trung binh

# todo: xác định mức độ tương đối của phương sai dư so với phương sai dữ liệu đo được
# todo: NSE có giá trị trong khoảng –∞ đến 1, với NSE = 1 là giá trị tối ưu nhất, chỉ ra sự tương
# todo: đồng tuyệt đối giữa giá trị thực đo và tính toán. Tiêu chí để đánh giá chất lượng cho chỉ số
# todo: NSE có thể chia ra như sau: NSE ≤ 0,5 là xếp loại không đat; 0,5 ≤ NSE ≤ 0,65 là xếp loại
# todo: đạt yêu cầu; 0,65 ≤ NSE ≤ 0,75 là xếp loại tốt; 0,75 ≤ NSE ≤ 1 là xếp loại rất tốt~
def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))

# todo: giá trị trung bình trên mẫu thử nghiệm về sự khác biệt tuyệt đối giữa dự đoán và quan sát thực tế
def MAE(y_test, y_pred):
    return mean_absolute_error(y_test, y_pred)

# todo: khoảng cách trung bình giữa giá trị dự đoán và giá trị thực tế
# todo: Một giá trị RMSE nhỏ hơn sẽ cho thấy mô hình có hiệu suất tốt hơn, vì khoảng cách trung bình giữa dự đoán và giá trị thực tế là nhỏ.
def RMSE(y_test, y_pred):
    return mean_squared_error(y_test, y_pred, squared=False)

min=999999
k = 5
# todo: n_splits = k -> chia k phần
# todo: random_state = none -> 
kf = KFold(n_splits=k, random_state=None)

# todo: lấy lần lượt ra từng phần
for train_index, validation_index in kf.split(dt_Train):
    # todo: tách dữ liệu thành tập X và tập nhãn dán Y

    X_train = dt_Train.iloc[train_index,:5]
    X_validation = dt_Train.iloc[validation_index, :5]

    y_train = dt_Train.iloc[train_index, 5]
    y_validation = dt_Train.iloc[validation_index, 5]

    # todo: huấn luyện mô hình
    lr = LinearRegression()
    lr.fit(X_train, y_train)

    # todo: y dự đoán của tập train
    y_train_pred = lr.predict(X_train)
    # todo: y dự đoán của tập validation (tập test)
    y_validation_pred = lr.predict(X_validation)
    y_train = np.array(y_train)
    y_validation = np.array(y_validation)

    # todo: tổng trung bình của tập train + tổng trung bình của tập validation
    sum_error = error(y_train,y_train_pred) + error(y_validation, y_validation_pred)
    
    # todo: lần đánh giá hiện tại mà nhỏ hơn lần đánh giá trước đó thì min = lần đánh giá hiện tại
    
    if(sum_error < min):
        min = sum_error
        regr=lr

# todo: y_pred là giá trị dự đoán
y_test_pred=regr.predict(dt_Test.iloc[:,:5])

# todo: y_test là giá trị thực
y_test=np.array(dt_Test.iloc[:,5])

print("Thuc te        Du doan              Chenh lech")

for i in range(0,len(y_test)):
    print(y_test[i],"  ",y_test_pred[i],  "  " , abs(y_test[i]-y_test_pred[i]))

print('\n')

print("r2_score = ", r2_score(y_test, y_test_pred), '\n')

print("NSE = ", NSE(y_test, y_test_pred), '\n')

print("MAE = ", MAE(y_test, y_test_pred), '\n')

print("RMSE = ", RMSE(y_test, y_test_pred), '\n')
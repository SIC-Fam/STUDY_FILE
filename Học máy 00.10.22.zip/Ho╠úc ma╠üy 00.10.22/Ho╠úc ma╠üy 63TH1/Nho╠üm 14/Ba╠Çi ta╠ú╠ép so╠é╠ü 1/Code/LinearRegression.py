import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error

# todo: xác định mức độ tương đối của phương sai dư so với phương sai dữ liệu đo được
# todo: NSE có giá trị trong khoảng –∞ đến 1, với NSE = 1 là giá trị tối ưu nhất, chỉ ra sự tương
# todo: đồng tuyệt đối giữa giá trị thực đo và tính toán. Tiêu chí để đánh giá chất lượng cho chỉ số
# todo: NSE có thể chia ra như sau: NSE ≤ 0,5 là xếp loại không đat; 0,5 ≤ NSE ≤ 0,65 là xếp loại
# todo: đạt yêu cầu; 0,65 ≤ NSE ≤ 0,75 là xếp loại tốt; 0,75 ≤ NSE ≤ 1 là xếp loại rất tốt
def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))

# todo: giá trị trung bình trên mẫu thử nghiệm về sự khác biệt tuyệt đối giữa dự đoán và quan sát thực tế
def MAE(y_test, y_pred):
    return mean_absolute_error(y_test, y_pred)

# todo: khoảng cách trung bình giữa giá trị dự đoán và giá trị thực tế
# todo: Một giá trị RMSE nhỏ hơn sẽ cho thấy mô hình có hiệu suất tốt hơn, vì khoảng cách trung bình giữa dự đoán và giá trị thực tế là nhỏ.
def RMSE(y_test, y_pred):
    return mean_squared_error(y_test, y_pred, squared=False)

data = pd.read_csv("./archive/AirfoilSelfNoise.csv")

# False: lay 30% dong dau
# todo: lấy 70% dữ liệu làm tập train, 30% còn lại dùng làm tập test
dt_train, dt_test = train_test_split(data, test_size=0.3, shuffle=False)

# todo: train set
X_train = np.array(dt_train.iloc[:,:5])
# todo: 
Y_train = np.array(dt_train.iloc[:, 5])

# todo: test set
X_test = np.array(dt_test.iloc[:, :5])
Y_test = np.array(dt_test.iloc[:, 5])

# todo: Thuat toan
reg = LinearRegression().fit(X_train, Y_train)

# todo: y du doan cua tap test
y_pred = reg.predict(X_test)

# todo: y = y thuc (train or test)
y = Y_test

print("ThucTe      || DuDoan     || ChenhLech")
for i in range(0, len(y)):
    print(y[i], " || ", y_pred[i], " || ", abs(y[i] - y_pred[i]))

print('\n')

# todo: danh gia <0 - 1>
print("r2_score = ", r2_score(Y_test, y_pred), '\n')
print("NSE = ", NSE(Y_test, y_pred), '\n')
print("MAE = ", MAE(Y_test, y_pred), '\n')
print("RMSE = ", RMSE(Y_test, y_pred), '\n')


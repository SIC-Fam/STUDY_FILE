from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import math
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.metrics import silhouette_score, davies_bouldin_score

# todo: KMEAN dùng để phân nhóm dữ liệu

data = pd.read_csv('./archive/AirfoilSelfNoise.csv')

# todo: mã hóa
le=preprocessing.LabelEncoder()
data =data.apply(le.fit_transform)

# data = np.array( data[['Gender', 'Age', 'Annual Income (k$)', 'Spending Score (1-100)']].values )
# data = np.array( data[['buying', 'maint', 'doors', 'persons', 'lug_boot', 'safety', 'acceptability']].values )
# data = np.array( data[['V1', 'V2', 'V3', 'V4', 'V5', 'V6', 'V7', 'V8', 'V9', 'V10', 'V11', 'V12', 'V13', 'V14', 'V15', 'V16', 'V17', 'V18', 'V19', 'V20', 'V21', 'V22', 'V23', 'V24', 'Class']].values )
# data = np.array( data[['squareMeters', 'numberOfRooms', 'floors', 'cityCode', 'cityPartRange', 'numPrevOwners', 'made', 'isNewBuilt', 'hasStormProtector', 'basement', 'attic', 'garage', 'hasStorageRoom', 'hasGuestRoom', 'price', 'category', 'PoolAndYard']].values )

dt_train, dt_test = train_test_split(data, test_size=0.1, shuffle=True)
 
X = np.array(dt_train)

print('Data_test ')
print(dt_test)

# x_clusters = np.array(dt_train.head(2))

# todo: n_clusters: phân cụm [0 và 1]
# todo: random_state:
# todo: n_init:
# todo: sai số
# todo: copy_x
kmean = KMeans(n_clusters=2, random_state=19, n_init='auto', tol=0.01, copy_x=True).fit(X)

# todo: nhãn của mỗi điểm dữ liệu
label = kmean.labels_

# todo: độ đo
silhouette_score_result = silhouette_score(X, label)

davies_bouldin_score_result = davies_bouldin_score(X, label)

print('Silhouette_score = ', silhouette_score_result)
print('Davies_bouldin_score = ', davies_bouldin_score_result)

# todo: tạo giao diện
# !form
# todo: tạo cửa sổ
window = Tk()
window.title('Bài tập số 3')
window.geometry('500x500')

lable_f = Label(window, text="Tần số (f: 200 - 20.000) hz : ")
lable_f.grid(row=1, column=1, padx=40, pady=10)
textbox_f = Entry(window)
textbox_f.grid(row=1, column=2)

lable_alpha = Label(window, text="Góc (alpha: 0.0 - 30.0) : ")
lable_alpha.grid(row=2, column=1, padx=40, pady=10)
textbox_alpha = Entry(window)
textbox_alpha.grid(row=2, column=2)

lable_c = Label(window, text="Độ dài hợp âm (c: 0.0 - 0.4): ")
lable_c.grid(row=3, column=1, pady=10)
textbox_c = Entry(window)
textbox_c.grid(row=3, column=2)

lable_u = Label(window, text="Vận tốc dòng chảy (U_infinity: 31.7 - 71.3): ")
lable_u.grid(row=4, column=1, pady=10)
textbox_u = Entry(window)
textbox_u.grid(row=4, column=2)

lable_delta = Label(window, text="Độ dày dịch chuyển bên hút (delta: 0.0 - 0.06): ")
lable_delta.grid(row=5, column=1, pady=10, padx=40)
textbox_delta = Entry(window)
textbox_delta.grid(row=5, column=2)

lable_sspl = Label(window, text="Mức áp suất (SSPL: 103.0 - 141.0): ")
lable_sspl.grid(row=6, column=1, pady=10)
textbox_sspl = Entry(window)
textbox_sspl.grid(row=6, column=2)

lbl_pred = Label(window, text='Nhãn dự đoán của dữ liệu mới: ')
lbl_pred.grid(row=8, column=1, pady=10)
lbl_pred_result = Label(window, text='...')
lbl_pred_result.grid(row=8, column=2)

Silhouette = Label(window, text="Độ đo Silhouette : ")
Silhouette.grid(row=9, column=1, pady=10)
Silhouette_result = Label(window, text='...')
Silhouette_result.grid(row=9, column=2)

DaviesBouldin = Label(window, text="Độ đo DaviesBouldin : ")
DaviesBouldin.grid(row=10, column=1, pady=10)
DaviesBouldin_result = Label(window, text='...')
DaviesBouldin_result.grid(row=10, column=2)

# todo: lấy dữ liệu ra 
def dudoankmean():
    f = textbox_f.get()
    alpha = textbox_alpha.get()
    c = textbox_c.get()
    delta = textbox_delta.get()
    u = textbox_u.get()
    sspl = textbox_sspl.get()
    if ((f == '') or (alpha == '') or (c == '') or (delta == '') or (u == '') or (sspl == '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        # todo: mảng 1 chiều, -1 lấy tất cả giá trị
        x_test_input = np.array([f,alpha,c,delta, u, sspl]).reshape(1, -1)

        # todo: dự đoán nhãn để phân vào nhóm 0 hoặc 1
        label_pred = kmean.predict(x_test_input)

        # todo: 
        lbl_pred_result.configure(text=label_pred)

        # todo: giá trị càng cao thì càng tốt
        # todo: cấu hình lại cái text
        Silhouette_result.configure(text=str(round(silhouette_score_result * 100, 2)) + '%')

        # todo: giá trị càng thấp thì càng tốt
        DaviesBouldin_result.configure(text=str(round(davies_bouldin_score_result * 100, 2)) + '%')

XacNhan = Button(window,text="xác nhận",command=dudoankmean)
XacNhan.grid(row=7, column=1,padx=40, pady=10)
lbl_ketqua = Label(window, text='Kết Quả')
lbl_ketqua.grid(row=7, column=2)
    
window.mainloop()
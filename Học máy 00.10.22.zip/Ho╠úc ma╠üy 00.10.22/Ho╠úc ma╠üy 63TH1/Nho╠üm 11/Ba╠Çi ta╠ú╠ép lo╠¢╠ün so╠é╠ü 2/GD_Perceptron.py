import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
from sklearn.metrics import accuracy_score
df = pd.read_csv('../gender_classification_v7.csv')
X_data = np.array(df[['long_hair', 'forehead_width_cm',	'forehead_height_cm', 
                      'nose_wide', 'nose_long',	'lips_thin', 'distance_nose_to_lip_long', 'gender']].values)

# Hàm tính độ chính xác bằng tay
def custom_accuracy(y_true, y_pred):
    correct = 0
    total = len(y_true)
    for i in range(total):
        if y_true[i] == y_pred[i]:
            correct += 1
    return correct / total

def custom_precision(y_true, y_pred):
    if len(y_true) != len(y_pred):
        raise ValueError("Độ dài của y_true và y_pred phải giống nhau")
    # Số lượng true positives (TP) và false positives (FP)
    tp = 0
    fp = 0
    for i in range(len(y_true)):
        if y_true[i] == 1 and y_pred[i] == 1:
            tp += 1
        elif y_true[i] == 0 and y_pred[i] == 1:
            fp += 1
    # Tính precision
    if tp + fp == 0:
        precision = 0.0
    else:
        precision = tp / (tp + fp)
    return precision

def custom_recall(y_true, y_pred):
    if len(y_true) != len(y_pred):
        raise ValueError("Độ dài của y_true và y_pred phải giống nhau")
    # Số lượng true positives (TP) và false negatives (FN)
    tp = 0
    fn = 0
    for i in range(len(y_true)):
        if y_true[i] == 1 and y_pred[i] == 1:
            tp += 1
        elif y_true[i] == 1 and y_pred[i] == 0:
            fn += 1
    # Tính recall
    if tp + fn == 0:
        recall = 0.0
    else:
        recall = tp / (tp + fn)
    return recall
def custom_f1(precision, recall):
    if((precision + recall) > 0):
        f1 = (2 * precision * recall) / (precision + recall)
    else:
        f1 = 0
    return f1    

def data_encoder(X):
    for i, j in enumerate(X):
        for k in range(0, 8):
            if (j[k] == "Male"):
                j[k] = 0
            elif (j[k] == "Female"):
                j[k] = 1
    return X

data=data_encoder(X_data) #dung ham date_encoder de chuan hoa' du lieu va luu vao bien data
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True)
#print(dt_Train)
X_train = dt_Train[:, :7]
y_train = dt_Train[:, 7]
X_test = dt_Test[:, :7]
y_test = dt_Test[:, 7]

# Chuyển đổi nhãn thành kiểu số nguyên
label_encoder = LabelEncoder()
y_train = label_encoder.fit_transform(y_train)
y_test = label_encoder.transform(y_test)

pla = Perceptron(penalty='l1', max_iter=5000, eta0=0.001)
pla = pla.fit(X_train, y_train)
y_predict = pla.predict(X_test) 

# Tính độ chính xác bằng hàm custom
print('Accuracy : %.12f' % custom_accuracy(y_test, y_predict))
print('Precision : %.9f' % custom_precision(y_test, y_predict))
print('Recall : %.9f' % custom_recall(y_test, y_predict))
print('F1 : %.9f' % custom_f1(custom_precision(y_test, y_predict), custom_recall(y_test, y_predict)))
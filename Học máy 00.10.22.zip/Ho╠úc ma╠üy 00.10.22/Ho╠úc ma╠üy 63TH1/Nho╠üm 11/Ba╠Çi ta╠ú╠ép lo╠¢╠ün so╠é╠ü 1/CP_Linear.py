import pandas as pd
import numpy as np
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn import linear_model


data = pd.read_csv('./Cellphone.csv')
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle=False)

X_train = dt_Train.iloc[:, :12]
y_train = dt_Train.iloc[:, 12]
X_test = dt_Test.iloc[:, :12]
y_test = dt_Test.iloc[:, 12]

clf = linear_model.LinearRegression().fit(X_train, y_train)
print('w=', clf.coef_)
print('w0=', clf.intercept_)
y_pred = clf.predict(X_test)
y = np.array(y_test)

def tinh_nse(y_test, y_pred):
    numerator = np.sum((y_test - y_pred) ** 2)
    denominator = np.sum((y_pred - np.mean(y_pred)) ** 2)
    nse = 1 - (numerator / denominator)
    return nse

print("R2: %.9f" % r2_score(y_test, y_pred))
print("NSE: %.9f" % tinh_nse(y_test, y_pred))
print("MAE: %.9f" % mean_absolute_error(y_test, y_pred))
print("RMSE: %.9f" % np.sqrt(mean_squared_error(y_test, y_pred)))
print("Thuc te Du doan Chenh lech")
for i in range(0, len(y)):
    print("%.2f" % y[i], "  ", y_pred[i], "  ", abs(y[i]-y_pred[i]))
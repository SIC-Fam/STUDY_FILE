from tkinter import *
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
import numpy as np
import pandas as pd
from sklearn.metrics import silhouette_score, davies_bouldin_score

# Hàm để dự đoán nhãn phân cụm của mẫu mới và tính độ đo chất lượng mô hình
def predict_cluster():
    # Lấy dữ liệu từ ô textbox
    features = []
    for entry in entry_list:
        features.append(float(entry.get()))
    
    # Thực hiện dự đoán nhãn phân cụm
    predicted_label = kmeans.predict([features])
    
    # Hiển thị nhãn phân cụm
    label_text.set("Nhãn phân cụm: " + str(predicted_label[0]))
    
    # Tính độ đo chất lượng mô hình
    silhouette = silhouette_score(X_test, kmeans.predict(X_test))
    davies_bouldin = davies_bouldin_score(X_test, kmeans.predict(X_test))
    
    # Hiển thị độ đo chất lượng mô hình
    evaluation_text.set("Silhouette: {:.2f}, Davies-Bouldin: {:.2f}".format(silhouette, davies_bouldin))

# Tạo cửa sổ chính của ứng dụng GUI
form = Tk()
form.title("Người dùng")
form.geometry("240x350")

# Dữ liệu mẫu và mô hình phân cụm
df = pd.read_csv('../Water Quality Testing.csv')
X = np.array(df[['pH','Temperature','Turbidity (NTU)','Dissolved Oxygen (mg/L)','Conductivity']].values)  

dt_Train, dt_Test = train_test_split(df, test_size= 0.1, shuffle = False)
X_train = dt_Train.iloc[:, :5]
X_test = dt_Test.iloc[:, :5]
kmeans = KMeans(n_clusters=80)
kmeans.fit(X_train)
d = len(X[0])  # Số chiều của mẫu
print(d)

# Tạo các label và textbox
labels = ["Chiều " + str(i+1) + ":" for i in range(d)]
entry_list = []
for i, label_text in enumerate(labels):
    label = Label(form, text=label_text)
    label.grid(row=i, column=0, padx=15, pady=10)
    entry = Entry(form)
    entry.grid(row=i, column=1, padx=15, pady=10)
    entry_list.append(entry)

# Tạo nút dự đoán và đặt sự kiện khi click vào nút
predict_button = Button(form, text="Dự đoán", command=predict_cluster)
predict_button.grid(row=d, column=0, columnspan=2, padx=10, pady=10)

# Tạo label để hiển thị nhãn phân cụm dự đoán và độ đo chất lượng mô hình
label_text = StringVar()
label_result = Label(form, textvariable=label_text)
label_result.grid(row=d+1, column=0, columnspan=2, padx=10, pady=10)

evaluation_text = StringVar()
evaluation_result = Label(form, textvariable=evaluation_text)
evaluation_result.grid(row=d+2, column=0, columnspan=2, padx=10, pady=10)

# Gọi vòng lặp sự kiện chính để các hành động có thể diễn ra trên màn hình máy tính của người dùng
form.mainloop()
﻿from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score
from sklearn.model_selection import train_test_split
import numpy as np
import pandas as pd
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
df = pd.read_csv('Wholesale_customers_data_1.csv')
data = np.array(df[['Channel','Region','Fresh','Milk','Grocery','Frozen','Detergents','Delicassen']].values)
X_train, X_test = train_test_split(data, test_size=0.1, shuffle=True)
k_values = range(2, 11)
silhouette_scores = []
davies_bouldin_scores = []
for k in k_values:
    kmeans = KMeans(n_clusters=k, n_init=10)
    kmeans.fit(X_train)
    test_labels = kmeans.predict(X_test)
    test_silhouette = silhouette_score(X_test, test_labels)
    test_davies_bouldin = davies_bouldin_score(X_test, test_labels)
    silhouette_scores.append(test_silhouette)
    davies_bouldin_scores.append(test_davies_bouldin)
best_silhouette_index = np.argmax(silhouette_scores)
best_davies_bouldin_index = np.argmin(davies_bouldin_scores)
print(silhouette_scores)
print(davies_bouldin_scores)
best_silhouette_k = k_values[best_silhouette_index]
best_davies_bouldin_k = k_values[best_davies_bouldin_index]
best_silhouette_score = silhouette_scores[best_silhouette_index]
best_davies_bouldin_score = davies_bouldin_scores[best_davies_bouldin_index]
print("Best Silhouette Score:", silhouette_scores[best_silhouette_index], "with k =", best_silhouette_k)
print("Best Davies-Bouldin Score:", davies_bouldin_scores[best_davies_bouldin_index], "with k =", best_davies_bouldin_k)

form = Tk()
form.title("Phân cụm sản phẩm:")
form.geometry("1000x700")



lable_ten = Label(form, text = "Các loại sản phẩm:", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)

lable_channel = Label(form, text = " Kênh bán hàng:")
lable_channel.grid(row = 2, column = 1, padx = 40, pady = 10)
textbox_channel = Entry(form)
textbox_channel.grid(row = 2, column = 2)

lable_region = Label(form, text = "Vùng:")
lable_region.grid(row = 3, column = 1, pady = 10)
textbox_region = Entry(form)
textbox_region.grid(row = 3, column = 2)

lable_fresh = Label(form, text = "Doanh thu đồ tươi:")
lable_fresh.grid(row = 4, column = 1,pady = 10)
textbox_fresh = Entry(form)
textbox_fresh.grid(row = 4, column = 2)

lable_milk = Label(form, text = "Doanh thu sữa:")
lable_milk.grid(row = 5, column = 1, pady = 10)
textbox_milk = Entry(form)
textbox_milk.grid(row = 5, column = 2)

lable_groccery = Label(form, text = "Doanh thu đồ tạp hóa:")
lable_groccery.grid(row = 6, column = 1, pady = 10 )
textbox_groccery = Entry(form)
textbox_groccery.grid(row = 6, column = 2)

lable_frozen = Label(form, text = "Doanh thu đồ đông lạnh:")
lable_frozen.grid(row = 7, column = 1, pady = 10 )
textbox_frozen = Entry(form)
textbox_frozen.grid(row = 7, column = 2)

lable_detergents = Label(form, text = "Doanh thu đồ tẩy rửa:")
lable_detergents.grid(row = 8, column = 1, pady = 10 )
textbox_detergents = Entry(form)
textbox_detergents.grid(row = 8, column = 2)

lable_delicassen = Label(form, text = "Doanh thu đồ đặc sản:")
lable_delicassen.grid(row = 9, column = 1, pady = 10 )
textbox_delicassen = Entry(form)
textbox_delicassen.grid(row = 9, column = 2)

lbl = Label(form)
lbl.grid(column=1, row=10)
lbl.configure(text="Đánh giá kmeans: "+'\n'
                           +"Điểm Davies Bouldin: "+str(best_davies_bouldin_score)+'\n'
                           +"Điểm Silhouette: "+str(best_silhouette_score)+'\n')
def phanloaikmeans():
    Channel = textbox_channel.get()
    Region = textbox_region.get()
    Fresh = textbox_fresh.get()
    Milk = textbox_milk.get()
    Groccery =textbox_groccery.get()
    Frozen =textbox_frozen.get()
    Detergents = textbox_detergents.get()
    Delicassen = textbox_delicassen.get()
    if(Channel == '') or (Region == '') or (Fresh == '') or (Milk == '') or (Groccery == '')or (Frozen == '') or (Detergents == '') or (Delicassen == ''):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([Channel,Region,Fresh,Milk,Groccery,Frozen,Detergents,Delicassen]).reshape(1, -1)
        y_kqua = kmeans.predict(X_dudoan)
        print(type(str(y_kqua[0])))
        lbl.configure(text="Kết quả: "+str(y_kqua[0]))
button_kmeans = Button(form, text = 'Kết quả phân loại theo kmeans', command = phanloaikmeans)
button_kmeans.grid(row = 11, column = 1, pady = 20)
lbl = Label(form, text="...")
lbl.grid(column=2, row=12)
form.mainloop()
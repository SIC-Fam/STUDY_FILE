import pandas as pd
from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import numpy as np
from sklearn.linear_model import Lasso
from sklearn.linear_model import Ridge
from sklearn import linear_model
import csv
data = pd.read_csv('Student_Performance.csv')
X_Train = data[['Hours Studied','Previous Scores','Sleep Hours','Sample Question Papers Practiced']]
Y_Train = data['Performance Index']

model = Lasso()
model.fit(X_Train,Y_Train)
Y_pred = model.predict(X_Train)
print("Coefficent of determination: %.9f" % r2_score(Y_Train, Y_pred))
﻿from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import KFold
import numpy as np
import pandas as pd

data = pd.read_csv('Student_Performance.csv')
k = 7
kf = KFold(n_splits=k)
r2_scores = []

X = data[['Hours Studied', 'Previous Scores', 'Sleep Hours', 'Sample Question Papers Practiced']]
Y = data['Performance Index']

for train_index, test_index in kf.split(X):
    X_Train, X_Test = X.iloc[train_index], X.iloc[test_index]
    Y_Train, Y_Test = Y.iloc[train_index], Y.iloc[test_index]
    
    reg = LinearRegression().fit(X_Train, Y_Train)
    Y_pred = reg.predict(X_Test)
    score = r2_score(Y_Test, Y_pred)
    r2_scores.append(score)

print(np.mean(r2_scores))
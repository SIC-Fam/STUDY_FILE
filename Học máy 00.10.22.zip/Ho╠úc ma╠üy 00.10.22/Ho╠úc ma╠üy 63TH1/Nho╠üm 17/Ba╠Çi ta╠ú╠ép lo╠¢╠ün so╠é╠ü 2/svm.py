import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler

# Đọc dữ liệu từ file CSV
data = pd.read_csv('social.csv')

# Chuyển đổi cột 'gender' thành số sử dụng LabelEncoder
data['gender'] = data['gender'].apply(lambda x: 1 if x == 'Male' else 0)

# Chuẩn bị dữ liệu đầu vào và đầu ra
X = data[['gender', 'age', 'estimatedSalary']]
y = data['purchased']

scaler = StandardScaler()
X = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, shuffle=True)

# Khởi tạo mô hình SVC
model = SVC()

# Huấn luyện mô hình với dữ liệu huấn luyện
model.fit(X_train, y_train)

y_predict = model.predict(X_test)

count = 0
for i in range(0, len(y_predict)):
    if y_test.iloc[i] == y_predict[i]:
        count = count + 1
accuracy = count / len(y_predict)
print('Tỷ lệ dự đoán đúng:', accuracy)

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Perceptron
from sklearn.metrics import accuracy_score

# Đọc dữ liệu từ file CSV
data = pd.read_csv('social.csv')

data['gender'] = data['gender'].apply(lambda x: 1 if x == 'Male' else 0)

X = data[['gender', 'age', 'estimatedSalary']]
y = data['purchased']

# Chia dữ liệu thành tập huấn luyện và tập kiểm tra
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, shuffle=True)

# Chuẩn hóa dữ liệu (nếu cần)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Huấn luyện mô hình Perceptron
perceptron = Perceptron(max_iter=1000, shuffle=True)
perceptron.fit(X_train, y_train)


# Dự đoán trên tập kiểm tra
y_predict = perceptron.predict(X_test)
count = 0
for i in range(0, len(y_predict)):
    if y_test.iloc[i] == y_predict[i]:
        count = count + 1
accuracy = count / len(y_predict)
print('Tỷ lệ dự đoán đúng:', accuracy)

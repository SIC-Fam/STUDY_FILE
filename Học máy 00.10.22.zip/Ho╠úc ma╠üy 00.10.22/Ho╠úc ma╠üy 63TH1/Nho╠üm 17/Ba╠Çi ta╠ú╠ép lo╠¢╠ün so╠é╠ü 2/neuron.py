import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score

# Đọc dữ liệu từ file CSV
data = pd.read_csv('social.csv')

# Chuyển đổi giá trị chữ thành 0 và 1 cho cột 'gender'
data['gender'] = data['gender'].apply(lambda x: 1 if x == 'Male' else 0)

# Chia dữ liệu thành features (X) và target variable (y)
X = data[['gender', 'age', 'estimatedSalary']]
y = data['purchased']

# Chuẩn hóa dữ liệu
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Chia dữ liệu thành tập huấn luyện và tập kiểm tra
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, shuffle=True)

# Xây dựng mô hình Neural Network
model = MLPClassifier(hidden_layer_sizes=(100,), max_iter=1000, shuffle=True)

# Huấn luyện mô hình
model.fit(X_train, y_train)

# Dự đoán trên tập kiểm tra
y_pred = model.predict(X_test)

# Dự đoán trên tập kiểm tra
y_predict = model.predict(X_test)

count = 0
for i in range(0, len(y_predict)):
    if y_test.iloc[i] == y_predict[i]:
        count = count + 1
accuracy = count / len(y_predict)
print('Tỷ lệ dự đoán đúng:', accuracy)


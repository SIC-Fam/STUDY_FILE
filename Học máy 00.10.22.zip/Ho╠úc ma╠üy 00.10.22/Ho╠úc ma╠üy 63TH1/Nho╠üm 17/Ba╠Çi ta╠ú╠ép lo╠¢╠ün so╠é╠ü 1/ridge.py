import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score


# Đọc dữ liệu từ tệp CSV
data = pd.read_csv('./advertisite.csv')

# Chia dữ liệu thành biến đầu vào (X) và biến mục tiêu (y)
X = data[['TV', 'Radio', 'Newspaper']]
y = data['Sales']

# Chia dữ liệu thành tập huấn luyện và tập kiểm tra
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Xây dựng mô hình hồi quy tuyến tính Ridge
alpha = 1.0  # Tham số alpha của Ridge
ridge_reg = Ridge(alpha=alpha)

# Huấn luyện mô hình trên tập huấn luyện
ridge_reg.fit(X_train, y_train)

# Dự đoán trên tập kiểm tra
y_pred = ridge_reg.predict(X_test)

# Tính độ do R^2
r2 = r2_score(y_test, y_pred)
print(f"Độ do R^2: {r2}")

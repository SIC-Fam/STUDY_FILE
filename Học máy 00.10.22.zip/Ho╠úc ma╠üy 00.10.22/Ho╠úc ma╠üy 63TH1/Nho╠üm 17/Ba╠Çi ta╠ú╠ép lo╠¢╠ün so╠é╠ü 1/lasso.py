import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Lasso
from sklearn.metrics import r2_score


# Đọc dữ liệu từ tệp CSV
data = pd.read_csv('./advertisite.csv')

# Chia dữ liệu thành biến đầu vào (X) và biến mục tiêu (y)
X = data[['TV', 'Radio', 'Newspaper']]
y = data['Sales']

# Chia dữ liệu thành tập huấn luyện và tập kiểm tra
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Xây dựng mô hình hồi quy Lasso
alpha = 1.0  # Tham số alpha của Lasso
lasso_reg = Lasso(alpha=alpha)

# Huấn luyện mô hình trên tập huấn luyện
lasso_reg.fit(X_train, y_train)

# Dự đoán trên tập kiểm tra
y_pred = lasso_reg.predict(X_test)

# Tính độ do R^2
r2 = r2_score(y_test, y_pred)
print(f"Độ do R^2: {r2}")


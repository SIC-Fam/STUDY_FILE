from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import silhouette_score, davies_bouldin_score

data = pd.read_csv('Mall_Customers.csv')
# Chuyển đổi cột 'Genre' thành giá trị số
data['Genre'] = data['Genre'].map({'Male': 0, 'Female': 1})
X = data[['Genre', 'Age', 'Annual Income (k$)','Spending Score (1-100)' ]]
X_train, X_test = train_test_split(X, test_size=0.1 , shuffle = True)

# Sử dụng thuật toán K-means với số clusters là 5 
kmeans = KMeans(n_clusters=8, random_state=42)

# Thực hiện clustering trên dữ liệu
kmeans.fit(X.values)

# Lấy các điểm trung tâm của clusters
centroids = kmeans.cluster_centers_

# Gán labels cho các điểm dữ liệu
labels = kmeans.labels_

# Thêm cột 'Cluster' vào DataFrame để lưu trữ cluster mà mỗi điểm dữ liệu thuộc về
data['Cluster'] = labels

# In ra kết quả clustering
print(data.head())


#form
form = Tk()
form.title("Dự đoán phân khúc khách hàng:")
form.geometry("1000x500")



lable_ten = Label(form, text = "Nhập thông tin khách hàng:", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)

lable_Age = Label(form, text = "tuổi:")
lable_Age.grid(row = 3, column = 1, pady = 10)
tuoi = Entry(form)
tuoi.grid(row = 3, column = 2)

lable_AnnualIncome = Label(form, text = "Thu Nhập:")
lable_AnnualIncome.grid(row = 4, column = 1,pady = 10)
thunhap = Entry(form)
thunhap.grid(row = 4, column = 2)

lable_AnnualIncome = Label(form, text = "Giới tính:")
lable_AnnualIncome.grid(row = 5, column = 1,pady = 10)
gioitinh = Entry(form)
gioitinh.grid(row = 5, column = 2)

lable_AnnualIncome = Label(form, text = "Spending score(1-100):")
lable_AnnualIncome.grid(row = 6, column = 1,pady = 10)
spending = Entry(form)
spending.grid(row = 6, column = 2)
def calculate_metrics():
    # Lấy dữ liệu từ các textbox
    age = float(tuoi.get())
    income = float(thunhap.get())
    gender = float(gioitinh.get())
    spendingscore = float(spending.get())

    # Dự đoán cluster cho dữ liệu mới
    new_data = np.array([[age, income, gender,spendingscore ]])
    cluster = kmeans.predict(new_data)
    
    # Tính các độ đo cho cluster
    silhouette_avg = silhouette_score(X, labels)
    davies_bouldin_index = davies_bouldin_score(X, labels)
    
    # Hiển thị kết quả trên form
    lbl1.config(text="Cluster: {}".format(cluster[0]))
    lbl2.config(text="Silhouette Score: {:.2f}".format(silhouette_avg))
    lbl3.config(text="Davies-Bouldin Index: {:.2f}".format(davies_bouldin_index))

# Button để tính và hiển thị các độ đo
button_calculate = Button(form, text='Tính và Hiển thị Độ đo', command=calculate_metrics)
button_calculate.grid(row=7, column=1, pady=10)

# Các Label để hiển thị kết quả
lbl1 = Label(form, text="Cluster: ")
lbl1.grid(column=2, row=10)
lbl2 = Label(form, text="Silhouette Score: ")
lbl2.grid(column=2, row=11)
lbl3 = Label(form, text="Davies-Bouldin Index: ")
lbl3.grid(column=2, row=12)

form.mainloop()
#in giá trị các độ đo 
# Tính giá trị của Silhouette score
silhouette_avg = silhouette_score(X, labels)
print("Silhouette Score:", silhouette_avg)

# Tính giá trị của Davies-Bouldin index
davies_bouldin_index = davies_bouldin_score(X, labels)
print("Davies-Bouldin Index:", davies_bouldin_index)


import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score,mean_absolute_error,mean_squared_error #Đánh giá hiệu quả của mô hình hồi quy 1.0 là tốt nhất
from sklearn.model_selection import train_test_split
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
#doc file data
data = pd.read_csv('./giaxecu.csv')
#tao ra train va test
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle=True)

k = 3
kf = KFold(n_splits=k, random_state=None)
#du doan sai so theo y
def error(y, y_pred):
    l = []
    for i in range(0, len(y)):
        l.append(np.abs(np.array(y[i:i+1])-np.array(y_pred[i:i+1])))
    return np.mean(l)
#dang gia hieu suat mo hinh
def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))


max = 999999
i = 1
a = 0
#kiem tra cheo
for i_train, test_i_train in kf.split(dt_Train):

    X_train, X_test = dt_Train.iloc[i_train,
                                    :5], dt_Train.iloc[test_i_train, :5]
    Y_train, Y_test = dt_Train.iloc[i_train,
                                    5], dt_Train.iloc[test_i_train, 5]

    stock = LinearRegression()
    stock.fit(X_train, Y_train)
    Y_pred_train = stock.predict(X_train)
    Y_pred_test = stock.predict(X_test)
    sum = error(Y_train, Y_pred_train) + error(Y_test, Y_pred_test)
    if (sum < max):
        max = sum
        last = i
        regr = stock.fit(X_train, Y_train)
    i = i+1
#tim ra du doan tot nhat
Y_pred = regr.predict(dt_Test.iloc[:, :5])
Y = np.array(dt_Test.iloc[:, 5])


print('R^2: ', r2_score(Y_test, Y_pred_test))
print('NSE: ',NSE(Y_test,Y_pred_test))
print('MAE: ',mean_absolute_error(Y_test, Y_pred_test))
print('RMSE: ', np.sqrt(mean_squared_error(Y_test, Y_pred_test)),'\n')

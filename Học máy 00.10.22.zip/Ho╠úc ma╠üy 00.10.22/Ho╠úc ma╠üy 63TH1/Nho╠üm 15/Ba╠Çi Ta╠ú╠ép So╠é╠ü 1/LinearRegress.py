import pandas as pd
import numpy as np
from sklearn.metrics import r2_score,mean_absolute_error,mean_squared_error #Đánh giá hiệu quả của mô hình hồi quy 1.0 là tốt nhất
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
#lien ket data
data = pd.read_csv('./giaxecu.csv')
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle=True)
#ham NSE dang gia hieu suat mo hinh
def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))

#tao bien
X_train = dt_Train.iloc[:, :5]
y_train = dt_Train.iloc[:, 5]
X_test = dt_Test.iloc[:, :5]
y_test = dt_Test.iloc[:, 5]
#ham train
reg = LinearRegression().fit(X_train, y_train)
y_test_pred = reg.predict(X_test)
y_test = np.array(y_test)

print("Thuc te        Du doan              Chenh lech") #in ra du doan
for i in range(0,len(y_test)):
    print(y_test[i],"  ",y_test_pred[i],  "  " , abs(y_test[i]-y_test_pred[i]))

print('R^2: ', r2_score(y_test, y_test_pred))
print('NSE: ',NSE(y_test,y_test_pred))
print('MAE: ',mean_absolute_error(y_test, y_test_pred))
print('RMSE: ', np.sqrt(mean_squared_error(y_test, y_test_pred)),'\n')



from itertools import count
from sklearn import tree
import numpy as np
import pandas as pd
from sklearn.linear_model import Perceptron
from sklearn.svm import SVC
from sklearn import decomposition
from sklearn import metrics
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
df = pd.read_csv('heart.csv', index_col=0, parse_dates=True)
declare_data = np.array(df[['age', 'sex', 'Chest pain', 'blood pressure', 'cholesterol', 'fbs', 'restecg',
                  'max heart rate', 'exng', 'oldpeak', 'slope', 'caa', 'thal rate', 'output']].values)


def data_encoder(X):
    for i, j in enumerate(X):
        for k in range(0, 13):
            if (j[k] == "Man"):
                j[k] = 0
            elif (j[k] == "Woman"):
                j[k] = 1
            elif (j[k] == "TRUE"):
                j[k] = 2
            elif (j[k] == "FALSE"):
                j[k] = 3
            elif (j[k] == "Yes"):
                j[k] = 4
            elif (j[k] == "No"):
                j[k] = 5
    return X


data = data_encoder(declare_data)
# print(data)
data_Train, data_Test = train_test_split(data, test_size=0.3, shuffle=True)

X_train = data_Train[:, :-1]
y_train = data_Train[:, -1]
X_test = data_Test[:, :-1]
y_test = data_Test[:, -1]
# ID3
idata = tree.DecisionTreeClassifier(criterion="entropy")
idata = idata.fit(X_train, y_train)
y_pred_id3 = idata.predict(X_test)

count_id3 = 0
for i in range(0, len(y_pred_id3)):
    if (y_test[i] == y_pred_id3[i]):
        count_id3 = count_id3 + 1
print("ID3:\n", classification_report(y_test, y_pred_id3))

# CART
c_l_f = tree.DecisionTreeClassifier(criterion="gini")
c_l_f = c_l_f.fit(X_train, y_train)
y_pred = c_l_f.predict(X_test)
print("CART:\n", classification_report(y_test, y_pred))
countValue = 0
for i in range(0, len(y_pred)):
    if (y_test[i] == y_pred[i]):
        countValue = countValue + 1
#SVM
svm = SVC(kernel='poly', gamma='scale')
svm.fit(X_train, y_train)
svmPredict = svm.predict(X_test)
print("SVM:\n", classification_report(y_test, svmPredict))
count_SVM = 0
for i in range(0, len(svmPredict)):
    if (y_test[i] == svmPredict[i]):
        count_SVM = count_SVM + 1
        
# Perceptron
p_l_a = Perceptron()
p_l_a.fit(X_train, y_train)
y_predict = p_l_a.predict(X_test)
y = np.array(y_test)
print("Perceptron is :\n", classification_report(y_test, y_predict))
count_per = 0
for i in range(0, len(y_predict)):
    if (y_test[i] == y_predict[i]):
        count_per = count_per + 1
# Show
print("-----------------------------------------------------------------------")
print("Correct prediction rate of algorithms ID3: ", count_id3/len(y_pred_id3))
print("Correct prediction rate of CART: ", countValue/len(y_pred))
print("Correct prediction rate of Perceptron: ", count_per/len(y_predict))
print("Correct prediction rate of SVM: ", count_SVM/len(svmPredict))

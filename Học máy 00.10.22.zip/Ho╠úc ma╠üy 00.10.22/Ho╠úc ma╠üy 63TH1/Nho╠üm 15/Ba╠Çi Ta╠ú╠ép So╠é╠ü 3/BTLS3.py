import numpy as np
import pandas as pd

from sklearn.metrics import silhouette_score, davies_bouldin_score
from sklearn.cluster import KMeans
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from sklearn.model_selection import train_test_split


def data_encoder(X):
    for i, j in enumerate(X):
        for k in range(0, 13):
            if (j[k] == "Man"):
                j[k] = 0
            elif (j[k] == "Woman"):
                j[k] = 1
            elif (j[k] == "TRUE"):
                j[k] = 2
            elif (j[k] == "FALSE"):
                j[k] = 3
            elif (j[k] == "Yes"):
                j[k] = 4
            elif (j[k] == "No"):
                j[k] = 5
    return X

# Hàm lấy data nhập từ form
def pred_function():
    age = textbox_row_age.get()
    sex = combo_box_sex.get()
    Chestpain = textbox_row_Chestpain.get()
    bloodpre = textbox_row_bloodpre.get()
    cholesterol = textbox_row_cholesterol.get()
    fbs = combo_box_fbs.get()
    restecg = textbox_row_restecg.get()
    maxheartrate = textbox_row_maxheartrate.get()
    exng = combo_box_exng.get()
    oldpeak = textbox_row_oldpeak.get()
    slope = textbox_row_slope.get()
    caa = textbox_row_caa.get()
    thalrate = textbox_row_thalrate.get()
    if (sex == "Man"):
        sex= 0
    else:
        sex = 1
    
    if (fbs == "TRUE"):
        fbs = 2
    else:
        fbs = 3
    
    if (exng == "Yes"):
        exng = 4
    else:
        exng = 5 

    path = pd.read_csv('C:/Users/vient/Desktop/bai3/bai3/heart.csv')

    X_data = np.array(path[['age', 'sex', 'Chest pain', 'blood pressure', 'cholesterol', 'fbs',
                        'restecg', 'max heart rate', 'exng', 'oldpeak', 'slope', 'caa', 'thal rate']].values)
    
    # Mã hóa tập dữ liệu

  
    data = data_encoder(X_data)
    # Chia tập dữ liệu
    dt_Train, dt_Test = train_test_split(data, test_size=0.1, shuffle=True)
    print("Train set:\n", dt_Train)
    print("Test set:\n", dt_Test)

    X = np.array(dt_Train)
    # Mảng đã chọn
    init_array = np.array([[0, 55, 1, 1, 2, 2, 256, 40, 6], [
                          1, 70, 1, 1, 2, 4, 80, 20, 6]])
    
    # Khởi tạo mô hình K-means clustering với các trung tâm cụm từ mảng đã chọn
    kmeans = KMeans(n_clusters=2, random_state=0,
                    n_init='auto').fit(X)
     
    input_data = [age, sex, Chestpain, bloodpre, cholesterol, fbs, restecg, maxheartrate, exng, oldpeak, slope, caa, thalrate]
    predict = kmeans.predict([input_data])

    # random state la cho cta 1 vung de thuc hien random
    print("Lable Y :", kmeans.labels_)
    print("Du doan nhan cua mau du lieu:", predict)
    # In ra tâm của các cụm
    print("Tam cua cac cum:")
    print(kmeans.cluster_centers_)
    silhouette_avg = silhouette_score(X, kmeans.labels_)
    print("Silhouette score:", silhouette_avg)      #càng cao càng tốt
    davies_bouldin = davies_bouldin_score(X, kmeans.labels_)
    print("Davies bouldin score:", davies_bouldin)  #càng thấp càng tốt
    
    label_gender_dudoan = Label(form)
    label_gender_silhouette_avg = Label(form)
    label_gender_davies_bouldin = Label(form)
    label_gender_dudoan = Label(form, text="Nhan du doan la: ")
    label_gender_dudoan.grid(row=18, column=1, pady=10)
    label_gender_ketqua_dudoan=Label(form)
    label_gender_ketqua_dudoan.configure(text=predict[0])
    label_gender_ketqua_dudoan.grid(row=18, column=2, pady=10)


    silhouette_avg = silhouette_score(X, kmeans.labels_)
    label_sit = Label(form, text="Silhouette score: ")
    label_sit.grid(row=19, column=1, pady=10)
    label_gender_silhouette_avg.configure(text=str(silhouette_avg))
    label_gender_silhouette_avg.grid(row=19, column=2, pady=10)
    
    davies_bouldin = davies_bouldin_score(X, kmeans.labels_)
    label_da = Label(form, text="Davies bouldin score: ")
    label_da.grid(row=20, column=1, pady=10)
    label_gender_davies_bouldin.configure(text=str(davies_bouldin))
    label_gender_davies_bouldin.grid(row=20, column=2, pady=10)

# GIAO DIỆN FORM
form = Tk()
form.title("Bài tập tuần số 3")
form.geometry("900x640")

lable_title = Label(form, text="Nhập dữ liệu của người cần dự đoán",
                    font=("Arial", 15), fg="red")
lable_title.grid(row=0, column=1)

lable_row_age = Label(form, text="Tuổi", font=("Arial", 10))
lable_row_age.grid(row=1, column=0, padx=30, pady=5)
textbox_row_age = Entry(form, width=20)
textbox_row_age.grid(row=1, column=1)

lable_row_sex = Label(form, text="Giới tính", font=("Arial", 10))
lable_row_sex.grid(row=2, column=0, padx=30, pady=5)
sex =["Man", "Woman"]
combo_box_sex = ttk.Combobox(form, width=17, values=sex)
combo_box_sex.grid(row=2, column=1)

lable_row_Chestpain = Label(form, text="Tức ngực", font=("Arial", 10))
lable_row_Chestpain.grid(row=3, column=0, padx=30, pady=5)
textbox_row_Chestpain = Entry(form, width=20)
textbox_row_Chestpain.grid(row=3, column=1)

lable_row_bloodpre = Label(form, text="Huyết áp", font=("Arial", 10))
lable_row_bloodpre.grid(row=4, column=0, padx=30, pady=5)
textbox_row_bloodpre = Entry(form, width=20)
textbox_row_bloodpre.grid(row=4, column=1)

lable_row_cholesterol = Label(form, text="Cholesterol", font=("Arial", 10))
lable_row_cholesterol.grid(row=5, column=0, padx=30, pady=5)
textbox_row_cholesterol = Entry(form, width=20)
textbox_row_cholesterol.grid(row=5, column=1)

lable_row_fbs = Label(form, text="fbs", font=("Arial", 10))
lable_row_fbs.grid(row=6, column=0, padx=30, pady=5)
fbs =["TRUE", "FALSE"]
combo_box_fbs = ttk.Combobox(form, width=17, values=fbs)
combo_box_fbs.grid(row=6, column=1)

lable_row_restecg = Label(form, text="Restecg", font=("Arial", 10))
lable_row_restecg.grid(row=7, column=0, padx=30, pady=5)
textbox_row_restecg = Entry(form, width=20)
textbox_row_restecg.grid(row=7, column=1)

lable_row_maxheartrate = Label(form, text="Nhịp tim", font=("Arial", 10))
lable_row_maxheartrate.grid(row=1, column=2, padx=30, pady=5)
textbox_row_maxheartrate = Entry(form, width=20)
textbox_row_maxheartrate.grid(row=1, column=3)

lable_row_exng = Label(form, text="Exng", font=("Arial", 10))
lable_row_exng.grid(row=2, column=2, padx=30, pady=5)
exng =["Yes", "No"]
combo_box_exng = ttk.Combobox(form, width=17, values=exng)
combo_box_exng.grid(row=2, column=3)

lable_row_oldpeak = Label(form, text="Oldpeak", font=("Arial", 10))
lable_row_oldpeak.grid(row=3, column=2, padx=30, pady=5)
textbox_row_oldpeak = Entry(form, width=20)
textbox_row_oldpeak.grid(row=3, column=3)

lable_row_slope = Label(form, text="Slope", font=("Arial", 10))
lable_row_slope.grid(row=4, column=2, padx=30, pady=5)
textbox_row_slope = Entry(form, width=20)
textbox_row_slope.grid(row=4, column=3)

lable_row_caa = Label(form, text="Caa", font=("Arial", 10))
lable_row_caa.grid(row=5, column=2, padx=30, pady=5)
textbox_row_caa = Entry(form, width=20)
textbox_row_caa.grid(row=5, column=3)

lable_row_thalrate = Label(form, text="Thal rate", font=("Arial", 10))
lable_row_thalrate.grid(row=6, column=2, padx=30, pady=5)
textbox_row_thalrate = Entry(form, width=20)
textbox_row_thalrate.grid(row=6, column=3)

button_pred = Button(form, text='Ấn để xem kết quả', command=pred_function)
button_pred.grid(row=17, column=0, padx=30, pady=20)

form.mainloop()

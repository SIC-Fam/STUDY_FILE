# https://www.kaggle.com/datasets/fedesoriano/stroke-prediction-dataset  
import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import Perceptron 
from sklearn.metrics import accuracy_score
from sklearn import preprocessing 
from sklearn.svm import SVC
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
data = pd.read_csv('healthcare-dataset-stroke-data.csv') 
le=preprocessing.LabelEncoder() 
data=data.apply(le.fit_transform) 
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = False) 
X_train = dt_Train.drop(['id','stroke'], axis = 1) 
y_train = dt_Train['stroke'] 
X_test= dt_Test.drop(['id','stroke'], axis = 1)
y_test= dt_Test['stroke']
y_test = np.array(y_test)

clf = SVC(kernel='poly',C=3.9)
clf.fit(X_train, y_train)
y_pred=clf.predict(X_test)
# count=0
# for i in range(0,len(y_pred)):
#     # print(y_test[i],"  ",y_pred[i])
#     if(y_test[i]==y_pred[1]):
#         count+=1
# print('Ty le du doan dung cua cay quyet dinh: ',count/len(y_pred))
acc=accuracy_score(y_pred,y_test)
print('Ti le du doan dung Accuracy cua SVM: ',accuracy_score(y_pred,y_test))
print('Precision SVM: ',precision_score(y_test, y_pred,average='micro'))#average là tham số tùy chọn để xác định cách tính toán
print('recall SVM: ',recall_score(y_test, y_pred,average='micro'))
print('f1_score SVM: ',f1_score(y_test, y_pred, average='micro'))

print('Ti le du doan sai Accuracy cua SVM: ',1-accuracy_score(y_pred,y_test))
print('Precision SVM: ',1-precision_score(y_test, y_pred,average='micro'))
print('recall SVM: ',1-recall_score(y_test, y_pred,average='micro'))
print('f1_score SVM: ',1-f1_score(y_test, y_pred, average='micro'))
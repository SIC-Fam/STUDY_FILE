import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import Perceptron 
from sklearn import preprocessing 
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
data = pd.read_csv('healthcare-dataset-stroke-data.csv') 
le=preprocessing.LabelEncoder() 
data=data.apply(le.fit_transform) 
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = False) 
X_train = dt_Train.drop(['id','stroke'], axis = 1) 
y_train = dt_Train['stroke'] 
X_test= dt_Test.drop(['id','stroke'], axis = 1)
y_test= dt_Test['stroke']
y_test = np.array(y_test)
clf = DecisionTreeClassifier(criterion='entropy',min_samples_leaf=2)
clf = clf.fit(X_train, y_train)
y_pred=clf.predict(X_test)
# count=0
# print("y_test y_pred")
# for i in range(0,len(y_pred)):
#     print(y_test[i],"  ",y_pred[i])
#     if(y_test[i]==y_pred[1]):
#         count+=1
# print('Ty le du doan dung: ',count/len(y_pred))
print('Ti le du doan dung Accuracy cua ID3: ',accuracy_score(y_pred,y_test))
print('Precision ID3: ',precision_score(y_test, y_pred,average='micro'))#average là tham số tùy chọn để xác định cách tính toán
print('recall ID3: ',recall_score(y_test, y_pred,average='micro'))
print('f1_score ID3: ',f1_score(y_test, y_pred, average='micro'))

print('Ti le du doan sai Accuracy cua ID3: ',1-accuracy_score(y_pred,y_test))
print('Precision ID3: ',1-precision_score(y_test, y_pred,average='micro'))
print('recall ID3: ',1-recall_score(y_test, y_pred,average='micro'))
print('f1_score ID3: ',1-f1_score(y_test, y_pred, average='micro'))
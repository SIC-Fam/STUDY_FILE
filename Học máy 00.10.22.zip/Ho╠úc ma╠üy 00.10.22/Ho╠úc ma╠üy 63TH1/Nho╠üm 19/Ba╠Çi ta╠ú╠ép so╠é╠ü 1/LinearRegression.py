import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
def NSE(y_test, y_predict):
    return (1 - (np.sum((y_predict - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))
def MAE(y_test, y_predict):
    return mean_absolute_error(y_test, y_predict)

def RMSE(y_test, y_predict):
    return mean_squared_error(y_test, y_predict, squared=False)

dataframe = pd.read_csv('bitcoin.csv') 
dt_train,dt_test = train_test_split(dataframe,test_size=0.3,shuffle=False)
x_train = dt_train.iloc[:,1:3] 
y_train = dt_train.iloc[:,4] 
x_test = dt_test.iloc[:,1:3]
y_test = dt_test.iloc[:,4]
reg = LinearRegression().fit(x_train,y_train)
y_predict = reg.predict(x_test)
y = np.array(y_test)

print("Thuc te Du doan Chenh lech")
for i in range(0,len(y)):
    print(" ",y[i]," ",y_predict[i]," ", abs(y[i]-y_predict[i]))
print("Coef of determination LinearRegression :",r2_score(y_test,y_predict))
print("NSE LinearRegression: ", NSE(y_test,y_predict))
print('MAE LinearRegression:', MAE(y_test,y_predict))
print('RMSE LinearRegression:', RMSE(y_test,y_predict))
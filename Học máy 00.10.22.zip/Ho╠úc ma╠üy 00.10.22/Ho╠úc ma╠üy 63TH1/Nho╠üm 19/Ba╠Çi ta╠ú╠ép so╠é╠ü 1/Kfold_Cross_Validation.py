import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score 
from sklearn.model_selection import train_test_split 
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error

data = pd.read_csv('bitcoin.csv')
dt_Train, dt_Test = train_test_split(data, test_size=0.3 , shuffle = False) 
k = 5
kf = KFold(n_splits=k)

def error(y,y_pred):
    sum=0
    for i in range(0,len(y)):
        sum = sum + abs(y[i] - y_pred[i])
    return sum/len(y) 
def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))
def MAE(y_test, y_pred):
    return mean_absolute_error(y_test, y_pred)

def RMSE(y_test, y_pred):
    return mean_squared_error(y_test, y_pred, squared=False)

regr = LinearRegression()
min=999999
for train_index, val_index in kf.split(dt_Train):
    X_train = dt_Train.iloc[train_index,1:3]
    X_val = dt_Train.iloc[val_index, 1:3]
    y_train, y_val = dt_Train.iloc[train_index, 4], dt_Train.iloc[val_index, 4]

    reg = LinearRegression()
    reg.fit(X_train, y_train)
    y_train_pred = reg.predict(X_train) 
    y_val_pred = reg.predict(X_val) 
    y_train = np.array(y_train)
    y_val = np.array(y_val)
    
    sum_error = error(y_train,y_train_pred)+error(y_val, y_val_pred)
    if(sum_error < min):
        min = sum_error
        regr=reg
y_test_pred=regr.predict(dt_Test.iloc[:,1:3])
y_test=np.array(dt_Test.iloc[:,4])
print("Thuc te Du doan Chenh lech")
for i in range(0,len(y_test)):
    print(y_test[i]," ",y_test_pred[i], " " , abs(y_test[i]-y_test_pred[i]))
    
print("NSE Kfold Cross Validation: ", NSE(y_test,y_test_pred))
print ('Coef Kfold Cross Validation:',r2_score(y_test,y_test_pred)) 
print('MAE Kfold Cross Validation:', MAE(y_test,y_test_pred))
print('RMSE Kfold Cross Validation:', RMSE(y_test,y_test_pred))
import numpy as np
import pandas as pd
from tkinter import messagebox
from tkinter import ttk
from tkinter import *
# Kmean
from sklearn.metrics import accuracy_score
from sklearn.metrics import silhouette_score, davies_bouldin_score

from sklearn.cluster import KMeans
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
# giao dien
form = Tk()
form.title("Stroke prediction")
form.geometry("400x600")
# id,gender,age,hypertension,heart_disease,ever_married,Residence_type,avg_glucose_level,bmi,smoking_status


def data_encoder(X):
    for i, j in enumerate(X):
        for k in range(0, 9):
            if (j[k] == "Male"):
                j[k] = 0
            elif (j[k] == "Female"):
                j[k] = 1
            elif (j[k] == "Yes"):
                j[k] = 2
            elif (j[k] == "No"):
                j[k] = 3
            elif (j[k] == "Rural"):
                j[k] = 4
            elif (j[k] == "Urban"):
                j[k] = 5
            elif (j[k] == "formerly smoked"):
                j[k] = 6
            elif (j[k] == "never smoked"):
                j[k] = 7
            elif (j[k] == "smokes"):
                j[k] = 8
            elif (j[k] == "Unknown"):
                j[k] = 9
    return X


def get_data_form():
    gender = combo_box_gender.get()
    age = Textbox_age.get()
    hypertension = combo_box_hypertension.get()
    marriage = combo_box_marriage.get()
    Residencetype = combo_box_Residencetype.get()
    avg_glucose_level = Textbox_avg_glucose_level.get()
    BMI = Textbox_BMI.get()
    smoking = combo_box_smoking.get()
    heart_disease = combo_box_heartdisease.get()
    if (gender == "Male"):
        gender = 0
    else:
        gender = 1
    if (marriage == "Yes"):
        marriage = 2
    else:
        marriage = 3
    if (Residencetype == "Rural"):
        Residencetype = 4
    else:
        Residencetype = 5
    if (smoking == "formerly smoked"):
        smoking = 6
    elif (smoking == "never smoked"):
        smoking = 7
    elif (smoking == "smokes"):
        smoking = 8
    else:
        smoking = 9

    df = pd.read_csv("healthcare-dataset-stroke-data.csv")
    X_data = np.array(df[["gender", "age", "hypertension", "heart_disease",
                          "ever_married", "Residence_type",
                          "avg_glucose_level", "bmi", "smoking_status"]].values)
    # Mã hóa tập dữ liệu
    data = data_encoder(X_data)
    # Chia tập dữ liệu
    dt_Train, dt_Test = train_test_split(data, test_size=0.1, shuffle=True)

    X_train = np.array(dt_Train)
    X_test = np.array(dt_Test)
    # Mảng đã chọn
    init_array = np.array([[0, 67, 0, 1, 2, 5, 228.69, 36.6, 6], [1, 70, 0, 0, 2, 4, 69.04, 35.9, 6]])
    # Khởi tạo mô hình K-means clustering với các trung tâm cụm từ mảng đã chọn
    kmeans = KMeans(n_clusters=2, random_state=0,
                    n_init='auto').fit(X_train)

    # random state la cho cta 1 vung de thuc hien random
    print("Lable Y :", kmeans.labels_)
    # Dự đoán nhãn của mẫu dữ liệu
    predict = kmeans.predict([[gender, age, hypertension, heart_disease, marriage, Residencetype, avg_glucose_level, BMI, smoking]])

    # Dự đoán nhãn cho tập test
    y_predict = kmeans.predict(X_test)
    print("Du doan nhan cua mau du lieu:", predict)
    # In ra tâm của các cụm
    print("Tam cua cac cum:")
    print(kmeans.cluster_centers_)
    silhouette_avg = silhouette_score(X_test, y_predict)
    print("Silhouette score:", silhouette_avg)  # càng cao càng tốt
    davies_bouldin = davies_bouldin_score(X_test, y_predict)
    print("Davies bouldin score:", davies_bouldin)  # càng thấp càng tốt

    label_gender_dudoan = Label(form)
    label_gender_silhouette_avg = Label(form)
    label_gender_davies_bouldin = Label(form)
    label_gender_dudoan = Label(form, text="Nhan du doan la: ")
    label_gender_dudoan.grid(row=12, column=1, pady=10)
    label_gender_ketqua_dudoan = Label(form)
    label_gender_ketqua_dudoan.configure(text=predict[0])
    label_gender_ketqua_dudoan.grid(row=12, column=2, pady=10)
    # if(predict[0]==0):
    #     label_gender_dudoan.configure(text="Không có khả năng bị đột quỵ")
    #     label_gender_dudoan.grid(row=12, column=1, pady=10)

    # else:
    #     label_gender_dudoan.configure(text="Có khả năng bị đột quỵ")
    #     label_gender_dudoan.grid(row=12, column=2, pady=10)
    label_sit = Label(form, text="Silhouette score: ")
    label_sit.grid(row=13, column=1, pady=10)
    label_gender_silhouette_avg.configure(text=str(silhouette_avg))
    label_gender_silhouette_avg.grid(row=13, column=2, pady=10)
    label_da = Label(form, text="Davies bouldin score: ")
    label_da.grid(row=14, column=1, pady=10)
    label_gender_davies_bouldin.configure(text=str(davies_bouldin))
    label_gender_davies_bouldin.grid(row=14, column=2, pady=10)


# Giao Dien
label_gender = Label(form, text="Gender: ")
label_gender.grid(row=1, column=1, pady=10)
gender = ["Female", "Male"]
combo_box_gender = ttk.Combobox(form, width=17, values=gender)
combo_box_gender.set("Male")
combo_box_gender.grid(row=1, column=2, pady=10)

label_age = Label(form, text="Age (0-120): ")
label_age.grid(row=2, column=1, pady=10)
Textbox_age = Entry(form)
Textbox_age.grid(row=2, column=2, pady=10)

label_hypertension = Label(form, text="Hypertension:")
label_hypertension.grid(row=3, column=1, pady=10)
hypertension = ["0", "1"]
combo_box_hypertension = ttk.Combobox(form, width=17, values=hypertension)
combo_box_hypertension.set("0")
combo_box_hypertension.grid(row=3, column=2, pady=10)

label_heartdisease = Label(form, text="Heart disease: ")
label_heartdisease.grid(row=4, column=1, pady=10)
heartdisease = ["0", "1"]
combo_box_heartdisease = ttk.Combobox(form, width=17, values=heartdisease)
combo_box_heartdisease.set("0")
combo_box_heartdisease.grid(row=4, column=2, pady=10)

label_marriage = Label(form, text="Ever Married? ")
label_marriage.grid(row=5, column=1, pady=10)
marriage = ["Yes", "No"]
combo_box_marriage = ttk.Combobox(form, width=17, values=marriage)
combo_box_marriage.set("Yes")
combo_box_marriage.grid(row=5, column=2, pady=10)

label_Residencetype = Label(form, text="Residence type: ")
label_Residencetype.grid(row=7, column=1, pady=10)
Residencetype = ["Rural", "Urban"]
combo_box_Residencetype = ttk.Combobox(form, width=17, values=Residencetype)
combo_box_Residencetype.set("Rural")
combo_box_Residencetype.grid(row=7, column=2, pady=10)

label_avg_glucose_level = Label(form, text="Avg glucose level (100-215): ")
label_avg_glucose_level.grid(row=8, column=1, pady=10)
Textbox_avg_glucose_level = Entry(form)
Textbox_avg_glucose_level.grid(row=8, column=2, pady=10)

label_BMI = Label(form, text="BMI (18-41): ")
label_BMI.grid(row=9, column=1, pady=10)
Textbox_BMI = Entry(form)
Textbox_BMI.grid(row=9, column=2, pady=10)

label_smoking = Label(form, text="Smoking: ")
label_smoking.grid(row=10, column=1, pady=10)
smokeType = ["formerly smoked", "never smoked", "smokes", "Unknown"]
combo_box_smoking = ttk.Combobox(form, width=17, values=smokeType)
combo_box_smoking.set("formerly")
combo_box_smoking.grid(row=10, column=2, pady=10)

button = ttk.Button(form, text="Predict", command=get_data_form)
button.grid(row=11, column=2, pady=10)

form.mainloop()

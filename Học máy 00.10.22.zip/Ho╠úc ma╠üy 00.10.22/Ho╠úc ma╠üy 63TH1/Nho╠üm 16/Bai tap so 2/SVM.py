import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC  # for classification
from sklearn.preprocessing import LabelEncoder
from sklaern import Accuracy, Precision, Recall, F1

from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
df = pd.read_csv('D:\Machine-Learning\pank-chua-ma-hoa.csv')

# encode
label_encoder = LabelEncoder()
df = df.apply(label_encoder.fit_transform)

dt_Train, dt_Test = train_test_split(df, test_size=0.3, shuffle = True)

X_train = dt_Train.iloc[:, :16]
y_train = dt_Train.iloc[:, 16]
X_test = dt_Test.iloc[:, :16]
y_test = dt_Test.iloc[:, 16]

svm_classifier = SVC(kernel='rbf',C=0.1, gamma='auto').fit(X_train, y_train)

y_pred = svm_classifier.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

precision = precision_score(y_test,y_pred)
recall = recall_score(y_test,y_pred)
f1 = f1_score(y_test,y_pred)

print("Accuracy : ", Accuracy) 
print("Precision : ", Precision)
print("Recall : ", Recall)
print("F1 : ",  F1)


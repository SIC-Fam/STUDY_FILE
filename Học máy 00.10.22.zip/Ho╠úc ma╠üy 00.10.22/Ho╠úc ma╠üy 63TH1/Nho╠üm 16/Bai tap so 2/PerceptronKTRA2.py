import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
from sklearn.preprocessing import LabelEncoder

from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score

df = pd.read_csv('C:/Users/Admin/Desktop/PYTHON/guitienkihan.csv')

#encode
label_encoder = LabelEncoder()
df = df.apply(label_encoder.fit_transform)

dt_Train, dt_Test = train_test_split(df, test_size=0.3, shuffle = True)

X_train = dt_Train.iloc[:, :16]
y_train = dt_Train.iloc[:, 16]
X_test = dt_Test.iloc[:, :16]
y_test = dt_Test.iloc[:, 16]

pla = Perceptron().fit(X_train, y_train)
y_pred = pla.predict(X_test) 
print('Perceptron')
print('Accuracy : %.9f' % accuracy_score(y_test,y_pred)) #du doan do chinh xac cua du lieu
print('Precision : %.9f' % precision_score(y_test,y_pred)) #muc do gan cua cac phep do lap lai voi nhau
print('Recall : %.9f' % recall_score(y_test,y_pred)) #phat hien cac truong hop duong tinh trong du lieu
print('F1 : %.9f' % f1_score(y_test,y_pred)) #se cao neu du doan duoc nhieu nguoi gui tien va chinh xac ng gui tien

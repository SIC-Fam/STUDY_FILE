import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

from sklearn.preprocessing import LabelEncoder

from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
df = pd.read_csv('C:/Users/Admin/Desktop/PYTHON/guitienkihan.csv')

#encode
label_encoder = LabelEncoder()
df = df.apply(label_encoder.fit_transform)

dt_Train, dt_Test = train_test_split(df, test_size=0.3, shuffle = True)

X_train = dt_Train.iloc[:, :16]
y_train = dt_Train.iloc[:, 16]
X_test = dt_Test.iloc[:, :16]
y_test = dt_Test.iloc[:, 16]

clf=DecisionTreeClassifier(criterion='gini').fit(X_train,y_train)
y_pred = clf.predict(X_test) 
print('CART')
print('Accuracy : %.9f' % accuracy_score(y_test,y_pred)) 
print('Precision : %.9f' % precision_score(y_test,y_pred))
print('Recall : %.9f' % recall_score(y_test,y_pred))
print('F1 : %.9f' % f1_score(y_test,y_pred))
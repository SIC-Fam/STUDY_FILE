from sklearn.cluster import KMeans
import random
import numpy as np
import pandas as pd
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import tkinter as tk
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import silhouette_score, davies_bouldin_score
from sklearn.model_selection import train_test_split
index=0 #tạo biến lấy random 1 dòng code trong datatest
df=pd.read_csv('./CustomerSegment.csv') #đọc file dữ liệu
df=df.iloc[:,:-1] #loại bỏ nhãn
# originTest=df
# label_encoder = LabelEncoder()
# df = df.apply(label_encoder.fit_transform)
dtTrain, dtTest = train_test_split(df, test_size=0.1, shuffle = True) #chia dữ liệu

originTest=dtTest # lấy dữ liệu test nguyên bản chưa mã hóa

label_encoder = LabelEncoder() 
dtTrain = dtTrain.apply(label_encoder.fit_transform) #mã hóa dữ liệu huấn luyện

label_encoder = LabelEncoder()
dtTest = dtTest.apply(label_encoder.fit_transform) #mã hóa dữ liệu test

kmeans = KMeans(n_clusters=4, n_init='auto').fit(dtTrain.values) #tạo mô hình kmean với 4 cụm
# print(kmeans.predict(dtTest)) 
# print(kmeans.labels_)
# print(dtTest.shape)
silhouette=silhouette_score(dtTrain, kmeans.labels_) #càng lớn càng tốt
davies_bouldin=davies_bouldin_score(dtTrain, kmeans.labels_) #càng nhỏ càng tốt

# print(test)
# print(kmeans.cluster_centers_)

# form
form = Tk()
form.title("Phân cụm khách hàng:")
form.geometry("800x800")



lable_ten = Label(form, text = "Nhập thông tin khách hàng:", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)

lableId = Label(form, text = " Id:")
lableId.grid(row = 2, column = 1, padx = 40, pady = 10)
textboxId = Entry(form)
textboxId.grid(row = 2, column = 2)
textboxId.insert(tk.END,"tong tuan")

lableGender = Label(form, text = "Gender:")
lableGender.grid(row = 3, column = 1, pady = 10)
textboxGender = Entry(form)
textboxGender.grid(row = 3, column = 2)

lableEverMaried = Label(form, text = "Ever Married:")
lableEverMaried.grid(row = 4, column = 1,pady = 10)
textboxEverMaried = Entry(form)
textboxEverMaried.grid(row = 4, column = 2)

lableAge= Label(form, text = "Age:")
lableAge.grid(row = 5, column = 1, pady = 10)
textboxAge= Entry(form)
textboxAge.grid(row = 5, column = 2)

lableGraduate = Label(form, text = "Graduate:")
lableGraduate.grid(row = 6, column = 1, pady = 10 )
textboxGraduate = Entry(form)
textboxGraduate.grid(row = 6, column = 2)

lableProfession= Label(form, text = "Profession:")
lableProfession.grid(row = 7, column = 1, pady = 10 )
textboxProfession = Entry(form)
textboxProfession.grid(row = 7, column = 2)

lableWork_Experience = Label(form, text = "Work_Experience:")
lableWork_Experience.grid(row = 8, column = 1, pady = 10 )
textboxWork_Experience = Entry(form)
textboxWork_Experience.grid(row = 8, column = 2)

lableSpending_Score = Label(form, text = "Spending_Score:")
lableSpending_Score.grid(row = 9, column = 1, pady = 10 )
textboxSpending_Score = Entry(form)
textboxSpending_Score.grid(row = 9, column = 2)

lableFamily_Size = Label(form, text = "Family_Size:")
lableFamily_Size.grid(row = 10, column = 1, pady = 10 )
textboxFamily_Size = Entry(form)
textboxFamily_Size.grid(row = 10, column = 2)

lableVar_1 = Label(form, text = "Var_1:")
lableVar_1.grid(row = 11, column = 1, pady = 10 )
textboxVar_1 = Entry(form)
textboxVar_1.grid(row = 11, column = 2)


lbl1 = Label(form)
lbl1.grid(column=1, row=12,padx=20,pady=20)
lbl1.configure(text="Tỉ lệ dự đoán đúng của Kmean: "+'\n'+"Silhoutte: "+str(silhouette)+'\n'+"Davie_bouldin: "+str(davies_bouldin)+'\n')


def diendulieu(): #hàm lấy ngẫu nhiên một bộ dữ liệu từ datatest 
    global index
    index=random.randint(0,len(dtTest))
    test=originTest.iloc[index]
    textboxId.delete(0, tk.END)
    textboxId.insert(tk.END,test[0])
    textboxGender.delete(0, tk.END)
    textboxGender.insert(tk.END,test[1])
    textboxEverMaried.delete(0, tk.END)
    textboxEverMaried.insert(tk.END,test[2])
    textboxAge.delete(0, tk.END)
    textboxAge.insert(tk.END,test[3])
    textboxGraduate.delete(0, tk.END)
    textboxGraduate.insert(tk.END,test[4])
    textboxProfession.delete(0, tk.END)
    textboxProfession.insert(tk.END,test[5])
    textboxWork_Experience.delete(0, tk.END)
    textboxWork_Experience.insert(tk.END,test[6])
    textboxSpending_Score.delete(0, tk.END)
    textboxSpending_Score.insert(tk.END,test[7])
    textboxFamily_Size.delete(0, tk.END)
    textboxFamily_Size.insert(tk.END,test[8])
    textboxVar_1.delete(0, tk.END)
    textboxVar_1.insert(tk.END,test[9])
    print(test)
    print(index)
# lấy random ngẫu nhiên một bộ dữ liệu từ tập test đem đi phân cụm
button_Random= Button(form, text = 'Điền dữ liệu',command=diendulieu)
button_Random.grid(row = 10, column = 3, padx = 20)

def phancum(): #hàm thực hiện phân cụm cho dữ liệu được lấy random từ datatest
    # test=np.array(dtTest.iloc[index])
    test=[dtTest.iloc[index]]
    test=np.array(test)
    print(test)
    kmeans.fit(dtTrain.values)
    ketqua=kmeans.predict(test)
    Cum.configure(text=ketqua)
    print(index)
    print(ketqua)
    

button_Phancum = Button(form, text = 'Phân cụm',command=phancum)
button_Phancum.grid(row = 11, column = 3, padx = 20)
Cum = Label(form, text="...")
Cum.grid(column=4, row=11,padx=20)
form.mainloop()
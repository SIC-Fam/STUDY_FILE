from tkinter import *
import tkinter
import numpy as np
import pandas as pd
from sklearn.metrics import silhouette_score,davies_bouldin_score
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
from sklearn import preprocessing
window = tkinter.Tk()#This method creates a blank window with close, maximize, and minimize buttons on the top as a usual GUI should have
window.title("GUI")
# label = tkinter.Label(window,text="Welcome").pack()
# top_frame = tkinter.Frame(window).pack()
#Clean the data
df = pd.read_csv('F:\Machine Learning\BaiNhom\BTL3\Customers.csv').drop("CustomerID",axis=1)
print(df.isna().sum()) #Kiểm tra dữ liệu rỗng thấy cột Profession có 35 giá trị NA
#min_sample_split so mau toi thieu de phan chia (Moi mot ,Node phai co toi thieu min_sample_split)
#drop row bị missing values
df1 = df.dropna(axis = 0).reset_index(drop= True)
print(df1.value_counts("Profession").unique())
#kiểm tra lại
print(df1.isna().sum())
#kiểm tra xem có row nào bị trùng nhau không
print(df1.duplicated().sum())
#Matrix của df1 sau khi tiền xử lý dữ liệu là
print(df1.shape)
encode_values = {
    "Gender":{"Female":0,"Male":1},
    "Profession":{"Healthcare":0,"Engineer":1,"Lawyer":2,"Entertainment":3,
                  "Artist":4,"Executive":5,"Doctor":6,"Homemaker":7,"Marketing":8}
}
data = df1.replace(encode_values)
print(data)
dt_Train,dt_Test = train_test_split(data,test_size=0.1,shuffle=True)
X_train = dt_Train.iloc[:, :7]
X_test = dt_Test.iloc[:, :7]
print(X_train)
num_cluster = [i for i in range(2,12)]
#Độ đo sil
def sil_score(num_cluster,val):
    sil_sc = []
    for num in num_cluster:
        kmeans = KMeans(n_clusters=num,random_state=42,n_init='auto').fit(X_train.values)
        sil_sc.append(silhouette_score(X_train.values,kmeans.labels_))
    return sil_sc
sil_sc = sil_score(num_cluster,X_train) 
print(sil_sc)# thấy k = 7 là tốt nhất
def dav_score(num_cluster,val):
    dav_score = []
    k_values = []
    for num in num_cluster:
        kmeans = KMeans(n_clusters=num,random_state=42,n_init='auto').fit(X_train.values)
        dav_score.append(davies_bouldin_score(X_train.values,kmeans.labels_))
    return dav_score
dav_score = dav_score(num_cluster,X_train) 
print(dav_score)# thấy k = 7 là tốt nhất
kmeans = KMeans(n_clusters=9,n_init='auto').fit(X_train.values)
kmsSil_sc = silhouette_score(X_train.values,kmeans.labels_)
kmsDav_sc = davies_bouldin_score(X_train.values,kmeans.labels_)
myHeader = ["Gender","Age","Annual Income ($)","Spending Score (1-100)","Profession","Work Experience (Years)","Family Size"]
varList = [StringVar() for i in range(0,len(myHeader))]
for i in range(0,len(myHeader)):
    tkinter.Label(window,text=myHeader[i]).grid(row=i,column=0)
    tkinter.Entry(window,textvariable=varList[i]).grid(row=i,column=1)
def retrive_input():
    res = []
    for i in range(0,len(varList)):
        # print(varList[i].get())
        value = varList[i].get()
        print(value)
        res.append(value)
    rowData = pd.DataFrame([res])
    rowData.columns = myHeader
    rowDataEncode = rowData.replace(encode_values)
    print(rowDataEncode)
    y_predict = kmeans.predict(rowDataEncode.values)
    lbl =tkinter.Label(window, text = 'Nhãn của mẫu thuộc clustering thứ '+str(y_predict)).grid(row=16,column=0)

    # lbl.config(text="Giá trị dự đoán: "+y_predict)
tkinter.Button(window,text="Dự đoán",command=retrive_input).grid(row=15,column=0)
tkinter.Label(window,text = "Độ đo Silhouette: "+str(kmsSil_sc)).grid(row =0,column=2 , padx=10)
tkinter.Label(window,text = "Độ đo Davies-Bouldin.: "+str(kmsDav_sc)).grid(row = 1 ,column=2,padx=10)
print(kmeans.labels_)
print(kmeans.cluster_centers_)
# txt1 = tkinter.Text(top_frame) 
window.mainloop()

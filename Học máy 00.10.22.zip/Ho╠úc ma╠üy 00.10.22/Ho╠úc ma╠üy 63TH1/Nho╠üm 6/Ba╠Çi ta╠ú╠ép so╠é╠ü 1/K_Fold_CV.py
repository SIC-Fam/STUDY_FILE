#K Fold Cross - validation
# from sklearn.model_selection import cross_validate,cross_val_score,train_test_split,cross_val_predict
# import pandas as pd;
# from sklearn.linear_model import LinearRegression
# import numpy as np
from sklearn.metrics import r2_score,mean_absolute_error,mean_squared_error
# dataframe = pd.read_csv('./lr_lifeExpectancy/Life-Expectancy-Data-Updated.csv')
# dt_train,dt_test = train_test_split(dataframe,test_size=0.3,shuffle=False)
# x_train = dt_train.iloc[:,3:20]
# y_train = dt_train.iloc[:,20]
# x_test = dt_test.iloc[:,3:20]
# y_test = dt_test.iloc[:,20]
# #10-fold cv
# model = LinearRegression()
# mymodel = model.fit(x_train,y_train)
# #Prediction
# for i in range(2,15): #cv = 9 la tot nhat 
#     print("CV = ",i)
#     y_pred = cross_val_predict(mymodel,x_test,y_test,cv=i)
#     print('R^2: ', r2_score(y_test, y_pred))
#     print('MAE: ',mean_absolute_error(y_test, y_pred))
#     print('MSE: ', mean_squared_error(y_test, y_pred))
#     print('RMSE: ', np.sqrt(mean_squared_error(y_test, y_pred)),'\n')

import pandas as pd
from sklearn.metrics import r2_score
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import numpy as np
def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))
# Loading the dataset
data = pd.read_csv('./lr_lifeExpectancy/Life-Expectancy-Data-Updated.csv')
dt_Train, dt_Test = train_test_split(data, test_size=0.3 , shuffle = False)
#dt_Train gồm x_train và y_train tương tự với dt_Test

# tinh error, y thuc te, y_pred: dl du doan
def error(y,y_pred):
    sum=0
    for i in range(0,len(y)):
        sum = sum + abs(y[i] - y_pred[i])
    return sum/len(y)  # tra ve trung binh

min=999999
k = 10
kf = KFold(n_splits=k, random_state=None) 
print(kf)
for train_index, validation_index in kf.split(dt_Train):#chia dt_train thành k tệp dữ liệu. 1 phần validate và 4 phần train lặp 5 
    X_train, X_validation = dt_Train.iloc[train_index,3:20], dt_Train.iloc[validation_index, 3:20]
    y_train, y_validation = dt_Train.iloc[train_index, 20], dt_Train.iloc[validation_index, 20]
    #huấn luyện mô hình 
    lr = LinearRegression()
    lr.fit(X_train, y_train)
    y_train_pred = lr.predict(X_train) #dự đoán tập y_train
    y_validation_pred = lr.predict(X_validation) #dự đoán tập validation
    y_train = np.array(y_train)
    y_validation = np.array(y_validation)
    #lấy error = validation error + train error nhỏ nhất
    sum_error = error(y_train,y_train_pred)+error(y_validation, y_validation_pred)
    
    if(sum_error < min):
        min = sum_error
        regr=lr

y_test_pred=regr.predict(dt_Test.iloc[:,3:20])
y_test=np.array(dt_Test.iloc[:,20])
print("Thuc te        Du doan              Chenh lech")
for i in range(0,len(y_test)):
    print(y_test[i],"  ",y_test_pred[i],  "  " , abs(y_test[i]-y_test_pred[i]))
print("KFold CV scores")
print('R^2: ', r2_score(y_test, y_test_pred))
print('NSE: ',NSE(y_test,y_test_pred))
print('MAE: ',mean_absolute_error(y_test, y_test_pred))
print('RMSE: ', np.sqrt(mean_squared_error(y_test, y_test_pred)),'\n')
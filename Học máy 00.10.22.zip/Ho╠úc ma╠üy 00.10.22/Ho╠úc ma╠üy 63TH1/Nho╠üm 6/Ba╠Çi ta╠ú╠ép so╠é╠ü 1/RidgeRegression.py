import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score,mean_absolute_error,mean_squared_error #Đánh giá hiệu quả của mô hình hồi quy 1.0 là tốt nhất
from sklearn.model_selection import train_test_split
def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))
dataframe = pd.read_csv('./lr_lifeExpectancy/Life-Expectancy-Data-Updated.csv')
dt_train,dt_test = train_test_split(dataframe,test_size=0.3,shuffle=True)
x_train = dt_train.iloc[:,3:20]
y_train = dt_train.iloc[:,20]
x_test = dt_test.iloc[:,3:20]
y_test = dt_test.iloc[:,20]
#Hồi quy LR có hệ số bias
reg = Ridge().fit(x_train,y_train)
y_test_pred = reg.predict(x_test) #du doan tập nhãn của x_test
y_test = np.array(y_test)
print("Thuc te        Du doan              Chenh lech")
for i in range(0,len(y_test)):
    print(y_test[i],"  ",y_test_pred[i],  "  " , abs(y_test[i]-y_test_pred[i]))
print("RidgeRegression scores")
print('R^2: ', r2_score(y_test, y_test_pred))
print('NSE: ',NSE(y_test,y_test_pred))
print('MAE: ',mean_absolute_error(y_test, y_test_pred))
print('RMSE: ', np.sqrt(mean_squared_error(y_test, y_test_pred)),'\n')
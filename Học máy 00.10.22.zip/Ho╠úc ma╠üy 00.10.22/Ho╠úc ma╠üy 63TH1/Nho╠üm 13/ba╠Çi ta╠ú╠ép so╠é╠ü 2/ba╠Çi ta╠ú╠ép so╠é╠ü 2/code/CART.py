import pandas as pd
from sklearn.model_selection import train_test_split
import numpy as np
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score
from sklearn.tree import DecisionTreeClassifier
from sklearn import preprocessing

# Đọc dữ liệu từ tệp csv 'cars.csv' và lưu vào biến data.
data = pd.read_csv('./diabetes_prediction_dataset.csv')
le=preprocessing.LabelEncoder() 
data=data.apply(le.fit_transform)
# Chia dữ liệu thành tập huấn luyện và tập kiểm tra, với tỷ lệ 70% cho tập huấn luyện và 30% cho tập kiểm tra. Dữ liệu không được xáo trộn trước khi chia.
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = False)
X_train = dt_Train.drop(['diabetes'], axis = 1) 
y_train = dt_Train['diabetes'] 
X_test= dt_Test.drop(['diabetes'], axis = 1)
y_test= dt_Test['diabetes']
y_test = np.array(y_test)
# Xây dựng mô hình Neural Network
tree = DecisionTreeClassifier()
# Huấn luyện mô hình Neural Network trên tập huấn luyện.
tree.fit(X_train, y_train)

# Dự đoán nhãn cho tập kiểm tra.
y_pred =tree.predict(X_test)

# Tính độ chính xác của mô hình.
print('Accuracy_score: ' ,accuracy_score(y_pred,y_test))
print('Precision_score: ',precision_score(y_test, y_pred,average='micro'))
print('Recall_score: ',recall_score(y_test, y_pred,average='micro'))
print('f1_score: ',f1_score(y_test, y_pred, average='micro'))



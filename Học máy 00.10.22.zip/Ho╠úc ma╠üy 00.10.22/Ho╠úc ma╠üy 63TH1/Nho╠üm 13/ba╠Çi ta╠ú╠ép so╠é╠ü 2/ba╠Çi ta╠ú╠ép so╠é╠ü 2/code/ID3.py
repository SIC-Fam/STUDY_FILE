import pandas as pd
from sklearn.model_selection import train_test_split
import numpy as np
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
from sklearn import preprocessing
# Đọc dữ liệu từ tệp csv 'cars.csv' và lưu vào biến data.
df = pd.read_csv('./diabetes_prediction_dataset.csv')
le=preprocessing.LabelEncoder() 
data=df.apply(le.fit_transform)

# Chia dữ liệu thành tập huấn luyện và tập kiểm tra, với tỷ lệ 70% cho tập huấn luyện và 30% cho tập kiểm tra. Dữ liệu không được xáo trộn trước khi chia.
dt_Train, dt_Test = train_test_split(data, test_size=0.3, shuffle = True)
X_train = dt_Train.drop(['diabetes'], axis = 1) 
y_train = dt_Train['diabetes'] 
X_test= dt_Test.drop(['diabetes'], axis = 1)
y_test= dt_Test['diabetes']
y_test = np.array(y_test)

# Xây dựng mô hình Neural Network
model=tree.DecisionTreeClassifier(criterion='entropy')
# Huấn luyện mô hình Neural Network trên tập huấn luyện.
model.fit(X_train, y_train)

# Dự đoán nhãn cho tập kiểm tra.
y_pred =model.predict(X_test)
count = 0
for i in range(0,len(y_pred)):
    if(y_test[i] == y_pred[i]):
        count = count + 1
# Tính độ chính xác của mô hình.
print("Accuracy_score:",count/len(y_pred))
print('Precision_score: ',precision_score(y_test,y_pred))
print('Recall_score: ',recall_score(y_test,y_pred ))
print('f1_score: ',f1_score(y_test, y_pred))


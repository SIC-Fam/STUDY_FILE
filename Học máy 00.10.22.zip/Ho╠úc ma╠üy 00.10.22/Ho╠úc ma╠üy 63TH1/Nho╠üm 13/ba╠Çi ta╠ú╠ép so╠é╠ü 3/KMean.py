from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import davies_bouldin_score
from sklearn.metrics import silhouette_score
from sklearn.model_selection import train_test_split


df = pd.read_csv('./Iris.csv')
X = np.array(df[['Id','SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']].values)    
y = np.array(df['Species'])

# Chia tập dữ liệu thành tập huấn luyện và tập kiểm tra
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=1)

# Clustering bằng K-means
kmeans = KMeans(n_clusters=6,n_init=10)
labels = kmeans.fit_predict(X_train)

# Đánh giá độ phù hợp của mô hình bằng chỉ số Silhouette
silhouette = silhouette_score(X_train, labels)

# Đánh giá độ phù hợp của mô hình bằng chỉ số Davies-Bouldin
davies_bouldin  = davies_bouldin_score(X_train, labels)
#form
form = Tk()
form.title("Dự đoán loài hoa:")
form.geometry("1000x500")

lable_ten = Label(form, text = "Nhập thông tin loài hoa:", font=("Arial Bold", 10), fg="red")
lable_ten.grid(row = 1, column = 1, padx = 40, pady = 10)

lable_Id = Label(form, text = " ID:")
lable_Id.grid(row = 2, column = 1, padx = 40, pady = 10)
textbox_Id = Entry(form)
textbox_Id.grid(row = 2, column = 2)

lable_SepalLengthCm = Label(form, text = "Chiều dài lá đài:")
lable_SepalLengthCm.grid(row = 3, column = 1, pady = 10)
textbox_SepalLengthCm = Entry(form)
textbox_SepalLengthCm.grid(row = 3, column = 2)

lable_SepalWidthCm = Label(form, text = "Chiều rộng lá đài:")
lable_SepalWidthCm.grid(row = 4, column = 1,pady = 10)
textbox_SepalWidthCm = Entry(form)
textbox_SepalWidthCm.grid(row = 4, column = 2)

lable_PetalLengthCm= Label(form, text = "Chiều dài cánh hoa:")
lable_PetalLengthCm.grid(row = 5, column = 1, pady = 10)
textbox_PetalLengthCm = Entry(form)
textbox_PetalLengthCm.grid(row = 5, column = 2)

lable_PetalWidthCm= Label(form, text = "Chiều rộng cánh hoa:")
lable_PetalWidthCm.grid(row = 6, column = 1, pady = 10)
textbox_PetalWidthCm = Entry(form)
textbox_PetalWidthCm.grid(row = 6, column = 2)


def predict_cluster():
    Id = textbox_Id.get()
    SepalLengthCm= textbox_SepalLengthCm.get()
    SepalWidthCm = textbox_SepalWidthCm.get()
    PetalLengthCm = textbox_PetalLengthCm.get()
    PetalWidthCm = textbox_PetalWidthCm.get()
    
    if((Id == '') or (SepalLengthCm == '') or (SepalWidthCm == '') or (PetalLengthCm == '') or (PetalWidthCm== '')):
        messagebox.showinfo("Thông báo", "Bạn cần nhập thông tin đầy đủ !")
    else:
        X_dudoan = np.array([Id,SepalLengthCm,SepalWidthCm,PetalLengthCm,PetalWidthCm]).reshape(1, -1)
        y_kqua = kmeans.predict(X_dudoan)
        lbl1 = Label(form)
        lbl1.grid(column=1, row =10)
        lbl1.configure(text = "khả năng dự đoán: ")
button_btn = Button(form, text = 'kết quả ', command = predict_cluster )
button_btn.grid(row = 7, column = 1, padx = 30)
lbl2= Label(form, text="silhouette")
lbl2.grid(row = 7, column=2)
lbl2.configure(text="Độ đo: "+'\n'
                           +"Silhouette: "+str(silhouette)+'\n'
                           +"Davies_Bouldin: "+str(davies_bouldin)+'\n')


form.mainloop()


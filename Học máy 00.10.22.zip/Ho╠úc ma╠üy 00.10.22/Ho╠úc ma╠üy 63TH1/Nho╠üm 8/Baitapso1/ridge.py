import pandas as pd
from sklearn.metrics import r2_score
from sklearn.linear_model import Ridge
from sklearn.model_selection import train_test_split
import numpy as np
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from math import sqrt
data=pd.read_csv('Heart_Disease_Prediction.csv')
dt_Train,dt_Test = train_test_split(data,test_size=0.3,shuffle=False) 
X_Train=dt_Train.iloc[:,:13] 
y_Train=dt_Train.iloc[:,13] 
X_Test=dt_Test.iloc[:,:13] 
y_Test=dt_Test.iloc[:,13] 
clf=Ridge(alpha=1,max_iter=1000,tol=0.00001).fit(X_Train, y_Train)   #Huan luyen Ridge
y_pred=clf.predict(X_Test)  
y=np.array(y_Test)
print("Thuc te        Du doan              Chenh lech")
for i in range (0,len(y)):
    print('%.2f' %y[i]," ", y_pred[i]," ", abs(y[i]-y_pred[i]))
# Tính R-squared (R²)
r2 = r2_score(y_Test, y_pred)
# Tính Nash-Sutcliffe Efficiency (NSE)
nse = 1 - (np.sum((y_Test - y_pred) ** 2) / np.sum((y_Test - np.mean(y_Test)) ** 2))
# Tính Mean Absolute Error (MAE)
mae = mean_absolute_error(y_Test, y_pred)
# Tính Root Mean Squared Error (RMSE)
rmse = np.sqrt(mean_squared_error(y_Test, y_pred))
print("R-squared (R²):", r2)
print("Nash-Sutcliffe Efficiency (NSE):", nse)
print("Mean Absolute Error (MAE):", mae)
print("Root Mean Squared Error (RMSE):", rmse)


import pandas as pd
from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import numpy as np
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from math import sqrt
data = pd.read_csv('Heart_Disease_Prediction.csv')
dt_Train, dt_Test = train_test_split(data, test_size=0.3 , shuffle = False)
X_train = dt_Train.iloc[:, :13]
y_train= dt_Train.iloc[:, 13]
X_test = dt_Test.iloc[:, :13]
y_test = dt_Test.iloc[:, 13]
reg = LinearRegression()
reg.fit(X_train, y_train)
print('w=', reg.coef_)
print('w0=', reg.intercept_)
y_test_pred = reg.predict(X_test)
y=np.array(y_test)
print("Thuc te   Du doan      Chenh lech")
for i in range(0,len(y)):
    print("%.2f" % y[i], "   ", y_test_pred[i], "   ", abs(y[i]-y_test_pred[i]))
test_r2 = r2_score(y_test, y_test_pred)
# Tính Nash-Sutcliffe Efficiency (NSE)
nse = 1 - (np.sum((y_test - y_test_pred) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2))
# Tính MAE (Mean Absolute Error) trên tập kiểm tra
mae = mean_absolute_error(y_test, y_test_pred)
# Tính RMSE (Root Mean Square Error) trên tập kiểm tra
rmse = sqrt(mean_squared_error(y_test, y_test_pred))
# In ra các kết quả
print("R-squared (R²):", test_r2)
print("Nash-Sutcliffe Efficiency (NSE):", nse)
print("Mean Absolute Error (MAE):", mae)
print("Root Mean Squared Error (RMSE):", rmse)
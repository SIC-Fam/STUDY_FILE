import pandas as pd
from sklearn.metrics import r2_score
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import numpy as np
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from math import sqrt
data = pd.read_csv('Heart_Disease_Prediction.csv')
dt_Train, dt_Test = train_test_split(data, test_size=0.3 , shuffle = False)
# tinh error, y thuc te, y_pred: dl du doan
def error(y,y_pred):
    sum=0
    for i in range(0,len(y)):
        sum = sum + abs(y[i] - y_pred[i])
    return sum/len(y)  # tra ve trung binh
min=999999
k = 5
kf = KFold(n_splits=k, random_state=None)
for train_index, validation_index in kf.split(dt_Train):
    X_train, X_validation = dt_Train.iloc[train_index,:13], dt_Train.iloc[validation_index, :13]
    y_train, y_validation = dt_Train.iloc[train_index, 13], dt_Train.iloc[validation_index, 13]

    lr = LinearRegression()
    lr.fit(X_train, y_train)
    y_train_pred = lr.predict(X_train)
    y_validation_pred = lr.predict(X_validation)
    y_train = np.array(y_train)
    y_validation = np.array(y_validation)

    sum_error = error(y_train,y_train_pred)+error(y_validation, y_validation_pred)
    if(sum_error < min):
        min = sum_error
        regr=lr
y_test_pred=regr.predict(dt_Test.iloc[:,:13])
y_test=np.array(dt_Test.iloc[:,13])
print("Thuc te        Du doan              Chenh lech")
for i in range(0,len(y_test)):
    print(y_test[i],"  ",y_test_pred[i],  "  " , abs(y_test[i]-y_test_pred[i]))
test_r2 = r2_score(y_test, y_test_pred)
# Tính NSE (Nash-Sutcliffe Efficiency) trên tập kiểm tra
nse = 1 - (np.sum((y_test - y_test_pred) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2))
# Tính MAE (Mean Absolute Error) trên tập kiểm tra
mae = mean_absolute_error(y_test, y_test_pred)
# Tính RMSE (Root Mean Square Error) trên tập kiểm tra
rmse = sqrt(mean_squared_error(y_test, y_test_pred))
# In ra các kết quả
print("R-squared (R²):", test_r2)
print("Nash-Sutcliffe Efficiency (NSE):", nse)
print("Mean Absolute Error (MAE):", mae)
print("Root Mean Squared Error (RMSE):", rmse)
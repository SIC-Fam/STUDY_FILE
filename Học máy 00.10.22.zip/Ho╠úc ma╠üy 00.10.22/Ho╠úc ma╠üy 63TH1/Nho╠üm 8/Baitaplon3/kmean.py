import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.metrics import silhouette_score, davies_bouldin_score
from tkinter import *
from tkinter import ttk

df = pd.read_csv('stroke_prediction.csv')
X_data = np.array(df[['gender', 'age', 'hypertension', 'heart_disease', 'ever_married', 'work_type',
                     'Residence_type', 'avg_glucose_level', 'bmi', 'smoking_status']].values)

def data_encoder(X):
    for i, j in enumerate(X):
        for k in range(0, 10):
            if (j[k] == "Yes"):
                j[k] = 1
            elif (j[k] == "No"):
                j[k] = 2
            elif (j[k] == "Urban"):
                j[k] = 3
            elif (j[k] == "Rural"):
                j[k] = 4
            elif (j[k] == "Unknown"):
                j[k] = 5
            elif (j[k] == "never smoked"):
                j[k] = 6
            elif (j[k] == "formerly smoked"):
                j[k] = 7
            elif (j[k] == "smokes"):
                j[k] = 8
            elif (j[k] == "Private"):
                j[k] = 9
            elif (j[k] == "Self-employed"):
                j[k] = 10
            elif (j[k] == "Govt_job"):
                j[k] = 11
            elif (j[k] == "children"):
                j[k] = 12
            elif (j[k] == "Male"):
                j[k] = 13
            elif (j[k] == "Female"):
                j[k] = 14
    return X

data = data_encoder(X_data)
dt_Train, dt_Test = train_test_split(data, test_size=0.1, shuffle=True)

X_test = np.array(dt_Test)
kmeans = KMeans(n_clusters=2, random_state=0, n_init='auto').fit(X_test)

y_pred = kmeans.predict(dt_Test)
labels = kmeans.labels_
centers = kmeans.cluster_centers_

silhouette = silhouette_score(X_test, y_pred)
davies = davies_bouldin_score(X_test, y_pred)

window = Tk()
window.title("Phân cụm khả năng bệnh đột quỵ")
window.geometry('450x450')
window.configure(background="yellow")

Gender = Label(window, text="Gender").grid(row=1, column=1, padx=40, pady=10)
GD = ["Male", "Female"]
txtGender = ttk.Combobox(window, values=GD)
txtGender.set('Male')
txtGender.grid(row=1, column=2, pady=10)

Age = Label(window, text="Age ").grid(row=2, column=1, padx=40, pady=10)
txtAge = Entry(window)
txtAge.grid(row=2, column=2, pady=10)

Hypertension = Label(window, text="hypertension").grid(row=3, column=1, padx=40, pady=10)
txtHypertension = Entry(window)
txtHypertension.grid(row=3, column=2, pady=10)

Heart_disease = Label(window, text="heart_disease").grid(row=4, column=1, padx=40, pady=10)
txtHeart_disease = Entry(window)
txtHeart_disease.grid(row=4, column=2, pady=10)

Ever_married = Label(window, text="ever_married").grid(row=5, column=1, padx=40, pady=10)
txtEver_married = Entry(window)
txtEver_married.grid(row=5, column=2, pady=10)

Work_type = Label(window, text="work_type").grid(row=6, column=1, padx=40, pady=10)
txtWork_type = Entry(window)
txtWork_type.grid(row=6, column=2, pady=10)

Residence_type = Label(window, text="Residence_type").grid(row=7, column=1, padx=40, pady=10)
txtResidence_type = Entry(window)
txtResidence_type.grid(row=7, column=2, pady=10)

Avg_glucose_level = Label(window, text="avg_glucose_level").grid(row=8, column=1, padx=40, pady=10)
txtAvg_glucose_level = Entry(window)
txtAvg_glucose_level.grid(row=8, column=2, pady=10)

Bmi = Label(window, text="bmi").grid(row=9, column=1, padx=40, pady=10)
txtBmi = Entry(window)
txtBmi.grid(row=9, column=2, pady=10)

Smoking_status = Label(window, text="smoking_status").grid(row=10, column=1, padx=40, pady=10)
txtSmoking_status = Entry(window)
txtSmoking_status.grid(row=10, column=2, pady=10)

Silhouette = Label(window, text="Độ đo Silhouette  ").grid(row=11, column=1, pady=10)
lbhous = Label(window, text=silhouette)
lbhous.grid(row=11, column=2, pady=10)

davis = Label(window, text="Độ đo DaviesBouldin là ").grid(row=12, column=1, pady=10)
lbdv = Label(window, text=davies)
lbdv.grid(row=12, column=2, pady=10)

def Kmean():
    gender = txtGender.get()
    age = txtAge.get()
    hypertension = txtHypertension.get()
    heart_disease = txtHeart_disease.get()
    ever_married = txtEver_married.get()
    work_type = txtWork_type.get()
    residence_type = txtResidence_type.get()
    avg_glucose_level = txtAvg_glucose_level.get()
    bmi = txtBmi.get()
    smoking_status = txtSmoking_status.get()

    if gender == "Male":
        gender = 13
    else:
        gender = 14

    if ever_married == "Yes":
        ever_married = 1
    else:
        ever_married = 0

    if residence_type == "Rural":
        residence_type = 3
    else:
        residence_type = 4

    if smoking_status == "Unknown":
        smoking_status = 5
    elif smoking_status == "never smoked":
        smoking_status = 6
    elif smoking_status == "formerly smoked":
        smoking_status = 7
    elif smoking_status == "smokes":
        smoking_status = 8

    if work_type == "Private":
        work_type = 9
    elif work_type == "Self-employed":
        work_type = 10
    elif work_type == "Govt_job":
        work_type = 11
    elif work_type == "children":
        work_type = 12

    X_dudoan = np.array([[gender, age, hypertension, heart_disease, ever_married, work_type, residence_type,
                         avg_glucose_level, bmi, smoking_status]])
    y_kqua = kmeans.predict(X_dudoan)
    lbl.configure(text=y_kqua)

lblLOP = Label(window, text='Lớp dự đoán là :  ').grid(row=13, column=1, pady=10)
lbl = Label(window, text='....')
lbl.grid(row=13, column=2, pady=10)

xacnhan = Button(window, text="Dự đoán", command=Kmean).grid(row=14, column=2, pady=10)

window.mainloop()

import pandas as pd 
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
data = pd.read_csv('stroke_prediction.csv') #đọc tập dữ liệu
le = preprocessing.LabelEncoder() #mô hình hóa, để mã hoá các biến hạng mục trong dataframe
data = data.apply(le.fit_transform) #chuyển các biến hạng mục thành các giá trị số nguyên
dt_train, dt_test = train_test_split(data, test_size=0.3, shuffle=True) #chia dữ liệu thành 70% 30% để huấn luyện mô hình
X_train = dt_train.drop(['stroke'], axis = 1)#huấn luyện, loại bỏ cột stroke, axis = 1 cho biết đang thực hiện thao tác trên cột, chứ không phải trên hàng 
y_train = dt_train['stroke']
X_test = dt_test.drop(['stroke'], axis = 1)
y_test = dt_test['stroke']
clf = DecisionTreeClassifier(criterion='entropy',max_depth=6,min_samples_leaf=4).fit(X_train, y_train) #khai báo mô hình cây quyết định ,cretertion=đánh giá ,maxdepth độ sâu tối đa,
y_pred = clf.predict(X_test) #sử dụng mô hình đã huấn luyện để dự đoán nhãn cho tập X_test
print('Accuracy: ',accuracy_score(y_test,y_pred))
print('Precision:', precision_score(y_test, y_pred,average='micro'))
print('Recall:', recall_score(y_test, y_pred,average='micro'))
print('F1-score:', f1_score(y_test, y_pred,average='micro'))
import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
data = pd.read_csv('stroke_prediction.csv')
le = preprocessing.LabelEncoder()
data = data.apply(le.fit_transform)
dt_train, dt_test = train_test_split(data, test_size=0.3, shuffle=True)
X_train = dt_train.drop(['stroke'], axis = 1)
y_train = dt_train['stroke']
X_test = dt_test.drop(['stroke'], axis = 1)
y_test = dt_test['stroke']
pla=SVC(max_iter=-1,kernel='linear',random_state=1,tol=0.0001).fit(X_train,y_train) #khai báo mô hình SVM, chạy mô hình trên tập x_train, y_train
y_predict = pla.predict(X_test) 
y_pred = pla.predict(X_test)
print('Accuracy: ',accuracy_score(y_test,y_pred))
print('Precision:', precision_score(y_test, y_pred,average='micro'))
print('Recall:', recall_score(y_test, y_pred,average='micro'))
print('F1-score:', f1_score(y_test, y_pred,average='micro'))
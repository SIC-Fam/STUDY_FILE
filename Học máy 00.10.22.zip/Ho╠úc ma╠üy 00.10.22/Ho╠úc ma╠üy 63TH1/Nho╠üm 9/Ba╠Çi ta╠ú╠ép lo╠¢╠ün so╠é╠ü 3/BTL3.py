import numpy as np 
import pandas as pd 
from tkinter import messagebox
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split 
from sklearn import preprocessing
from sklearn.metrics import silhouette_score, davies_bouldin_score

# Hàm chuẩn hóa dữ liệu
def data_encoder(X):
    for i, j in enumerate(X):
        for k in range(0, 1):
            if (j[k] == "Male"):
                j[k] = 0
            elif (j[k] == "Female"):
                j[k] = 1
    return X

data=pd.read_csv('D:\\programming\\python\\hoc_may\\bai_tap_lon3\\Customer.csv')
data = np.array( data[['Gender', 'Age', 'Annual_Income', 'Spending_Score']].values )
# Chuẩn hóa dữ liệu
X_data = data_encoder(data)

# Chia dữ liệu thành tập huấn luyện và tập kiểm tra
dt_train, dt_test = train_test_split(X_data, test_size=0.1, shuffle=True)

X=np.array(dt_train) # Ép kiểu về mảng
X_test=np.array(dt_test) # Ép kiểu về mảng
# print(dt_train)
print(dt_test)

# Khai báo thuật toán  Kmean
km=KMeans(n_clusters=6,random_state=1,n_init='auto',tol=0.01,).fit(X)

# Số nhóm là 6
# random state khởi tao một vùng để thực hiện random

y_pred=km.predict(X_test)
#dudoan nhãn của tập test

#print(km.cluster_centers_)#in ra tâm của các cụm

silhoue = silhouette_score(X_test,y_pred)#càng cao càng tốt
davies = davies_bouldin_score(X_test, y_pred)#càng thấp càng tốt

from tkinter import *
from tkinter import ttk
# Tạo cửa sổ chính của ứng dụng GUI
window = Tk()
#tiêu đề
window.title("Phân cụm khả năng chi tiêu của người tiêu dùng")
#Kích thước
window.geometry('450x450')
# màu nền của cửa sổ
window.configure(background = "pink")

Gender = Label(window ,text = "Giới tính").grid(row=1, column=1, padx=40, pady=10)
GD=["Male","Female"]
txtGender = ttk.Combobox(window,values=GD)
txtGender.set('Male')
txtGender.grid(row=1, column=2,pady=10)

Age = Label(window ,text = "Tuổi ").grid(row=2, column=1, padx=40, pady=10)
txtAge = Entry(window)
txtAge.grid(row=2, column=2,pady=10)

Annual = Label(window ,text = "Thu nhập hàng năm").grid(row=3, column=1, padx=40, pady=10)
txtAnnual = Entry(window)
txtAnnual.grid(row=3, column=2,pady=10)

Spending = Label(window ,text = "Điểm chi tiêu(0-100)").grid(row=4, column=1, padx=40, pady=10)
txtSpending = Entry(window)
txtSpending.grid(row=4, column=2,pady=10)

Silhouette=Label(window,text="Độ đo Silhouette ").grid(row=8, column=1,pady=10)
lbhous=Label(window,text=silhoue).grid(row=8, column=2,pady=10)
davis=Label(window,text="Độ đo DaviesBouldin là ").grid(row=9, column=1,pady=10)
lbdv=Label(window,text=davies).grid(row=9, column=2,pady=10)
#hàm lấy dữ liệu và dự đoán mẫu của dữ liệu từ form
def Kmean():
    gender=txtGender.get()
    age=txtAge.get()
    annual=txtAnnual.get()
    spending=txtSpending.get()
    if (gender == "Male"):
        gender = 0
    else:
        gender = 1
    if((gender == '') or (age == '') or (annual == '') or (spending == '') ):
        messagebox.showinfo("Thông báo", "Bạn cần nhập đầy đủ thông tin!")
    else:
        X_dudoan = np.array([[gender,age,annual,spending]]).reshape(1, -1)
        y_kqua = km.predict(X_dudoan)
        lbl.configure(text=y_kqua)

lblLOP=Label(window, text = 'Lớp dự đoán là :  ').grid(row=7, column=1,pady=10)
lbl=Label(window,text='....')
lbl.grid(row=7, column=2,pady=10)
xacnhan=Button(window,text="Dự đoán",command=Kmean).grid(row=6, column=2,pady=10)

window.mainloop()
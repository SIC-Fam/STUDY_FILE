import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.svm import SVC #khai báo thư viện SVC
from sklearn.metrics import accuracy_score,f1_score,precision_score,recall_score


data = pd.read_csv('diabetes_prediction_dataset.csv') #đọc dữ liệu

le = preprocessing.LabelEncoder()
data = data.apply(le.fit_transform) #chuẩn hóa tất cả chữ trong tập dữ liệu thành số
dt_train, dt_test = train_test_split(data, test_size=0.3, shuffle=True) 
# Tham số test_size được đặt thành 0.3, nghĩa là 30% dữ liệu sẽ được sử dụng cho tập kiểm tra và 70% dữ liệu còn lại sẽ được sử dụng cho tập huấn luyện.
# Tham số shuffle được đặt thành True để đảm bảo rằng các hàng dữ liệu được xáo trộn ngẫu nhiên.

X_train = dt_train.drop(['diabetes'], axis = 1) # gán mẫu của tập train là toàn bộ data của tập dt_train trừ cột diabetes
y_train = dt_train['diabetes'] # gán nhãn của tập train là dữ liệu của cột diabetes trong dt_train
X_test = dt_test.drop(['diabetes'], axis = 1)# gán mẫu của tập test là toàn bộ data của tập dt_test trừ cột diabetes
y_test = dt_test['diabetes'] # gán nhãn của tập test là dữ liệu của cột diabetes trong dt_test



svm=SVC(max_iter=-1,kernel='poly',random_state=1,tol=0.001).fit(X_train,y_train) 
#khai báo mô hình SVM, chạy mô hình trên tập x_train, y_train
#max_inter = mặc định -1
y_pred = svm.predict(X_test) #dự đoán dựa trên dlieu x_test

print('Accuracy SVM: ',accuracy_score(y_test,y_pred)) #sử dụng hàm accuracy_score để tính tỉ lệ dự đoán bằng cách lấy y_pred / y_test, kq càng gần 1 mô hình càng tốt
print('Precision SVM: ',precision_score(y_test, y_pred,average='micro'))# Precision (độ chuẩn xác) tỉ lệ số điểm Positive (dự đoán đúng) / tổng số điểm mô hình dự đoán là Positive
print('Recall SVM: ',recall_score(y_test, y_pred,average='micro'))#Recall tỉ lệ số điểm Positive mô hình dự đoán đúng trên tổng số điểm được gán nhãn là Positive ban đầu
print('F1_score SVM: ',f1_score(y_test, y_pred, average='micro'))





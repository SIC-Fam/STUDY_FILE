import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score,f1_score,precision_score,recall_score


data = pd.read_csv('diabetes_prediction_dataset.csv')#đọc dữ liệu

le = preprocessing.LabelEncoder()
data = data.apply(le.fit_transform) #chuẩn hóa tất cả chữ trong tập dữ liệu thành số
dt_train, dt_test = train_test_split(data, test_size=0.3, shuffle=True)
# Tham số test_size được đặt thành 0.3, nghĩa là 30% dữ liệu sẽ được sử dụng cho tập kiểm tra và 70% dữ liệu còn lại sẽ được sử dụng cho tập huấn luyện.
# Tham số shuffle được đặt thành True để đảm bảo rằng các hàng dữ liệu được xáo trộn ngẫu nhiên.

X_train = dt_train.drop(['diabetes'], axis = 1) # gán mẫu của tập train là toàn bộ data của tập dt_train trừ cột diabetes
y_train = dt_train['diabetes'] # gán nhãn của tập train là dữ liệu của cột diabetes trong dt_train
X_test = dt_test.drop(['diabetes'], axis = 1)# gán mẫu của tập test là toàn bộ data của tập dt_test trừ cột diabetes
y_test = dt_test['diabetes'] # gán nhãn của tập test là dữ liệu của cột diabetes trong dt_test



dtr = DecisionTreeClassifier(criterion='entropy',max_depth=5,min_samples_leaf=3)
#khai báo mô hình cây quyết định ,cretertion=entropy phương pháp tính toán độ tinh khiết bằng chỉ số entropy(id3) ,
#maxdepth độ sâu tối đa=5, số mẫu tối thiểu min_samples_leaf là 3
dtr.fit(X_train, y_train)#truyền vào train huấn luyện vô hình xây dựng cây quyết định 
y_pred = dtr.predict(X_test)#dự đoán nhãn của tập test


print('Accuracy ID3: ',accuracy_score(y_test,y_pred)) #sử dụng hàm accuracy_score để tính tỉ lệ dự đoán bằng cách lấy y_pred / y_test, kq càng gần 1 mô hình càng tốt
print('Precision ID3: ',precision_score(y_test, y_pred,average='micro'))# Precision (độ chuẩn xác) tỉ lệ số điểm Positive (dự đoán đúng) / tổng số điểm mô hình dự đoán là Positive
print('Recall ID3: ',recall_score(y_test, y_pred,average='micro'))#Recall tỉ lệ số điểm Positive mô hình dự đoán đúng trên tổng số điểm được gán nhãn là Positive ban đầu
print('F1_score ID3: ',f1_score(y_test, y_pred, average='micro'))
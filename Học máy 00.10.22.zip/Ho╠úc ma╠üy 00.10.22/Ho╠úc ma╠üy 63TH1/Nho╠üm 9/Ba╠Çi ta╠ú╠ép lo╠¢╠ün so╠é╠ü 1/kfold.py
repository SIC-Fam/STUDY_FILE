import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error

data = pd.read_csv('D:\\programming\\python\\hoc_may\\hoi_quy_tuyen_tinh\\bai_tap_lon1\\breast_cancer.csv')

dt_Train,dt_Test = train_test_split(data, test_size=0.3, shuffle=False)
# Tham số test_size được đặt thành 0.3, nghĩa là 30% dữ liệu sẽ được sử dụng cho tập kiểm tra và 70% dữ liệu còn lại sẽ được sử dụng cho tập huấn luyện
# Tham số shuffle được đặt thành False để đảm bảo rằng các hàng dữ liệu không được xáo trộn ngẫu nhiên

# Tính error, y thực tế, y_pred: Dữ liệu dự đoán
def error(y_test,y_pred): # Tổng thực tế dự đoán chênh lệch
    sum = 0
    for i in range(0, len(y_test)):
        sum = sum + (np.abs(np.array(y_test[i]) - np.array(y_pred[i])))
    return sum/len(y_test) # Trả về giá trị trênh lệch

def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))

def MAE(y_test, y_pred):
    return mean_absolute_error(y_test, y_pred)

def RMSE(y_test, y_pred):
    return mean_squared_error(y_test, y_pred, squared=False)

# Tạo cross-validator sử dụng KFold với k-fold, n_splits = k = 5 tức là chia ra 5 tập fold
k = 5

kf = KFold(n_splits = k, random_state=None) #chia tập dữ liệu thành 5 phần

min = 999

for Trainning_Set,Validation_Set in kf.split(dt_Train): # Chọn ngẫu nhiên 4 phần là data train và 1 phần làm validation
    # Cắt dữ liệu vào các biến tương ứng (X chứa các thuộc tính | Y chứa nhãn)
    X_Train = dt_Train.iloc[Trainning_Set, :30]  # Lấy phần mẫu trainning set trong dt_train, từ cột 0 đến cột 29
    X_Validation = dt_Train.iloc[Validation_Set, :30] # Lấy phần mẫu của validation set trong dt_train, từ cột 0 đến cột 29
    Y_Train = dt_Train.iloc[Trainning_Set, 30] # Lấy phần nhãn trainning set trong dt_train là cột 30
    Y_Validation = dt_Train.iloc[Validation_Set, 30]# Lấy phần nhãn của validation set trong dt_train là cột 30

    # Khai báo mô hình hồi quy tuyến tính và tính toán bộ trọng số w của hàm tuyến tính
    LinReg = LinearRegression() # Khởi tạo mô hình LinearRegression
    LinReg.fit(X_Train, Y_Train) # Huấn luyện

    Y_Train_pred = LinReg.predict(X_Train) # Dự đoán nhãn của bộ dữ liệu trainning
    Y_Validation_pred = LinReg.predict(X_Validation) # Dự đoán nhãn của bộ dữ liệu validation
    Y_Train = np.array(Y_Train) # Ép kiểu từ frame về mảng
    Y_Validation = np.array(Y_Validation) #ep kiểu từ frame về mảng

    sum_er = error(Y_Train, Y_Train_pred) + error(Y_Validation, Y_Validation_pred) # Tính tổng của train error và validation error
    if (sum_er < min): # Tìm min để đưa ra mô hình tốt nhất
        min = sum_er
        lr = LinReg # Trả về mô hình tốt nhất

# Bắt đầu dự đoán dựa trên mô hình tốt nhất
X_Test = dt_Test.iloc[:, :30]
Y_Test = dt_Test.iloc[:, 30]
Y_Test_pred = lr.predict(X_Test) # Sử dụng mô hình tốt nhất để đưa ra tập dự đoán từ tập test
Y_Test = np.array(Y_Test) # Ép kiểu về mảng

for i in range(0, len(Y_Test)):
    print("Thực tế:", Y_Test[i], "--", "Dự đoán:", Y_Test_pred[i], "--", "Chênh lệch:", abs(Y_Test[i]-Y_Test_pred[i]))
print('Coefficient of determination k-fold:' ,r2_score(Y_Test,Y_Test_pred)) 
print('NSE k-fold:', NSE(Y_Test,Y_Test_pred))
print('MAE k-fold:', MAE(Y_Test,Y_Test_pred))
print('RMSE k-fold:', RMSE(Y_Test,Y_Test_pred))

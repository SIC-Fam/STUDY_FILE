import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.linear_model import Lasso
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error

data = pd.read_csv('D:\\programming\\python\\hoc_may\\hoi_quy_tuyen_tinh\\bai_tap_lon1\\breast_cancer.csv')
dt_Train,dt_Test = train_test_split(data, test_size=0.3, shuffle=False)
# Tham số test_size được đặt thành 0.3, nghĩa là 30% dữ liệu sẽ được sử dụng cho tập kiểm tra và 70% dữ liệu còn lại sẽ được sử dụng cho tập huấn luyện
# Tham số shuffle được đặt thành False để đảm bảo rằng các hàng dữ liệu không được xáo trộn ngẫu nhiên

def NSE(y_test, y_pred):
    return (1 - (np.sum((y_pred - y_test) ** 2) / np.sum((y_test - np.mean(y_test)) ** 2)))

def MAE(y_test, y_pred):
    return mean_absolute_error(y_test, y_pred)

def RMSE(y_test, y_pred):
    return mean_squared_error(y_test, y_pred, squared=False)

X_Train = dt_Train.iloc[:, :30] # Mẫu tập train, tất cả các hàng và từ cột 0 đến cột 29
Y_Train = dt_Train.iloc[:, 30] # Nhãn của tập train, tất cả các hàng và cột 30
X_Test = dt_Test.iloc[:, :30] # Mẫu tập test, tất cả các hàng và từ cột 0 đến cột 29
Y_Test = dt_Test.iloc[:, 30] # Nhãn của tập test, tất cả các hàng và cột 30

reg = Lasso(alpha = 1.0, max_iter = 1000, tol = 0.01) # Khởi tạo mô hình Lasso
# max_iter là Số lần lặp tối đa 
# alpha là độ chính xác
# tol là độ chính xác của nghiệm

reg.fit(X_Train,Y_Train) # Huấn luyện mô hình từ tập train
Y_Pred = reg.predict(X_Test) # Đưa ra dự toán từ tập test
Y = np.array(Y_Test) # Ép kiểu về mảng

for i in range(0,len(Y)):
    print("Thực tế:", Y[i], "--", "Dự đoán:", Y_Pred[i], "--", "Chênh lệch:", abs(Y[i]-Y_Pred[i]))
print('Coefficient of determination Lasso:' ,r2_score(Y, Y_Pred)) 
print('NSE Lasso:', NSE(Y, Y_Pred))
print('MAE Lasso:', MAE(Y, Y_Pred))
print('RMSE Lasso:', RMSE(Y, Y_Pred))
